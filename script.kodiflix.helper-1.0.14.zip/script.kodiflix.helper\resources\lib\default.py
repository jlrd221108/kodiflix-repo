#!/usr/bin/python
# coding: utf-8

import json
import os
import re
import sys
import time

import xbmc
import xbmcgui
import xbmcplugin

from service import CACHE_DIRECTORY, CACHE_TOKEN_PROPERTY, HOME_WINDOW, clear_properties, ensure_cache_directory


def jsonrpc(method, params):
    request = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get("result", {})


def list_songs(handle, lane):
    folder = xbmc.getInfoLabel("Container.FolderPath")
    match = re.search(r"albumid/(\d+)", folder)
    album_id = int(match.group(1)) if match else 0
    if not album_id:
        song_id = int(xbmc.getInfoLabel("ListItem.DBID") or 0)
        if song_id:
            details = jsonrpc("AudioLibrary.GetSongDetails", {"songid": song_id, "properties": ["albumid"]}).get("songdetails", {})
            album_id = int(details.get("albumid", 0) or 0)
    if not album_id:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    songs = jsonrpc("AudioLibrary.GetSongs", {"filter": {"albumid": album_id}, "properties": ["title", "track", "duration", "artist", "album", "albumid", "file", "art"], "limits": {"start": 0, "end": 100000}, "sort": {"method": "track", "order": "ascending"}}).get("songs", [])
    midpoint = len(songs) // 2
    songs = songs[:midpoint] if lane == "left" else songs[midpoint:]
    xbmcplugin.setContent(handle, "songs")
    for song in songs:
        item = xbmcgui.ListItem(label=song.get("title", ""), offscreen=True)
        item.setInfo("music", {"title": song.get("title", ""), "tracknumber": song.get("track", 0), "duration": song.get("duration", 0), "artist": song.get("artist", []), "album": song.get("album", "")})
        item.setArt(song.get("art", {}))
        xbmcplugin.addDirectoryItem(handle, song.get("file", ""), item, False)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def clear_blur_cache():
    ensure_cache_directory()
    try:
        for entry in os.scandir(CACHE_DIRECTORY):
            if entry.is_file():
                try:
                    os.remove(entry.path)
                except OSError:
                    continue
    except OSError:
        pass
    clear_properties()
    HOME_WINDOW.setProperty(CACHE_TOKEN_PROPERTY, str(time.time()))
    xbmcgui.Dialog().notification("Kodiflix", "Blur cache cleared", time=2500)


if __name__ == "__main__":
    if len(sys.argv) > 0 and sys.argv[0].startswith("plugin://"):
        handle = int(sys.argv[1])
        query = sys.argv[2] if len(sys.argv) > 2 else ""
        list_songs(handle, "right" if "lane=right" in query else "left")
    elif len(sys.argv) > 1 and sys.argv[1] == "action=clear_cache":
        clear_blur_cache()