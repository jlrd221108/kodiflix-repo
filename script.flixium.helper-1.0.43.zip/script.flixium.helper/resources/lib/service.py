"""Publish adaptive artwork only while a custom view consumes it."""
import time

import xbmc
import xbmcvfs

from artwork_cache import (
    SUPPORTED_SKIN, SOURCE_CONTROL_ID, POSTER_SOURCE_CONTROL_ID,
    OUTPUT_PROPERTY, INFO_OUTPUT_PROPERTY, COLOR_PROPERTY, POSTER_COLOR_PROPERTY,
    COLOR_NOALPHA_PROPERTY, TEXT_COLOR_PROPERTY, CACHE_TOKEN_PROPERTY,
    DEFAULT_RADIUS, DEFAULT_SATURATION, HOME_WINDOW,
    DEBOUNCE_SECONDS, ACTIVE_POLL_SECONDS, clear_properties,
    prune_cache, setting_number, cache_filename, cached_blur,
    create_blur, image_colors, cached_source_stamp as source_stamp, open_source, CACHE_DIRECTORY,
)


class FlixiumHelperService(xbmc.Monitor):
	def __init__(self):
		super().__init__()
		self.previous_key = ""
		self.pending_key = ""
		self.pending_since = 0.0
		self.previous_info_mode = False
		self.previous_poster_source = ""
		self.poster_pending_since = 0.0
		self.poster_retry_at = 0.0
		self.poster_succeeded = False
		self.retry_at = 0.0
		self.pruned_at = 0.0
		self.glow_source = ""
		self.glow_since = 0.0
		self.glow_colors = {}
		self.blur_colors = {}
		self.glow_retry_at = 0.0

	@staticmethod
	def publish_poster_color(color):
		if HOME_WINDOW.getProperty(POSTER_COLOR_PROPERTY) == color:
			return
		if color:
			HOME_WINDOW.setProperty(POSTER_COLOR_PROPERTY, color)
		else:
			HOME_WINDOW.clearProperty(POSTER_COLOR_PROPERTY)

	def update_poster_glow(self):
		if not xbmc.getCondVisibility(
			"Skin.HasSetting(flix_adaptive_focus_glow) + Window.IsActive(videos) + [Control.IsVisible(56) | Control.IsVisible(57)]"
		):
			self.publish_poster_color("")
			self.glow_source = ""
			return
		source = xbmc.getInfoLabel("Control.GetLabel({})".format(POSTER_SOURCE_CONTROL_ID))
		key = (source, source_stamp(source), HOME_WINDOW.getProperty(CACHE_TOKEN_PROPERTY))
		now = time.monotonic()
		if key != self.glow_source:
			self.glow_source = key
			self.glow_since = now
			self.glow_retry_at = 0.0
			self.publish_poster_color("")
		if not source:
			return
		if key in self.glow_colors:
			self.publish_poster_color(self.glow_colors[key])
			return
		if now - self.glow_since < DEBOUNCE_SECONDS or now < self.glow_retry_at:
			return
		try:
			image = open_source(source, CACHE_DIRECTORY + "poster-glow.source", bool(key[1]))
			if image is not None:
				try:
					color, _text_color = image_colors(image, poster=True)
				finally:
					image.close()
				if len(self.glow_colors) >= 128:
					self.glow_colors.clear()
				self.glow_colors[key] = color
				if source == xbmc.getInfoLabel("Control.GetLabel({})".format(POSTER_SOURCE_CONTROL_ID)):
					self.publish_poster_color(color)
				return
		except Exception as error:
			xbmc.log("Flixium poster colour failed: {}".format(error), xbmc.LOGWARNING)
		self.glow_retry_at = now + 5

	@staticmethod
	def current_request():
		if (xbmc.getCondVisibility("Skin.HasSetting(Flixium.Glass.Enabled)")
				and not xbmc.getCondVisibility("Skin.HasSetting(Flixium.Home.MQ5)")
				and not xbmc.getCondVisibility(
					"[Window.IsActive(videos) + [Control.IsVisible(56) | Control.IsVisible(57)]] | "
					"[Window.IsActive(music) + [Control.IsVisible(58) | Control.IsVisible(59) | Control.IsVisible(60)]]")):
			return "", DEFAULT_RADIUS, DEFAULT_SATURATION, False, False, ""

		artist_mode = False
		info_mode = xbmc.getCondVisibility("Window.IsActive(movieinformation)")
		active = info_mode or xbmc.getCondVisibility(
			"[Window.IsActive(videos) + [Control.IsVisible(56) | Control.IsVisible(57)]] | "
			"[Window.IsActive(music) + [Container.Content(albums) | Container.Content(artists) | Container.Content(songs)] + [Control.IsVisible(55) | Control.IsVisible(58) | Control.IsVisible(59) | Control.IsVisible(60)]]"
		)
		consumed = xbmc.getCondVisibility(
			"!Skin.HasSetting(flix_disable_background_blur) | [Skin.HasSetting(flix_adaptive_focus_glow) + !Window.IsActive(videos)]"
		)
		if not active or not consumed:
			return "", DEFAULT_RADIUS, DEFAULT_SATURATION, artist_mode, info_mode, ""

		source_control_id = SOURCE_CONTROL_ID
		source = xbmc.getInfoLabel(
			"Control.GetLabel({})".format(source_control_id)
		)
		playback_mode = xbmc.getCondVisibility(
			"Window.IsVisible(visualisation) | Window.IsActive(musicosd)"
		)
		if playback_mode or not active or not consumed:
			# Playback owns its own output property and reuses this cache/pipeline.
			# Avoid competing writes from the browsing and playback services.
			source = ""
		radius = setting_number("Flixium.BlurRadius", DEFAULT_RADIUS, int)
		if playback_mode or xbmc.getCondVisibility("Window.IsActive(music) + [Control.IsVisible(58) | Control.IsVisible(60)]"):
			# Albums and Tracks share a light full-screen cover blur.
			radius = 3
		saturation = setting_number(
			"Flixium.BlurSaturation", DEFAULT_SATURATION, float
		)
		cache_token = HOME_WINDOW.getProperty(CACHE_TOKEN_PROPERTY)
		key = (
			"{}|{}|{}|{}|{}|{}|{}|{}".format(source, radius, saturation, artist_mode, info_mode, cache_token, source_stamp(source), xbmc.getCondVisibility("Skin.HasSetting(flix_adaptive_focus_glow)"))
			if source
			else ""
		)
		return source, radius, saturation, artist_mode, info_mode, key

	def generate_and_publish(self, source, radius, saturation, artist_mode, info_mode, request_key):
		try:
			blurred = create_blur(source, radius, saturation)
			if not blurred:
				return False
			self.publish_blur(blurred, artist_mode, info_mode, request_key)
			return True
		except Exception as error:
			xbmc.log(
				"Flixium Helper blur failed: {}".format(error), xbmc.LOGERROR
			)
		return False

	def prewarm_poster(self, source, radius, saturation):
		"""Debounce changes and back off failed artwork instead of probing at 10 Hz."""
		if not source or source in ("movie", "tvshow", "episode", "set", "artist", "album", "song"):
			return
		key = cache_filename(source, radius, saturation)
		now = time.monotonic()
		if key != self.previous_poster_source:
			self.previous_poster_source = key
			self.poster_pending_since = now
			self.poster_retry_at = 0.0
			self.poster_succeeded = False
		if self.poster_succeeded or now - self.poster_pending_since < DEBOUNCE_SECONDS or now < self.poster_retry_at:
			return
		try:
			self.poster_succeeded = bool(create_blur(source, radius, saturation))
		except Exception as error:
			xbmc.log("Flixium poster prewarm failed: {}".format(error), xbmc.LOGWARNING)
		if not self.poster_succeeded:
			self.poster_retry_at = now + 5

	def publish_blur(self, blurred, artist_mode, info_mode, request_key):
		# Reject obsolete work before analysing colours or changing any properties.
		if self.current_request()[5] != request_key:
			return
		output = INFO_OUTPUT_PROPERTY if info_mode else OUTPUT_PROPERTY
		if HOME_WINDOW.getProperty(output) != blurred:
			HOME_WINDOW.setProperty(output, blurred)
		if not xbmc.getCondVisibility("Skin.HasSetting(flix_adaptive_focus_glow)"):
			return
		if blurred not in self.blur_colors:
			if len(self.blur_colors) >= 128:
				self.blur_colors.clear()
			self.blur_colors[blurred] = image_colors(blurred)
		color, text_color = self.blur_colors[blurred]
		for name, value in ((COLOR_NOALPHA_PROPERTY, color[2:]),
						(COLOR_PROPERTY, color), (TEXT_COLOR_PROPERTY, text_color)):
			if HOME_WINDOW.getProperty(name) != value:
				HOME_WINDOW.setProperty(name, value)

	@staticmethod
	def retain_music_blur():
		# Preserve transient artwork gaps only inside the dedicated Flix views.
		# Roots, other views and playback own their own backgrounds.
		return xbmc.getCondVisibility(
			"Window.IsActive(music) + [Container.Content(albums) | Container.Content(artists) | Container.Content(songs)] + "
			"[Control.IsVisible(58) | Control.IsVisible(59) | Control.IsVisible(60)]"
		)

	def run(self):
		prune_cache()
		self.pruned_at = time.monotonic()
		while not self.abortRequested():
			if xbmc.getSkinDir() != SUPPORTED_SKIN:
				if self.previous_key:
					clear_properties()
				self.previous_key = ""
				self.pending_key = ""
				self.waitForAbort(5)
				continue

			# Preserve the published blur while a modal context menu owns focus.
			if xbmc.getCondVisibility("Window.IsActive(DialogContextMenu.xml)"):
				self.waitForAbort(ACTIVE_POLL_SECONDS)
				continue

			# Cached backgrounds can follow selection during rail movement. Only
			# expensive decoding waits; selection debounce starts immediately.
			scrolling = xbmc.getCondVisibility("Container.Scrolling")
			if not scrolling:
				self.update_poster_glow()
			source, radius, saturation, artist_mode, info_mode, current_key = self.current_request()
			# Also remove leftovers retained by an earlier service/window transition.
			if not current_key and not self.retain_music_blur() and HOME_WINDOW.getProperty(OUTPUT_PROPERTY):
				clear_properties()
			if time.monotonic() - self.pruned_at >= 600 and not current_key and not self.pending_key:
				prune_cache()
				self.pruned_at = time.monotonic()

			if info_mode != self.previous_info_mode:
				HOME_WINDOW.clearProperty(INFO_OUTPUT_PROPERTY)
				self.previous_info_mode = info_mode

			if current_key != self.previous_key:
				self.previous_key = current_key
				self.pending_key = current_key
				self.pending_since = time.monotonic()
				self.retry_at = 0.0
				if not current_key:
					if not self.retain_music_blur():
						clear_properties()
					self.pending_key = ""
					self.waitForAbort(ACTIVE_POLL_SECONDS)
					continue
				cached_path = cached_blur(cache_filename(source, radius, saturation, artist_mode))
				if cached_path:
					self.pending_key = ""
					self.publish_blur(cached_path, artist_mode, info_mode, current_key)

			if (
				self.pending_key
				and not scrolling
				and time.monotonic() >= self.retry_at
				and time.monotonic() - self.pending_since >= DEBOUNCE_SECONDS
			):
				request_key = self.pending_key
				self.pending_key = ""
				succeeded = self.generate_and_publish(
					source, radius, saturation, artist_mode, info_mode, request_key
				)
				if not succeeded:
					self.pending_key = request_key
					self.retry_at = time.monotonic() + 5

			# Information-dialog poster blurs are generated on demand. Speculative
			# prewarming decoded every selected poster alongside the fanart.

			self.waitForAbort(ACTIVE_POLL_SECONDS if current_key else 0.75)


if __name__ == "__main__":
	FlixiumHelperService().run()
