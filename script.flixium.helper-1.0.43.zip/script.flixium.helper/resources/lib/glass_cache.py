"""Deterministic, on-demand Gaussian glass materials. No artwork or UI capture.

Build at a small working size, then reconstruct smooth gradients at the chosen
texture resolution. Immutable content-addressed bundles survive skin reloads.
"""
import hashlib
import json
import math
import random
import os
from pathlib import Path
import shutil
import time
import uuid
from PIL import Image, ImageDraw, ImageFilter, ImageChops

VERSION = "glass-9"
RESOLUTIONS = {"720": (1280, 720), "1080": (1920, 1080), "1440": (2560, 1440)}
FILES = ("gradient.png", "panel.png", "dialog.png", "sidebar.png")
MAX_BYTES = 192 * 1024 * 1024
MAX_BUNDLES = 12
LANCZOS = getattr(getattr(Image, "Resampling", Image), "LANCZOS")

def colour(value, fallback):
    try:
        value = str(value).lstrip("#")[-6:]
        if len(value) != 6:
            raise ValueError()
        return tuple(int(value[i:i+2], 16) for i in (0, 2, 4))
    except (ValueError, TypeError):
        return colour(fallback, "202B3E")

def configuration(window="", highlight="", dialog="", background_resolution="1080", panel_resolution="1080", rounded=False, palette=None, unrounded=False):
    palette=palette or {"background":["0C1423","29435A","242C47"]}
    return {"stops":[colour(v,"202B3E") for v in palette["background"]], "version": VERSION, "radius": 0 if unrounded else (30 if rounded else 16), "window": colour(window, "202B3E"),
            "highlight": colour(highlight, "7DABDC"), "dialog": colour(dialog, "25324A"),
            "background": str(background_resolution) if str(background_resolution) in RESOLUTIONS else "1080",
            "panels": str(panel_resolution) if str(panel_resolution) in RESOLUTIONS else "1080"}

def signature(config):
    return hashlib.sha256(json.dumps(config, sort_keys=True).encode()).hexdigest()[:24]

def _gradient(config, dialog=False):
    # A deterministic abstract composition, rendered only on a cache miss.
    # Irregular overlapping colour clouds retain separation after Gaussian blur.
    width,height=512,288
    stops=config["stops"]
    rng=random.Random(6419)
    backdrop=Image.new("RGB",(width,height),tuple(stops[0]))
    clouds=((.12,.14,.32,.40,1),(.69,.03,.38,.35,2),
            (.94,.36,.30,.44,1),(.38,.48,.34,.31,2),
            (.66,.77,.37,.40,1),(.08,.87,.30,.32,2),
            (.43,.10,.21,.22,0),(.91,.91,.29,.27,2),
            (.19,.58,.19,.25,0),(.60,.40,.20,.24,1),
            (.43,.93,.22,.26,0))
    for index,(cx,cy,rx,ry,colour_index) in enumerate(clouds):
        mask=Image.new("L",(width,height));draw=ImageDraw.Draw(mask)
        points=[]
        for step in range(18):
            angle=step*math.tau/18
            irregular=rng.uniform(.65,1.22)
            points.append(((cx+math.cos(angle)*rx*irregular)*width,
                           (cy+math.sin(angle)*ry*irregular)*height))
        draw.polygon(points,fill=235 if colour_index else 175)
        mask=mask.filter(ImageFilter.GaussianBlur(14+index%3*3))
        colour=tuple(min(140,round(v*(1.22 if colour_index else 1))) for v in stops[colour_index])
        backdrop=Image.composite(Image.new("RGB",(width,height),colour),backdrop,mask)
    # Moderate final blur softens joins without erasing the abstract structure.
    return backdrop.filter(ImageFilter.GaussianBlur(9))


def _surface_field(config, dialog=False):
    tint=config["dialog" if dialog else "window"]
    image=Image.new("RGB",(384,216),tuple(tint))
    sheen=Image.new("RGB",image.size,tuple(min(255,v+28) for v in tint))
    mask=Image.new("L",image.size);d=ImageDraw.Draw(mask)
    d.ellipse((-160,-120,440,210),fill=105)
    return Image.composite(sheen,image,mask.filter(ImageFilter.GaussianBlur(55)))


def _rounded(draw, box, radius, fill=None, outline=None, width=1):
    if radius <= 0:
        draw.rectangle(box, fill=fill, outline=outline, width=width)
        return
    # Kodi's bundled Pillow can predate rounded_rectangle/Resampling enums.
    if hasattr(draw, "rounded_rectangle"):
        draw.rounded_rectangle(box,radius=radius,fill=fill,outline=outline,width=width)
        return
    x0,y0,x1,y1=box;r=radius
    corners=((x0,y0,x0+2*r,y0+2*r,180),(x1-2*r,y0,x1,y0+2*r,270),
             (x0,y1-2*r,x0+2*r,y1,90),(x1-2*r,y1-2*r,x1,y1,0))
    if fill is not None:
        draw.rectangle((x0+r,y0,x1-r,y1),fill=fill)
        draw.rectangle((x0,y0+r,x1,y1-r),fill=fill)
        for a,b,c,d,start in corners:draw.pieslice((a,b,c,d),start,start+90,fill=fill)
    if outline is not None:
        draw.line((x0+r,y0,x1-r,y0),fill=outline,width=width)
        draw.line((x0+r,y1,x1-r,y1),fill=outline,width=width)
        draw.line((x0,y0+r,x0,y1-r),fill=outline,width=width)
        draw.line((x1,y0+r,x1,y1-r),fill=outline,width=width)
        for a,b,c,d,start in corners:draw.arc((a,b,c,d),start,start+90,fill=outline)

def _material(backdrop, size, dialog=False, radius=16):
    # The cached frosted field is shared. No per-control live blur/readback.
    image = backdrop.filter(ImageFilter.GaussianBlur(17)).resize(size,LANCZOS).convert("RGBA")
    glaze = Image.new("RGBA", size)
    draw = ImageDraw.Draw(glaze)
    w,h=size
    for y in range(h):
        # Quiet upper sheen, darker lower body. Baked once, no animation.
        alpha = round(5 * math.exp(-y/max(h*.25,1)) + 2)
        draw.line((0,y,w,y), fill=(220,236,255,alpha))
    image = Image.alpha_composite(image,glaze)
    alpha = Image.new("L",size,220 if dialog else 120)
    mask=Image.new("L",size);d=ImageDraw.Draw(mask)
    _rounded(d,(0,0,w-1,h-1),radius=radius,fill=255)
    alpha=ImageChops.multiply(alpha,mask);image.putalpha(alpha)
    edge=Image.new("RGBA",size);d=ImageDraw.Draw(edge)
    _rounded(d,(1,1,w-2,h-2),radius=radius,outline=(221,237,255,58 if dialog else 46),width=1)
    image=Image.alpha_composite(image,edge)
    return image

def _valid(directory, config):
    try:
        if json.loads((directory/"manifest.json").read_text()) != json.loads(json.dumps(config)):
            return False
        sizes=(RESOLUTIONS[config["background"]],)+(RESOLUTIONS[config["panels"]],)*3
        for name,size in zip(FILES,sizes):
            with Image.open(directory/name) as im:
                if im.size != size: return False
                im.verify()
        return True
    except (OSError,ValueError,KeyError):
        return False

def _part_key(config, name):
    keys={"gradient":("version","stops","background"),
          "panel":("version","window","highlight","panels","radius"),
          "sidebar":("version","stops","window","panels","radius"),
          "dialog":("version","dialog","highlight","panels","radius")}[name]
    return json.dumps({key:config[key] for key in keys},sort_keys=True)

def _reuse(root, stage, config, name):
    expected=RESOLUTIONS[config["background" if name=="gradient" else "panels"]]
    for candidate in root.iterdir():
        if not candidate.is_dir() or len(candidate.name)!=24:continue
        source=candidate/(name+".png")
        try:
            other=json.loads((candidate/"manifest.json").read_text())
            if _part_key(other,name)!=_part_key(config,name):continue
            with Image.open(source) as im:
                if im.size!=expected:continue
                im.verify()
            try:os.link(source,stage/(name+".png"))
            except OSError:shutil.copy2(source,stage/(name+".png"))
            return True
        except (OSError,ValueError,KeyError,TypeError):continue
    return False

def _prune(root, active):
    bundles=[]
    for p in root.iterdir():
        if p.is_dir() and len(p.name)==24 and p.name!=active.name:
            size=sum(f.stat().st_size for f in p.iterdir() if f.is_file())
            bundles.append((p.stat().st_mtime,size,p))
    total=sum(b[1] for b in bundles)+sum(f.stat().st_size for f in active.iterdir() if f.is_file())
    for _stamp,size,p in sorted(bundles):
        if len(bundles)<MAX_BUNDLES and total<=MAX_BYTES:break
        # Only generated, hash-named directories within this cache root.
        if p.resolve().parent != root.resolve():continue
        try:shutil.rmtree(p)
        except OSError:continue  # A locked old cache must not prevent the new theme loading.
        total-=size;bundles.pop(bundles.index((_stamp,size,p)))

def ensure_cache(cache_root, config):
    root=Path(cache_root);root.mkdir(parents=True,exist_ok=True)
    target=root/signature(config)
    if _valid(target,config):
        os.utime(target,None)
        return {name.split(".")[0]:str(target/name) for name in FILES},False
    lock=root/(target.name+".lock")
    try:
        lock.mkdir()
    except FileExistsError:
        if time.time()-lock.stat().st_mtime>120:
            lock.rmdir()
            return ensure_cache(root,config)
        # Another short-lived request owns generation. Never publish half files.
        for _ in range(100):
            time.sleep(.05)
            if _valid(target,config):
                return {name.split(".")[0]:str(target/name) for name in FILES},False
        raise RuntimeError("Glass cache generation is busy")
    stage=root/(target.name+".tmp-"+uuid.uuid4().hex)
    try:
        stage.mkdir()
        gradient=None
        if not _reuse(root,stage,config,"gradient"):
            gradient=_gradient(config)
            gradient.resize(RESOLUTIONS[config["background"]],LANCZOS).save(stage/FILES[0],compress_level=3)
        size=RESOLUTIONS[config["panels"]]
        if not _reuse(root,stage,config,"panel"):
            _material(_surface_field(config),size,radius=config["radius"]).save(stage/FILES[1],compress_level=3)
        if not _reuse(root,stage,config,"dialog"):
            _material(_surface_field(config,True),size,True,radius=config["radius"]).save(stage/FILES[2],compress_level=3)
        if not _reuse(root,stage,config,"sidebar"):
            if gradient is None:gradient=_gradient(config)
            # Blur the actual gradient region behind the 370px home sidebar.
            # Bake once; a denser frosted material obscures the sharper background.
            field=gradient.crop((0,0,round(gradient.width*370/1920),gradient.height))
            field=field.filter(ImageFilter.GaussianBlur(48))
            # Broad diffusion alone barely changes an already blurred gradient.
            # A stronger, palette-derived body gives the frost visible separation.
            tint=Image.new("RGB",field.size,tuple(round(v*.72) for v in config["window"]))
            field=Image.blend(field,tint,.48)
            # Soft transmitted light across the top, rather than an opaque fill.
            sheen=Image.new("RGB",field.size,tuple(min(255,v+18) for v in config["window"]))
            mask=Image.new("L",field.size);draw=ImageDraw.Draw(mask)
            for y in range(field.height):
                draw.line((0,y,field.width,y),fill=round(48*math.exp(-y/max(field.height*.40,1))))
            field=Image.composite(sheen,field,mask)
            sidebar=_material(field,size,True,radius=config["radius"])
            # Extend the centre material to the left edge; only right corners round.
            # The source is stretched into 370px, so widen the repair to retain
            # a consistent physical corner radius after nine-slice rendering.
            patch=max(33,config["radius"]+3)
            sidebar.paste(sidebar.crop((patch,0,patch+1,size[1])).resize((patch,size[1])),(0,0))
            sidebar.save(stage/FILES[3],compress_level=3)
        (stage/"manifest.json").write_text(json.dumps(config,sort_keys=True))
        if target.exists():
            # A corrupt generated bundle only; source artwork is never touched.
            if target.resolve().parent != root.resolve():raise ValueError("Invalid cache directory")
            shutil.rmtree(target)
        os.replace(stage,target)
        _prune(root,target)
    finally:
        if stage.exists() and stage.resolve().parent==root.resolve():shutil.rmtree(stage)
        lock.rmdir()
    return {name.split(".")[0]:str(target/name) for name in FILES},True
