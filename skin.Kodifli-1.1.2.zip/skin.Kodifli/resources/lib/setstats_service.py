#!/usr/bin/python
# coding: utf-8

"""Publish aggregate metadata for the movie set selected in the Flix view."""

import json
import re
import time

import xbmc
import xbmcgui


SUPPORTED_SKIN = "skin.Kodifli"
SET_ID_CONTROL = 56001
SET_TYPE_CONTROL = 56002
GENRE_CONTROL = 56003
PROPERTY_COUNT = "kodiflix.helper.set_count"
PROPERTY_YEARS = "kodiflix.helper.set_years"
PROPERTY_RUNTIME = "kodiflix.helper.set_runtime"
PROPERTY_GENRES = "kodiflix.helper.flix_genres"
PROPERTY_ARTIST_ALBUMS = "kodiflix.helper.artist_album_count"
PROPERTY_ARTIST_TRACKS = "kodiflix.helper.artist_track_count"
PROPERTY_ALBUM_TRACKS = "kodiflix.helper.album_track_count"
HOME_WINDOW = xbmcgui.Window(10000)
FLIX_ACTIVE_CONDITION = (
	"[Window.IsActive(videos) + [Control.IsVisible(56) | Control.IsVisible(57)]] | "
	"[Window.IsActive(music) + [Control.IsVisible(56) | Control.IsVisible(57) | Container.Content(albums)]] | "
	"[Window.IsActive(home) + [Control.HasFocus(5800) | Control.HasFocus(5900)]] | "
	"String.IsEqual(Control.GetLabel({}),artist)".format(SET_TYPE_CONTROL)
)
FLIX_DIALOG_OVERLAY_CONDITION = (
	"Window.IsActive(1111) | "
	"[Window.IsVisible(videos) + !Window.IsActive(videos) + "
	"[Control.IsVisible(56) | Control.IsVisible(57)]]"
)
ACTIVE_POLL_SECONDS = 0.10
IDLE_POLL_SECONDS = 0.75
LIBRARY_UPDATE_DEBOUNCE_SECONDS = 2.0
GENRE_SPLIT_RE = re.compile(r"\s*(?:/|\||\u2022|\u00b7)\s*|,\s*|;\s*")
GENRE_ABBREVIATIONS = {
	"science fiction": "Sci-Fi",
	"science-fiction": "Sci-Fi",
}


def set_kodi_bool_setting(setting, value, warning):
	request = {
		"jsonrpc": "2.0",
		"id": 1,
		"method": "Settings.SetSettingValue",
		"params": {
			"setting": setting,
			"value": value,
		},
	}
	response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
	if "error" in response:
		xbmc.log(
			"{}: {}".format(warning, response["error"]),
			xbmc.LOGWARNING,
		)


def apply_video_library_preferences():
	set_kodi_bool_setting(
		"videolibrary.showallitems",
		False,
		"Kodiflix could not disable Kodi video library all-items entries",
	)
	set_kodi_bool_setting(
		"filelists.showparentdiritems",
		False,
		"Kodiflix could not disable Kodi parent-folder entries",
	)


def clear_set_properties():
	HOME_WINDOW.clearProperty(PROPERTY_COUNT)
	HOME_WINDOW.clearProperty(PROPERTY_YEARS)
	HOME_WINDOW.clearProperty(PROPERTY_RUNTIME)


def clear_properties():
	clear_set_properties()
	HOME_WINDOW.clearProperty(PROPERTY_GENRES)
	HOME_WINDOW.clearProperty(PROPERTY_ARTIST_ALBUMS)
	HOME_WINDOW.clearProperty(PROPERTY_ARTIST_TRACKS)
	HOME_WINDOW.clearProperty(PROPERTY_ALBUM_TRACKS)


def limited_genres(label, limit=2):
	"""Return the first distinct genres from Kodi's display label."""
	if limit <= 0 or not label:
		return ""
	genres = []
	seen = set()
	for genre in GENRE_SPLIT_RE.split(label):
		genre = " ".join(genre.split())
		genre = GENRE_ABBREVIATIONS.get(genre.casefold(), genre)
		key = genre.casefold()
		if genre and key not in seen:
			genres.append(genre)
			seen.add(key)
			if len(genres) == limit:
				break
	return " / ".join(genres[:limit])


def focused_genre_label():
	"""Read genres from the active Flix list or focused Home widget."""
	if xbmc.getCondVisibility("Window.IsActive(home) + Control.HasFocus(5800)"):
		return xbmc.getInfoLabel("Container(5800).ListItem.Genre")
	if xbmc.getCondVisibility("Window.IsActive(home) + Control.HasFocus(5900)"):
		return xbmc.getInfoLabel("Container(5900).ListItem.Genre")
	return xbmc.getInfoLabel("Control.GetLabel({})".format(GENRE_CONTROL))


def formatted_stats(movies):
	count = len(movies)
	count_label = "{} {}".format(count, "Movie" if count == 1 else "Movies")

	years = sorted(
		int(movie.get("year", 0))
		for movie in movies
		if int(movie.get("year", 0) or 0) > 0
	)
	if not years:
		years_label = ""
	elif years[0] == years[-1]:
		years_label = str(years[0])
	else:
		years_label = "{}\u2013{}".format(years[0], years[-1])

	total_seconds = sum(int(movie.get("runtime", 0) or 0) for movie in movies)
	total_minutes = total_seconds // 60
	hours = total_minutes // 60
	minutes = total_minutes % 60
	if not hours:
		runtime_label = "{} MIN".format(minutes)
	elif hours == 1:
		runtime_label = "1 HR {} MIN".format(minutes)
	else:
		runtime_label = "{} HRS {} MIN".format(hours, minutes)
	return count_label, years_label, runtime_label


def movie_set_movies(set_id):
	request = {
		"jsonrpc": "2.0",
		"id": 1,
		"method": "VideoLibrary.GetMovieSetDetails",
		"params": {
			"setid": set_id,
			"properties": [],
			"movies": {
				"properties": ["year", "runtime"],
				"limits": {"start": 0, "end": 10000},
			},
		},
	}
	response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
	return response.get("result", {}).get("setdetails", {}).get("movies", [])


def artist_album_count(artist_id):
	request = {
		"jsonrpc": "2.0",
		"id": 1,
		"method": "AudioLibrary.GetAlbums",
		"params": {
			"properties": [],
			"limits": {"start": 0, "end": 10000},
			"filter": {"artistid": artist_id},
		},
	}
	response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
	return len(response.get("result", {}).get("albums", []))


def artist_track_count(artist_id):
	request = {
		"jsonrpc": "2.0",
		"id": 1,
		"method": "AudioLibrary.GetSongs",
		"params": {
			"properties": [],
			"limits": {"start": 0, "end": 10000},
			"filter": {"artistid": artist_id},
		},
	}
	response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
	return len(response.get("result", {}).get("songs", []))


def album_track_count(album_id):
	request = {
		"jsonrpc": "2.0",
		"id": 1,
		"method": "AudioLibrary.GetSongs",
		"params": {
			"properties": [],
			"limits": {"start": 0, "end": 10000},
			"filter": {"albumid": album_id},
		},
	}
	response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
	return len(response.get("result", {}).get("songs", []))


def all_movie_set_stats():
	request = {
		"jsonrpc": "2.0",
		"id": 1,
		"method": "VideoLibrary.GetMovies",
		"params": {
			"properties": ["setid", "year", "runtime"],
			"limits": {"start": 0, "end": 100000},
		},
	}
	response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
	movies_by_set = {}
	for movie in response.get("result", {}).get("movies", []):
		set_id = int(movie.get("setid", 0) or 0)
		if set_id > 0:
			movies_by_set.setdefault(set_id, []).append(movie)
	return {
		set_id: formatted_stats(movies)
		for set_id, movies in movies_by_set.items()
	}


class SetStatsService(xbmc.Monitor):
	def __init__(self):
		super().__init__()
		self.previous_set_id = None
		self.previous_genre_label = None
		self.previous_artist_id = None
		self.previous_album_id = None
		self.cache = {}
		self.cache_loaded = False
		self.cache_dirty = False
		self.cache_dirty_since = 0.0

	def onNotification(self, _sender, method, _data):
		if method in (
			"VideoLibrary.OnUpdate",
			"VideoLibrary.OnRemove",
			"VideoLibrary.OnScanFinished",
			"VideoLibrary.OnCleanFinished",
		):
			self.cache_dirty = True
			self.cache_dirty_since = time.monotonic()

	def refresh_dirty_cache(self):
		if not self.cache_dirty:
			return
		if (
			time.monotonic() - self.cache_dirty_since
			< LIBRARY_UPDATE_DEBOUNCE_SECONDS
		):
			return
		self.cache = {}
		self.cache_loaded = False
		self.cache_dirty = False
		self.previous_set_id = None

	def preload_cache(self):
		try:
			self.cache.update(all_movie_set_stats())
		except Exception as error:
			xbmc.log(
				"Kodiflix set statistics preload failed: {}".format(error),
				xbmc.LOGERROR,
			)
		self.cache_loaded = True

	def publish(self, set_id):
		if set_id not in self.cache:
			self.cache[set_id] = formatted_stats(movie_set_movies(set_id))
		count_label, years_label, runtime_label = self.cache[set_id]
		HOME_WINDOW.setProperty(PROPERTY_COUNT, count_label)
		HOME_WINDOW.setProperty(PROPERTY_YEARS, years_label)
		HOME_WINDOW.setProperty(PROPERTY_RUNTIME, runtime_label)

	def run(self):
		while not self.abortRequested():
			if xbmc.getSkinDir() != SUPPORTED_SKIN:
				clear_properties()
				self.previous_set_id = None
				self.previous_genre_label = None
				self.cache_loaded = False
				self.waitForAbort(2)
				continue

			if not xbmc.getCondVisibility(FLIX_ACTIVE_CONDITION):
				# Keep the last capped genre while a customise/settings dialog is
				# displayed over Flix. Reading Control.GetLabel() from the dialog
				# would return empty and expose Kodi's uncapped ListItem.Genre.
				if xbmc.getCondVisibility(FLIX_DIALOG_OVERLAY_CONDITION):
					self.waitForAbort(ACTIVE_POLL_SECONDS)
					continue
				if (
					self.previous_set_id is not None
					or self.previous_genre_label is not None
				):
					# Set-only statistics are view-specific, but the capped genre must
					# survive focus/window transitions such as opening Customise.
					clear_set_properties()
				self.previous_set_id = None
				self.previous_genre_label = None
				self.previous_artist_id = None
				self.previous_album_id = None
				self.waitForAbort(IDLE_POLL_SECONDS)
				continue

			self.refresh_dirty_cache()
			if not self.cache_loaded:
				self.preload_cache()

			db_type = xbmc.getInfoLabel(
				"Control.GetLabel({})".format(SET_TYPE_CONTROL)
			).lower() or xbmc.getInfoLabel("ListItem.DBType").lower()
			if xbmc.getCondVisibility("Window.IsActive(music) + Container.Content(albums)"):
				db_type = "album"
			genre_label = focused_genre_label()
			if genre_label != self.previous_genre_label:
				self.previous_genre_label = genre_label
				trimmed_genres = limited_genres(genre_label)
				if trimmed_genres:
					HOME_WINDOW.setProperty(PROPERTY_GENRES, trimmed_genres)
				else:
					HOME_WINDOW.clearProperty(PROPERTY_GENRES)
			set_id_label = xbmc.getInfoLabel(
				"Control.GetLabel({})".format(SET_ID_CONTROL)
			)
			if db_type in ("artist", "album") and not set_id_label:
				set_id_label = xbmc.getInfoLabel("ListItem.DBID")
			try:
				artist_id = int(set_id_label) if db_type == "artist" else None
			except (TypeError, ValueError):
				artist_id = None
			if artist_id != self.previous_artist_id:
				self.previous_artist_id = artist_id
				HOME_WINDOW.clearProperty(PROPERTY_ARTIST_ALBUMS)
				HOME_WINDOW.clearProperty(PROPERTY_ARTIST_TRACKS)
				if artist_id is not None:
					try:
						album_count = artist_album_count(artist_id)
						if album_count:
							label = "{} ALBUM{}".format(
								album_count, "" if album_count == 1 else "S"
							)
							HOME_WINDOW.setProperty(PROPERTY_ARTIST_ALBUMS, label)
						track_count = artist_track_count(artist_id)
						if track_count:
							label = "{} TRACK{}".format(
								track_count, "" if track_count == 1 else "S"
							)
							HOME_WINDOW.setProperty(PROPERTY_ARTIST_TRACKS, label)
					except Exception as error:
						xbmc.log(
							"Kodiflix artist library counts failed: {}".format(error),
							xbmc.LOGWARNING,
						)
			try:
				album_id = int(set_id_label) if db_type == "album" else None
			except (TypeError, ValueError):
				album_id = None
			if db_type == "album":
				# During a view refresh Kodi can briefly expose an empty ID. Keep the
				# last valid count through that transition instead of flashing it away.
				if album_id is not None and album_id != self.previous_album_id:
					self.previous_album_id = album_id
					HOME_WINDOW.clearProperty(PROPERTY_ALBUM_TRACKS)
					try:
						track_count = album_track_count(album_id)
						if track_count:
							label = "{} TRACK{}".format(
								track_count, "" if track_count == 1 else "S"
							)
							HOME_WINDOW.setProperty(PROPERTY_ALBUM_TRACKS, label)
					except Exception as error:
						xbmc.log(
							"Kodiflix album track count failed: {}".format(error),
							xbmc.LOGWARNING,
						)
			elif db_type and self.previous_album_id is not None:
				# A confirmed non-album item means the old album count is no longer
				# relevant. Empty metadata is intentionally ignored above.
				self.previous_album_id = None
				HOME_WINDOW.clearProperty(PROPERTY_ALBUM_TRACKS)
			try:
				set_id = int(set_id_label) if db_type == "set" else None
			except (TypeError, ValueError):
				set_id = None

			if set_id != self.previous_set_id:
				self.previous_set_id = set_id
				if set_id is None:
					clear_set_properties()
				else:
					try:
						self.publish(set_id)
					except Exception as error:
						clear_set_properties()
						xbmc.log(
							"Kodiflix set statistics failed: {}".format(error),
							xbmc.LOGERROR,
						)

			self.waitForAbort(ACTIVE_POLL_SECONDS)


if __name__ == "__main__":
	apply_video_library_preferences()
	SetStatsService().run()
