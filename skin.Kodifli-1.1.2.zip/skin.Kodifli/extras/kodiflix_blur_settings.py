import sys

import xbmc
import xbmcgui


DEFAULT_RADIUS = "30"
DEFAULT_SATURATION = "1.5"


def skin_value(name, default):
    return xbmc.getInfoLabel("Skin.String({})".format(name)) or default


def set_skin_value(name, value):
    xbmc.executebuiltin("Skin.SetString({},{})".format(name, value))


def set_radius():
    current = skin_value("Kodiflix.BlurRadius", DEFAULT_RADIUS)
    value = xbmcgui.Dialog().numeric(0, "Enter blur radius value", current)
    if value == "":
        value = DEFAULT_RADIUS
    set_skin_value("Kodiflix.BlurRadius", value)


def set_saturation():
    current = skin_value("Kodiflix.BlurSaturation", DEFAULT_SATURATION)
    keyboard = xbmc.Keyboard(current, "Enter blur saturation value")
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return

    value = keyboard.getText().strip() or DEFAULT_SATURATION
    try:
        if float(value) < 0:
            raise ValueError
    except ValueError:
        xbmcgui.Dialog().notification(
            "Flix customisation",
            "Saturation must be zero or a positive number",
            xbmcgui.NOTIFICATION_ERROR,
        )
        return

    set_skin_value("Kodiflix.BlurSaturation", value)


if __name__ == "__main__" and len(sys.argv) > 1:
    if sys.argv[1] == "radius":
        set_radius()
    elif sys.argv[1] == "saturation":
        set_saturation()
