"""Reuse the Tracks blur pipeline/cache without depending on browser controls."""
import os
import importlib.util
import time

import xbmc
import xbmcaddon
import xbmcvfs

PROPERTY = "kodiflix.playback.blurred"
COLOR_PROPERTY = "kodiflix.playback.cover_color"


class PlaybackBlur:
    def __init__(self, window):
        self.window = window
        self.helper = None
        self.key = None
        self.retry_at = 0

    def update(self):
        if not xbmc.getCondVisibility("System.AddonIsEnabled(script.kodiflix.helper) + [!Skin.HasSetting(flix_disable_background_blur) | Skin.HasSetting(flix_adaptive_focus_glow)]"):
            self.clear()
            return
        if xbmc.getCondVisibility("Skin.HasSetting(KodiflixMusicVisualiserBackground) + Visualisation.Enabled + Window.IsVisible(visualisation)"):
            self.clear()
            return
        source = xbmc.getInfoLabel("Player.Art(album.thumb)") or xbmc.getInfoLabel("MusicPlayer.Cover")
        saturation = xbmc.getInfoLabel("Skin.String(Kodiflix.BlurSaturation)")
        token = self.window.getProperty("kodiflix.helper.cache_token")
        adaptive = xbmc.getCondVisibility("Skin.HasSetting(flix_adaptive_focus_glow)")
        key = (source, saturation, token, self.helper.source_stamp(source) if self.helper else "", adaptive)
        if key != self.key:
            self.window.clearProperty(COLOR_PROPERTY)
        if not source or key == self.key or time.monotonic() < self.retry_at:
            return
        try:
            if self.helper is None:
                addon = xbmcaddon.Addon("script.kodiflix.helper")
                script = os.path.join(addon.getAddonInfo("path"), "resources", "lib", "artwork_cache.py")
                spec = importlib.util.spec_from_file_location("kodiflix_artwork_cache", xbmcvfs.translatePath(script))
                self.helper = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(self.helper)
                key = (source, saturation, token, self.helper.source_stamp(source), adaptive)
            amount = self.helper.setting_number("Kodiflix.BlurSaturation", self.helper.DEFAULT_SATURATION, float)
            path = self.helper.create_blur(source, 3, amount)
            if not path:
                raise ValueError("Album artwork could not be opened")
            if (self.window.getProperty("kodiflix.helper.cache_token") != token
                    or (xbmc.getInfoLabel("Player.Art(album.thumb)") or xbmc.getInfoLabel("MusicPlayer.Cover")) != source
                    or xbmc.getCondVisibility("Skin.HasSetting(KodiflixMusicVisualiserBackground) + Visualisation.Enabled + Window.IsVisible(visualisation)")):
                return
            # Never substitute sharp artwork while a new derivative is being made.
            self.window.setProperty(PROPERTY, path)
            if adaptive:
                self.window.setProperty(COLOR_PROPERTY, self.helper.image_colors(path)[0])
            self.key = key
            self.retry_at = 0
        except Exception as error:
            xbmc.log("Kodiflix playback blur: {}".format(error), xbmc.LOGWARNING)
            self.retry_at = time.monotonic() + 5

    def clear(self):
        self.window.clearProperty(PROPERTY)
        self.window.clearProperty(COLOR_PROPERTY)
        self.key = None
        self.retry_at = 0
