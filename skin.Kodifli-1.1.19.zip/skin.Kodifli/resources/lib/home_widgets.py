"""Widget catalogue and configuration rules. No Kodi imports: easy to validate."""
from copy import deepcopy
import json
from urllib.parse import quote, unquote

MAX_WIDGETS = 6
ITEM_COUNTS = (10, 15, 20, 30)
SECTIONS = ("movies", "tvshows", "music", "programs")
SECTION_LABELS = ("Movies", "TV shows", "Music", "Programs")
PREFIX = "Kodiflix.Widgets"


def option(key, title, path, description):
    return {"id": key, "title": title, "path": path, "description": description}


def playlist(section, key):
    return "special://skin/playlists/widgets/{}_{}.xsp".format(section, key)


CATALOGUE = {
    "movies": [
        option("all", "All movies", "videodb://movies/titles/", "Your movie library, in alphabetical order."),
        option("fullscreen", "All movies (fullscreen)", "videodb://movies/titles/", "The original full-library movie widget, expanding into the fullscreen artwork view."),
        option("continue", "Continue watching", playlist("movies", "continue"), "Movies you have started and can resume."),
        option("recent", "Recently added", playlist("movies", "recent"), "The latest additions to your movie library."),
        option("unwatched", "Unwatched movies", playlist("movies", "unwatched"), "Movies you have not watched yet, newest first."),
        option("watched", "Recently watched", playlist("movies", "watched"), "Watched movies, ordered by when you last played them."),
        option("rated", "Top rated", playlist("movies", "rated"), "Movies with library ratings, highest first."),
        option("random", "Random movies", playlist("movies", "random"), "A random selection from your library."),
        option("sets", "Movie collections", "videodb://movies/sets/", "Browse your movie collections."),
        option("genres", "Genres", "videodb://movies/genres/", "Browse your movies by genre."),
    ],
    "tvshows": [
        option("all", "All shows", "videodb://tvshows/titles/", "Your TV show library, in alphabetical order."),
        option("fullscreen", "All shows (fullscreen)", "videodb://tvshows/titles/", "The original full-library TV widget, expanding into the fullscreen artwork view."),
        option("continue", "Continue watching episodes", playlist("tvshows", "continue"), "Episodes you have started and can resume."),
        option("next", "Next episode", "plugin://skin.Kodifli/?action=next", "The first unwatched regular episode of each show you have started. Specials are excluded."),
        option("recentepisodes", "Recently added episodes", playlist("tvshows", "recentepisodes"), "The latest episodes added to your library."),
        option("recentshows", "Recently added shows", playlist("tvshows", "recentshows"), "TV shows ordered by when they were added."),
        option("unwatched", "Unwatched shows", "special://skin/playlists/unwatched_tvshows.xsp", "Shows with no watched episodes."),
        option("watched", "Recently watched episodes", playlist("tvshows", "watched"), "Watched episodes, ordered by when you last played them."),
        option("random", "Random shows", playlist("tvshows", "random"), "A random selection of TV shows."),
    ],
    "music": [
        option("played", "Recently played albums", playlist("music", "played"), "Albums you have listened to recently."),
        option("recent", "Recently added albums", playlist("music", "recent"), "The latest additions to your music library."),
        option("most", "Most played albums", "special://skin/playlists/mostplayed_albums.xsp", "Your most played albums."),
        option("random", "Random albums", "special://skin/playlists/random_albums.xsp", "A random selection of albums."),
        option("unplayed", "Unplayed albums", "special://skin/playlists/unplayed_albums.xsp", "Albums you have not played yet."),
        option("rated", "Top rated albums", playlist("music", "rated"), "Albums with user ratings, highest first."),
        option("artists", "Artists", "musicdb://artists/", "Browse the artists in your library."),
        option("genres", "Genres", "musicdb://genres/", "Browse your music by genre."),
    ],
    "programs": [
        dict(option("categories", "Categories", "addons://", "Add-on management shortcuts, including repositories and ZIP installation."), target="addonbrowser"),
        dict(option("video", "Video add-ons", "addons://sources/video/", "Installed video add-ons."), target="videos"),
        dict(option("audio", "Music add-ons", "addons://sources/audio/", "Installed music add-ons."), target="music"),
        dict(option("programs", "Program add-ons", "addons://sources/executable/", "Installed program add-ons."), target="programs"),
        dict(option("games", "Game add-ons", "addons://sources/game/", "Installed game add-ons."), target="games"),
        dict(option("pictures", "Picture add-ons", "addons://sources/image/", "Installed picture add-ons."), target="pictures"),
        dict(option("android", "Android apps", "androidapp://sources/apps/", "Installed Android apps; available on Android devices."), target="programs"),
    ],
}
DEFAULT_IDS = {"movies": ("continue", "recent", "all"),
               "tvshows": ("continue", "next", "recentepisodes"),
               "music": ("played", "recent", "most"),
               "programs": ("categories", "video", "audio")}
PLAYLIST_TYPES = {"movies": {"movies"}, "tvshows": {"tvshows", "episodes"},
                  "music": {"albums", "artists", "songs"}}


def defaults(section):
    choices = {entry["id"]: entry for entry in CATALOGUE[section]}
    return [deepcopy(choices[key]) for key in DEFAULT_IDS[section]]


def widget_settings(section, entry):
    """Validated appearance values; fullscreen library rails are fixed."""
    if entry.get("id") == "fullscreen":
        return {"artwork": "thumbs", "limit": None, "progress": False}
    count = entry.get("limit", 15)
    if type(count) is not int or count not in ITEM_COUNTS:
        count = 15
    artwork = "posters" if section != "music" and entry.get("artwork") == "posters" else ("covers" if section == "music" else "thumbs")
    if section == "programs":
        artwork = "icons"
    progress = entry.get("progress", True)
    return {"artwork": artwork, "limit": count,
            "progress": (progress if isinstance(progress, bool) else True) if entry.get("id") == "continue" else False}


def normalise(section, entries):
    """Reject broken/stale entries, duplicates and oversized saved lists."""
    if not isinstance(entries, list):
        return defaults(section)
    choices = {entry["id"]: entry for entry in CATALOGUE[section]}
    result, seen = [], set()
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        key = entry.get("id")
        saved = entry
        if not isinstance(key, str):
            continue
        if key == "custom":
            if section == "programs":
                continue
            path, title = entry.get("path", ""), entry.get("title", "")
            if not isinstance(path, str) or not path.lower().endswith(".xsp") or not isinstance(title, str):
                continue
            if any(c in path + title for c in '\"\r\n'):
                continue
            entry = option("custom", title[:100] or "Custom playlist", path, "Your custom smart playlist.")
            identity = path
        elif key in choices:
            entry, identity = choices[key], key
        else:
            continue
        if identity not in seen:
            entry = deepcopy(entry)
            settings = widget_settings(section, saved)
            if key != "fullscreen":
                for name in ("artwork", "limit", "progress"):
                    if name in saved and (name != "progress" or key == "continue"):
                        entry[name] = settings[name]
            result.append(entry)
            seen.add(identity)
        if len(result) == MAX_WIDGETS:
            break
    return result


def encode(entries):
    return quote(json.dumps(entries, ensure_ascii=False, separators=(",", ":")), safe="")


def decode(section, value):
    if not value:
        return defaults(section)
    try:
        return normalise(section, json.loads(unquote(value)))
    except (ValueError, TypeError):
        return defaults(section)


def next_episodes(episodes, limit=15):
    """One first unwatched regular episode per started show, most recently played first."""
    shows = {}
    for episode in episodes:
        if episode.get("season", 0) <= 0 or episode.get("episode", 0) <= 0:
            continue
        shows.setdefault(episode["tvshowid"], []).append(episode)
    result = []
    for rows in shows.values():
        started = [row for row in rows if row.get("playcount", 0) > 0 or row.get("resume", {}).get("position", 0) > 0]
        if not started:
            continue
        unwatched = [row for row in rows if not row.get("playcount", 0)]
        if unwatched:
            row = min(unwatched, key=lambda item: (item["season"], item["episode"]))
            result.append((max((item.get("lastplayed", "") for item in started), default=""), row))
    return [row for _, row in sorted(result, key=lambda item: item[0], reverse=True)][:limit]
