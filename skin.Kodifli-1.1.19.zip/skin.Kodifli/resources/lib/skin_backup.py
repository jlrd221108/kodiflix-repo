"""Portable, validated Kodiflix archives. No Kodi imports or archive extraction."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import io
import json
import re
from urllib.parse import quote, unquote, urlsplit, urlunsplit, parse_qsl, urlencode
import zipfile

FORMAT = "kodiflix-settings"
VERSION = 1
ADDON_ID = "skin.Kodifli"
ASSET_PREFIX = "kodiflix-backup://"
MAX_BYTES = 128 * 1024 * 1024
MAX_FILE_BYTES = 32 * 1024 * 1024
MAX_SETTINGS = 32768  # Original MQ5's twenty menu/submenu slots exceed 4096 keys.
NAME = re.compile(r"^[A-Za-z0-9_.-]{1,200}$")
ASSET_NAME = re.compile(r"^assets/[0-9]{4}\.(xsp|png|jpg|jpeg|webp|gif|bmp|tbn)$")
CATEGORIES = ("basics", "kodiflix", "views", "widgets")
CATEGORY_LABELS = ("Basics", "Kodiflix settings", "View customisation", "Widget customisation")


def sensitive(name):
    return bool(re.search(r"api.?key|password|secret|token|credential|^mdblist_key_migrated$", name, re.I))


def category(name):
    name = name.lower()
    if name.startswith("kodiflix.backup."):
        return None  # Backup preferences stay local to this device.
    if name == "kodiflix.home.mq5" or name.startswith(("kodiflix.mq5.", "kodiflix.homemenu.")):
        return "basics"  # Both Home styles travel with general/home preferences.
    if name.startswith("kodiflix.widgets."):
        return "widgets"
    if (name.startswith(("flix_", "view_", "kodiflix.blur", "kodiflix.agerating", "kodiflix.default"))
            and name != "kodiflix.defaultsversion") or name in (
                "kodiflix.flixthumbsettingsmigrated", "hide_mediaflags", "show_musicvideoposter",
                "circle_userrating", "circle_rating", "circle_none"):
        return "views"
    if name.startswith(("kodiflix", "mdblist_")):
        return "kodiflix"
    return "basics"


def scrub_credentials(value):
    """Remove authentication embedded in source URLs when sensitive data is excluded."""
    if "://" not in value:
        return value
    try:
        parsed = urlsplit(value)
        netloc = parsed.netloc.rsplit("@", 1)[-1]
        query = [(key, item) for key, item in parse_qsl(parsed.query, keep_blank_values=True)
                 if not sensitive(key)]
        if netloc == parsed.netloc and len(query) == len(parse_qsl(parsed.query, keep_blank_values=True)):
            return value
        return urlunsplit((parsed.scheme, netloc, parsed.path, urlencode(query), parsed.fragment))
    except ValueError:
        return value


def selected_rows(rows, categories, include_sensitive, addon=False):
    return [row for row in rows if ("kodiflix" if addon else category(row["id"])) in categories
            and (include_sensitive or not sensitive(row["id"]))]


def map_value(value, transform):
    """Also map paths inside widget JSON, including its percent-encoded form."""
    if isinstance(value, list):
        return [map_value(item, transform) for item in value]
    if isinstance(value, dict):
        return {key: map_value(item, transform) for key, item in value.items()}
    if not isinstance(value, str):
        return value
    decoded = unquote(value)
    if decoded.startswith(("[", "{")):
        try:
            parsed = json.loads(decoded)
        except ValueError:
            pass
        else:
            mapped = json.dumps(map_value(parsed, transform), ensure_ascii=False, separators=(",", ":"))
            return quote(mapped, safe="") if decoded != value else mapped
    return transform(value)


def portable_path(value, roots):
    for special, local in sorted(roots.items(), key=lambda item: len(item[1]), reverse=True):
        base = local.replace("\\", "/").rstrip("/")
        path = value.replace("\\", "/")
        if path.lower() == base.lower() or path.lower().startswith(base.lower() + "/"):
            return special.rstrip("/") + path[len(base):]
    if value.startswith("\\\\"):
        return "smb:" + value.replace("\\", "/")
    return value


def foreign_path(value):
    return bool(re.match(r"^[A-Za-z]:[\\/]|^/(?!/)", value))


def validate_settings(rows):
    if not isinstance(rows, list) or len(rows) > MAX_SETTINGS:
        raise ValueError("Invalid settings list")
    seen = set()
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("id"), str) or not NAME.fullmatch(row["id"]):
            raise ValueError("Invalid setting name")
        identity = row["id"].lower()
        if identity in seen:
            raise ValueError("Duplicate setting name")
        seen.add(identity)
        kind, value = row.get("type"), row.get("value")
        if kind == "bool":
            valid = type(value) is bool
        elif kind == "string":
            valid = isinstance(value, str) and len(value) <= 1024 * 1024 and "\x00" not in value
        else:
            valid = False
        if not valid:
            raise ValueError("Invalid setting value")


def pack(settings, addon_settings, files, skin_version, selection=None):
    manifest = {
        "format": FORMAT, "version": VERSION, "skin": ADDON_ID,
        "skin_version": skin_version,
        "created": datetime.now(timezone.utc).isoformat(),
        "settings": settings, "addon_settings": addon_settings,
        "files": [{"path": path, "size": len(data), "sha256": hashlib.sha256(data).hexdigest()}
                  for path, data in sorted(files.items())],
    }
    if selection is not None:
        manifest["selection"] = selection
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False))
        for path, data in files.items():
            archive.writestr(path, data)
    result = output.getvalue()
    unpack(result)  # Never export an archive our restorer cannot validate.
    return result


def unpack(data):
    if len(data) > MAX_BYTES:
        raise ValueError("Backup is too large")
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        entries = archive.infolist()
        names = [item.filename for item in entries]
        if len(entries) > 2048 or len(names) != len(set(names)):
            raise ValueError("Invalid or duplicate archive entries")
        if sum(item.file_size for item in entries) > MAX_BYTES:
            raise ValueError("Unpacked backup is too large")
        if any(item.file_size > MAX_FILE_BYTES or item.flag_bits & 1 for item in entries):
            raise ValueError("Invalid or oversized archive entry")
        if "manifest.json" not in names:
            raise ValueError("This is not a Kodiflix backup")
        manifest = json.loads(archive.read("manifest.json"))
        if not isinstance(manifest, dict) or manifest.get("format") != FORMAT or manifest.get("skin") != ADDON_ID:
            raise ValueError("This is not a Kodiflix backup")
        if type(manifest.get("version")) is not int or manifest["version"] != VERSION:
            raise ValueError("This backup format is not supported")
        validate_settings(manifest.get("settings"))
        validate_settings(manifest.get("addon_settings"))
        selection = manifest.get("selection")
        if selection is not None:
            if (not isinstance(selection, dict) or not isinstance(selection.get("categories"), list)
                    or not selection["categories"] or any(item not in CATEGORIES for item in selection["categories"])
                    or type(selection.get("sensitive")) is not bool):
                raise ValueError("Invalid backup selection")
        records = manifest.get("files")
        if not isinstance(records, list) or len(records) > 2047:
            raise ValueError("Invalid backup file list")
        files = {}
        for entry in records:
            if not isinstance(entry, dict) or not isinstance(entry.get("path"), str) or not ASSET_NAME.fullmatch(entry["path"]):
                raise ValueError("Unsafe backup file path")
            path = entry["path"]
            if path in files or path not in names:
                raise ValueError("Missing or duplicate backup file")
            payload = archive.read(path)
            if len(payload) != entry.get("size") or hashlib.sha256(payload).hexdigest() != entry.get("sha256"):
                raise ValueError("Backup file failed its integrity check")
            files[path] = payload
        if set(names) != {"manifest.json", *files}:
            raise ValueError("Unexpected files in backup")
        return manifest, files


def restore_values(manifest, locations):
    restored = deepcopy(manifest)

    def resolve(value):
        if value.startswith(ASSET_PREFIX):
            path = value[len(ASSET_PREFIX):]
            if path not in locations:
                raise ValueError("A referenced file is missing from the backup")
            return locations[path]
        return value

    for row in restored["settings"] + restored["addon_settings"]:
        row["value"] = map_value(row["value"], resolve)
    return restored


def quoted(value):
    """Quote one Kodi builtin argument, preserving slashes, commas and quotes."""
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def commands(settings):
    validate_settings(settings)
    result = []  # Partial restores must never clear unrelated settings or credentials.
    for row in settings:
        if row["type"] == "bool":
            result.append("Skin.SetBool({},{})".format(row["id"], str(row["value"]).lower()))
        else:
            result.append("Skin.SetString({},{})".format(row["id"], quoted(row["value"])))
    return result
