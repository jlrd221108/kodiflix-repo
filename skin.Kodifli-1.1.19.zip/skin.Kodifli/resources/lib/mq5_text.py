"""Display-only casing for MQ5 settings, never stored preference values."""
import re


def sentence_case(value):
    if not re.sub(r"\[[^\]]*\]", "", value).isupper():
        return value
    parts = re.split(r"(\[[^\]]*\])", value)
    first = True
    for index in range(0, len(parts), 2):
        part = parts[index].lower()
        if first and re.search(r"[^\W\d_]", part):
            part = re.sub(r"[^\W\d_]", lambda m: m[0].upper(), part, count=1)
            first = False
        part = re.sub(r"\b(tv|pvr|osd|dvd|cd|cpu|ram|hdr|usb|url|rss)\b", lambda m: m[0].upper(), part, flags=re.I)
        parts[index] = part
    return "".join(parts).replace("[UPPERCASE]", "").replace("[/UPPERCASE]", "")
