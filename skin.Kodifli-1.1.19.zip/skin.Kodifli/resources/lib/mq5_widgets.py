"""MQ5 widget data owned by Kodiflix, using native Kodi JSON-RPC only.

The existing provider supplies bounded reads, event coalescing and diff writes.
This layer adds progress/next-episode lists and native smart-playlist queries.
Runtime properties use a private prefix, never another add-on's global keys.
"""
import re
import random

from mq5_providers import (MQ5Providers, SUPPORTED_FAMILIES, RECOMMENDATION_FAMILIES,
                           _VIDEO, _AUDIO, _FIELDS, item_properties, _text)

WIDGET_PREFIX = "Kodiflix.MQ5.Widget."


def rewrite_widget_actions(text):
    """Used during port generation and when migrating the installed runtime."""
    text = text.replace("RunScript(script.randomandlastitems,",
                        "RunScript(special://skin/extras/kodiflix_mq5_service.py,refresh,")
    text = text.replace("System.AddonIsEnabled(script.randomandlastitems)", "true")
    families = "|".join(SUPPORTED_FAMILIES + RECOMMENDATION_FAMILIES + ("RandomAddon",))
    return re.sub(r"(?i)(Property\()((?:" + families + r"|Playlist(?:Last|Random)(?:Movie|Episode|MusicVideo|Music)(?:vpl|apl)\d+)\.)",
                  lambda match: match[1] + WIDGET_PREFIX + match[2], text)


def widget_properties(kind, row):
    values = item_properties(kind, row)
    values["Userrating"] = _text(row.get("userrating", ""))
    values["Art(thumb)"] = values["Art(thumb)"] or values["Thumb"]
    if kind == "Album":
        values["Thumb"] = values["Thumb"] or (row.get("art") or {}).get("thumb", "")
    # Library identifiers retain native playback/resume semantics on all platforms.
    for name in ("movieid", "episodeid", "musicvideoid", "albumid", "songid"):
        identifier = row.get(name)
        if isinstance(identifier, int) and not isinstance(identifier, bool):
            values["Play"] = "RunScript(special://skin/extras/kodiflix_mq5_service.py,play,{},{}{})".format(
                name, identifier, ",resume" if kind in ("Movie", "Episode") else "")
            break
    return values


class NativeWidgets(MQ5Providers):
    def __init__(self, rpc, publish, clear, *, playlists=lambda: (), **kwargs):
        super().__init__(rpc, publish, clear, external_provider=False, **kwargs)
        self.owned_families = frozenset(SUPPORTED_FAMILIES + RECOMMENDATION_FAMILIES + ("RandomAddon",))
        self.external_families = frozenset()
        self.unsupported_contracts = {}
        self.playlists = playlists
        self.playlist_families = set()

    def _owns(self, family):
        return family in self.owned_families or family in self.playlist_families

    def _release_collisions(self, domain=None):
        # The caller wraps writes in our private namespace and holds a lease.
        # No external provider can take ownership of these widget properties.
        pass

    def _flatten(self, prefix, kind, rows, fields=None):
        fields = fields or _FIELDS[kind].split()
        if prefix.startswith("Playlist"):
            fields = list(widget_properties(kind, {}).keys())
        return {"{}.{}.{}".format(prefix, index, field): values.get(field, "")
                for index, row in enumerate(rows[:self.item_limit], 1)
                for values in (widget_properties(kind, row),) for field in fields}

    def _recommended(self, kind):
        if kind == "Episode":
            response = self._call("VideoLibrary.GetTVShows", {
                "properties": ["title"], "limits": {"end": self.item_limit},
                "sort": {"method": "lastplayed", "order": "descending"},
                "filter": {"field": "inprogress", "operator": "true", "value": ""}})
            rows = []
            for show in response.get("tvshows", []):
                episodes = self._call("VideoLibrary.GetEpisodes", {
                    "tvshowid": show["tvshowid"], "properties": _VIDEO["Episode"][2],
                    "limits": {"end": 1}, "sort": {"method": "episode", "order": "ascending"},
                    "filter": {"field": "playcount", "operator": "is", "value": "0"}})
                rows.extend(self._enrich_episode(row) for row in episodes.get("episodes", []))
        else:
            plural, key, fields = (_AUDIO if kind == "Album" else _VIDEO)[kind]
            params = {"properties": fields, "limits": {"end": self.item_limit},
                      "sort": {"method": "playcount", "order": "descending"}}
            if kind == "Movie":
                params["sort"]["method"] = "lastplayed"
                params["filter"] = {"field": "inprogress", "operator": "true", "value": ""}
            response = self._call(("AudioLibrary." if kind == "Album" else "VideoLibrary.") + "Get" + plural, params)
            rows = response.get(key, [])
        return self._flatten("Recommended" + kind, kind, rows)

    def _playlist(self, config):
        # Kodi resolves .xsp rules, nested playlists and network paths itself.
        kind, path, slot, mode, progress = config
        show_playlist = kind == "TVShow"
        kind = "Episode" if show_playlist else kind
        domain = "music" if kind in ("Album", "Song") else "video"
        prefix = "Playlist" + mode + ("Music" if domain == "music" else kind) + slot
        self.playlist_families.add(prefix)
        fields = (_AUDIO if domain == "music" else _VIDEO)[kind][2]
        params = {"directory": path, "media": domain,
                  "properties": list(dict.fromkeys(fields + ["dateadded"])),
                  "limits": {"start": 0, "end": 100 if progress or show_playlist else self.item_limit},
                  "sort": {"method": "random" if mode == "Random" else "dateadded", "order": "descending"}}
        episode_sort = dict(params["sort"])
        if show_playlist:
            params["sort"] = {"method": "label", "order": "ascending"}
        rows = []
        while True:
            response = self._call("Files.GetDirectory", params)
            batch = response.get("files")
            if not isinstance(batch, list):
                raise ValueError("Playlist did not return a file list")
            if show_playlist:
                episodes = []
                for show in batch:
                    query = {"tvshowid": show["id"], "properties": params["properties"],
                             "limits": {"end": self.item_limit}, "sort": episode_sort}
                    if progress:
                        query["filter"] = {"field": "inprogress", "operator": "true", "value": ""}
                    result = self._call("VideoLibrary.GetEpisodes", query)
                    episodes.extend(dict(row, id=row.get("episodeid")) for row in result.get("episodes", []))
                rows.extend(episodes)
            else:
                rows.extend(row for row in batch if not progress or (row.get("resume") or {}).get("position", 0) > 0)
            end = params["limits"]["end"]
            total = response.get("limits", {}).get("total", end)
            if not batch or end >= total or (not show_playlist and len(rows) >= self.item_limit):
                break
            params["limits"] = {"start": end, "end": end + 100}
        if show_playlist:
            if mode == "Random":
                random.shuffle(rows)
            else:
                rows.sort(key=lambda row: row.get("dateadded", ""), reverse=True)
        # Files.GetDirectory uses id/type instead of the library method's ID field.
        rows = [dict(row, **{kind.lower() + "id": row.get("id")}) for row in rows]
        if kind == "Episode":
            rows = [self._enrich_episode(row) for row in rows[:self.item_limit]]
        return self._flatten(prefix, kind, rows)

    def _addons(self):
        result = self._call("Addons.GetAddons", {"enabled": True,
            "properties": ["name", "author", "thumbnail", "summary", "version"]})
        rows = [row for row in result.get("addons", [])
                if row.get("type") in ("xbmc.python.pluginsource", "xbmc.python.script")]
        random.shuffle(rows)
        values = {}
        for index, row in enumerate(rows[:self.item_limit], 1):
            for field, value in {"Title": row.get("name", ""), "Author": row.get("author", ""),
                "Thumb": row.get("thumbnail", ""), "Summary": row.get("summary", ""),
                "Version": row.get("version", ""), "Type": row.get("type", ""),
                "Provides": "", "Path": row.get("addonid", "")}.items():
                values[f"RandomAddon.{index}.{field}"] = _text(value)
        return values

    def notify(self, method, data=None):
        super().notify(method, data)
        if method in ("Player.OnStop", "Player.OnEnd"):
            self.mark_dirty("video")
            self.mark_dirty("music")

    def _refresh(self, domain):
        values = super()._refresh(domain)
        for kind in (("Album",) if domain == "music" else ("Movie", "Episode", "MusicVideo")):
            prefix = "Recommended" + kind
            values.update(self._family(domain, prefix, lambda kind=kind: self._recommended(kind)))
        for config in self.playlists():
            kind, path, slot, mode, progress = config
            if (kind in ("Album", "Song")) != (domain == "music"):
                continue
            prefix = "Playlist" + mode + ("Music" if domain == "music" else "Episode" if kind == "TVShow" else kind) + slot
            self.playlist_families.add(prefix)
            values.update(self._family(domain, prefix, lambda config=config: self._playlist(config)))
        if domain == "video":
            values.update(self._family(domain, "RandomAddon", self._addons))
        return values
