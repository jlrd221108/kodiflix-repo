"""Adapters for the original MQ5 home actions.

RunScript(special://skin/extras/kodiflix_mq5.py,selectbool,heading,label|key,...)

Original heading/labels 31000..31999 map to script.kodiflix.helper IDs
32000..32999 (offset +1000); other IDs belong to Kodi. Source IDs stay original.
Label-only arguments are skipped, matching Kodi's original
Skin.SelectBool. Cancellation changes nothing; no existing choice is preselected.
No settings outside the supplied, namespaced boolean group are touched.
"""
import re
import sys


PREFIX = "Kodiflix.MQ5."
HELPER_ID = "script.kodiflix.helper"
KEY = re.compile(r"[A-Za-z_][A-Za-z0-9_.-]*\Z")
TRANSPARENCY_VALUES = {
    "styleglass": ("100", "95", "85", "75", "65", "55", "45", "35", "25", "15", "05"),
    "homeglass": ("95", "85", "75", "65", "55", "45", "35", "25", "15"),
}


def select_transparency(key, current, *, select, set_string):
    values = TRANSPARENCY_VALUES[key]  # Only these two original settings are supported.
    title = "Menu artwork transparency" if key == "styleglass" else "Menu bar transparency"
    selected = select(title, [str(100 - int(value)) + "%" for value in values],
                      preselect=values.index(current) if current in values else -1)
    if type(selected) is int and 0 <= selected < len(values) and values[selected] != current:
        set_string(PREFIX + key, values[selected])
        return True
    return False


def setting_key(value):
    value = value.strip()
    if not KEY.fullmatch(value):
        raise ValueError("Invalid MQ5 boolean setting")
    if value.startswith(PREFIX):
        if not KEY.fullmatch(value[len(PREFIX):]):
            raise ValueError("Missing MQ5 boolean setting")
        return value
    if value.lower().startswith("kodiflix."):
        raise ValueError("Selector setting is outside the MQ5 namespace")
    return PREFIX + value


def localized(value, core, mq5):
    """Resolve an original numeric localization token, without skin fallback."""
    value = str(value).strip()
    if not re.fullmatch(r"[0-9]+", value):
        raise ValueError("MQ5 selector labels must be localization IDs")
    number = int(value)
    return mq5(number + 1000) if 31000 <= number <= 31999 else core(number)


def selectbool(heading, options, *, core, mq5, select, set_bool):
    """Pure injected adapter. select(heading, labels) returns an index or -1.

    set_bool(key, enabled) receives only validated MQ5 keys, after confirmation.
    Bare labels are ignored. Unprefixed original keys are isolated automatically;
    already rewritten keys are preserved. Like Kodi Omega's SelectBool in
    xbmc/interfaces/builtins/SkinBuiltins.cpp, updates follow option order,
    including repeated keys. The dialog does not read existing boolean values.
    """
    choices = []
    for option in options:
        if "|" not in option:
            continue
        parts = option.strip().split("|")
        if len(parts) > 2:
            raise ValueError("Expected label|setting")
        label = localized(parts[0], core, mq5)
        key = setting_key(parts[1])
        choices.append((label, key))
    title = localized(heading, core, mq5)
    selected = select(title, [label for label, _ in choices])
    if type(selected) is not int or not 0 <= selected < len(choices):
        return False
    for index, (_, key) in enumerate(choices):
        set_bool(key, index == selected)
    return True


def main(args=None):
    args = list(sys.argv[1:] if args is None else args)
    if len(args) == 2 and args[0] == "colour":
        import os
        import xbmc
        import xbmcgui
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(__file__)), "resources", "lib"))
        from mq5_colours import select_colour
        return select_colour(args[1], xbmc.getInfoLabel("Skin.String(" + PREFIX + args[1] + ")"),
            select=xbmcgui.Dialog().select,
            set_string=lambda key, value: xbmc.executebuiltin("Skin.SetString({},{})".format(key, value), True))
    if len(args) == 2 and args[0] == "transparency" and args[1] in TRANSPARENCY_VALUES:
        import xbmc
        import xbmcgui
        return select_transparency(args[1], xbmc.getInfoLabel("Skin.String(" + PREFIX + args[1] + ")"),
            select=xbmcgui.Dialog().select,
            set_string=lambda key, value: xbmc.executebuiltin("Skin.SetString({},{})".format(key, value), True))
    if len(args) < 3 or args[0].strip().lower() != "selectbool":
        raise ValueError("Expected selectbool,heading,label|setting,...")
    # Deferred imports leave parsing and selection logic usable without Kodi.
    import xbmc
    import xbmcaddon
    import xbmcgui

    helper = None

    def mq5(number):
        nonlocal helper
        if helper is None:
            helper = xbmcaddon.Addon(HELPER_ID)
        return helper.getLocalizedString(number)

    return selectbool(
        args[1], args[2:], core=xbmc.getLocalizedString, mq5=mq5,
        select=xbmcgui.Dialog().select,
        # Kodi Omega SkinBuiltins.cpp::SetBool explicitly supports argument 2.
        # This matches SelectBool's boolean updates without Skin.Reset.
        set_bool=lambda key, enabled: xbmc.executebuiltin(
            "Skin.SetBool({},{})".format(key, "true" if enabled else "false"), True),
    )


if __name__ == "__main__":
    main()
