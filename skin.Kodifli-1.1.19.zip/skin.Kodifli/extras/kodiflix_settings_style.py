"""Choose the main settings layout without reloading the skin."""
import xbmc
import xbmcgui


def main():
    dual_v2 = xbmc.getCondVisibility("Skin.HasSetting(Kodiflix.SettingsDualListV2)")
    grid = xbmc.getCondVisibility("Skin.HasSetting(Kodiflix.SettingsGrid)")
    single = xbmc.getCondVisibility("Skin.HasSetting(Kodiflix.SettingsSingleList)")
    selected = 0 if dual_v2 else (2 if grid else (1 if single else 0))
    choice = xbmcgui.Dialog().select(
        "Settings view", ["Banner", "List", "Grid"], preselect=selected
    )
    if choice < 0:
        return
    for setting, enabled in (
        ("Kodiflix.SettingsSingleList", choice == 1),
        ("Kodiflix.SettingsGrid", choice == 2),
        ("Kodiflix.SettingsDualListV2", choice == 0),
    ):
        xbmc.executebuiltin("Skin.{}({})".format("SetBool" if enabled else "Reset", setting))


if __name__ == "__main__":
    main()
