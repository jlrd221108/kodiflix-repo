"""Native MQ5 Home widgets; no external widget service or playlist script.

Launched by MQ5 Home, never at Kodi startup; exits when MQ5 mode is disabled.
"""
import json
import os
import sys
import time
import uuid
import xml.etree.ElementTree as ET

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.join(xbmcvfs.translatePath("special://skin/"), "resources", "lib"))
from mq5_widgets import NativeWidgets, WIDGET_PREFIX

# A pre-native provider can survive ReloadSkin(). Its global-property lease
# must never prevent this private-property provider from starting after upgrade.
LEASE = "Kodiflix.MQ5.NativeWidgetLease"
MODE = "Skin.HasSetting(Kodiflix.Home.MQ5)"
REFRESH = "Kodiflix.MQ5.WidgetRefresh"


def active():
    return xbmc.getSkinDir() == "skin.Kodifli" and xbmc.getCondVisibility(MODE)


def rpc(method, params):
    response = json.loads(xbmc.executeJSONRPC(json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    if "error" in response:
        raise RuntimeError("{}: {}".format(method, response["error"]))
    return response.get("result", {})


def playlist_settings():
    """Resolve only enabled playlist slots, using VFS for Android/network paths."""
    for index in range(1, 21):
        def setting(key):
            return xbmc.getInfoLabel("Skin.String(Kodiflix.MQ5." + key + ")")
        master = setting(f"menu{index}.master")
        playlist_kind = "vpl" if "vpl" in master else "apl" if "apl" in master else ""
        if not playlist_kind:
            continue
        slot = playlist_kind + str(index)
        if "off" in setting(f"menu{index}.visible") or xbmc.getCondVisibility(
                f"Skin.HasSetting(Kodiflix.MQ5.no{slot}widget)"):
            continue
        path = setting(f"menu{index}.path")
        if not path:
            continue
        try:
            handle = xbmcvfs.File(path)
            try:
                playlist_type = ET.fromstring(handle.read()).get("type")
            finally:
                handle.close()
            kind = {"movies": "Movie", "episodes": "Episode", "tvshows": "TVShow", "musicvideos": "MusicVideo",
                    "albums": "Album", "songs": "Song"}.get(playlist_type)
            if kind:
                choice = setting("mf" + slot + "_list")
                yield kind, path, slot, "Random" if choice == "random" else "Last", choice == "inprogress"
        except (OSError, ValueError, ET.ParseError):
            xbmc.log("Kodiflix MQ5: cannot read widget playlist", xbmc.LOGWARNING)


def play(args):
    if len(args) not in (2, 3) or args[0] not in {
            "movieid", "episodeid", "musicvideoid", "albumid", "songid"}:
        raise ValueError("Invalid widget playback arguments")
    identifier = int(args[1])
    if identifier < 0:
        raise ValueError("Invalid library identifier")
    params = {"item": {args[0]: identifier}}
    if len(args) == 3 and args[2] == "resume":
        params["options"] = {"resume": True}
    return rpc("Player.Open", params)


def run(refresh=False):
    if not active():
        return
    home = xbmcgui.Window(10000)
    if refresh:
        home.setProperty(REFRESH, uuid.uuid4().hex)
    try:
        previous = json.loads(home.getProperty(LEASE) or "null")
    except ValueError:
        previous = None
    if isinstance(previous, dict) and 0 <= time.monotonic() - previous.get("time", 0) < 30:
        return
    token = uuid.uuid4().hex
    home.setProperty(LEASE, json.dumps({"token": token, "time": time.monotonic()}))
    def provider_rpc(method, params):
        # Renew during startup too: Android may take longer than a loop heartbeat.
        home.setProperty(LEASE, json.dumps({"token": token, "time": time.monotonic()}))
        return rpc(method, params)

    adapter = NativeWidgets(provider_rpc,
        lambda name, value: home.setProperty(WIDGET_PREFIX + name, value),
        lambda name: home.clearProperty(WIDGET_PREFIX + name), playlists=playlist_settings)
    refresh_token = home.getProperty(REFRESH)

    class Monitor(xbmc.Monitor):
        def onNotification(self, sender, method, data):
            adapter.notify(method, data)

    monitor = Monitor()
    reported_errors = {}
    try:
        adapter.start(active=True)
        while not monitor.abortRequested() and active():
            current = json.loads(home.getProperty(LEASE) or "null")
            if not isinstance(current, dict) or current.get("token") != token:
                break
            home.setProperty(LEASE, json.dumps({"token": token, "time": time.monotonic()}))
            requested = home.getProperty(REFRESH)
            if requested != refresh_token:
                refresh_token = requested
                adapter.mark_dirty("video")
                adapter.mark_dirty("music")
            adapter.tick()
            for family, error in adapter.last_errors.items():
                if reported_errors.get(family) != error:
                    xbmc.log("Kodiflix MQ5 widget {}: {}".format(family, error), xbmc.LOGERROR)
            reported_errors = dict(adapter.last_errors)
            if monitor.waitForAbort(.75):
                break
    except Exception as error:
        xbmc.log("Kodiflix MQ5 provider: {}".format(error), xbmc.LOGERROR)
    finally:
        adapter.stop()
        try:
            current = json.loads(home.getProperty(LEASE) or "null")
        except ValueError:
            current = None
        if isinstance(current, dict) and current.get("token") == token:
            home.clearProperty(LEASE)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "play":
        play(sys.argv[2:])
    else:
        run(refresh=len(sys.argv) > 1 and sys.argv[1] == "refresh")
