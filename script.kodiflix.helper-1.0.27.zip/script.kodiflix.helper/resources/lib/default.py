#!/usr/bin/python
# coding: utf-8

import json
import html
import hashlib
import os
import re
import sys
import time
import email.utils
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ElementTree

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from service import CACHE_DIRECTORY, CACHE_TOKEN_PROPERTY, HOME_WINDOW, clear_properties, ensure_cache_directory


NEWS_CACHE_FILENAME = "news_cache.json"
NEWS_ARTICLE_CACHE_FILENAME = "news_articles.json"
NEWS_CACHE_MAX_AGE_SECONDS = 15 * 60
NEWS_ARTICLE_CACHE_MAX_AGE_SECONDS = 24 * 60 * 60
NEWS_ARTICLE_CACHE_MAX_ITEMS = 20
NEWS_ARTICLE_BLOCK_VERSION = 3
NEWS_MAX_ITEMS = 60
NEWS_REQUEST_TIMEOUT_SECONDS = 8


def news_cache_path():
    profile = xbmcvfs.translatePath(
        "special://profile/addon_data/script.kodiflix.helper/"
    )
    return os.path.join(profile, NEWS_CACHE_FILENAME)


def read_news_cache():
    try:
        with open(news_cache_path(), "r", encoding="utf-8") as cache_file:
            cache = json.load(cache_file)
        if time.time() - float(cache.get("updated", 0)) <= NEWS_CACHE_MAX_AGE_SECONDS:
            return cache.get("items", [])
    except (OSError, TypeError, ValueError):
        pass
    return []


def write_news_cache(items):
    try:
        xbmcvfs.mkdirs(os.path.dirname(news_cache_path()))
        with open(news_cache_path(), "w", encoding="utf-8") as cache_file:
            json.dump({"updated": time.time(), "items": items}, cache_file, ensure_ascii=False)
    except OSError:
        pass


def news_article_cache_path():
    return os.path.join(os.path.dirname(news_cache_path()), NEWS_ARTICLE_CACHE_FILENAME)


def article_id(item_data):
    identity = item_data.get("url") or item_data.get("title", "")
    return hashlib.sha1(identity.encode("utf-8")).hexdigest()[:20]


def read_article_cache():
    try:
        with open(news_article_cache_path(), "r", encoding="utf-8") as cache_file:
            articles = json.load(cache_file)
        now = time.time()
        return {
            key: value for key, value in articles.items()
            if not value.get("_cached_at") or now - float(value.get("_cached_at", 0)) <= NEWS_ARTICLE_CACHE_MAX_AGE_SECONDS
        }
    except (OSError, TypeError, ValueError):
        return {}


def write_article_cache(items):
    try:
        xbmcvfs.mkdirs(os.path.dirname(news_article_cache_path()))
        articles = {}
        for item in items[-NEWS_ARTICLE_CACHE_MAX_ITEMS:]:
            cached_item = dict(item)
            cached_item["_cached_at"] = time.time()
            articles[article_id(cached_item)] = cached_item
        with open(news_article_cache_path(), "w", encoding="utf-8") as cache_file:
            json.dump(articles, cache_file, ensure_ascii=False)
    except OSError:
        pass


def feed_sources():
    path = xbmcvfs.translatePath("special://profile/RssFeeds.xml")
    try:
        root = ElementTree.parse(path).getroot()
    except (OSError, ElementTree.ParseError):
        return []
    sources = []
    seen_urls = set()
    sets = root.findall("./set")
    for index, feed_set in enumerate(sets, 1):
        name = (feed_set.attrib.get("id") or feed_set.attrib.get("name") or "Feed {}".format(index)).strip()
        urls = []
        for feed in feed_set.findall("feed"):
            url = (feed.text or "").strip()
            if url and url not in seen_urls:
                urls.append(url)
                seen_urls.add(url)
        if name == "1" and any("feeds.kodi.tv" in url for url in urls):
            name = "Kodi"
        if urls:
            sources.append({"name": name, "urls": urls})
    direct_urls = []
    for feed in root.findall("./feed"):
        url = (feed.text or "").strip()
        if url and url not in seen_urls:
            direct_urls.append(url)
            seen_urls.add(url)
    if direct_urls:
        sources.append({"name": "RSS Feeds", "urls": direct_urls})
    return sources


def feed_urls():
    return [url for source in feed_sources() for url in source["urls"]]


def xml_text(node, name):
    child = node.find(name)
    if child is None and not name.startswith("{*"):
        child = node.find("{*}" + name)
    return html.unescape("".join(child.itertext()).strip()) if child is not None else ""


def parse_feed(payload, source):
    root = ElementTree.fromstring(payload)
    entries = root.findall(".//item") or root.findall(".//{*}entry")
    items = []
    for entry in entries:
        title = xml_text(entry, "title")
        link_node = entry.find("link")
        if link_node is None:
            link_node = entry.find("{*}link")
        link = (link_node.text or "").strip() if link_node is not None else ""
        if link_node is not None and not link:
            link = link_node.attrib.get("href", "").strip()
        raw_description = xml_text(entry, "description")
        raw_content = xml_text(entry, "{*}encoded") or xml_text(entry, "{*}content")
        summary = clean_article_text(raw_description or xml_text(entry, "{*}summary") or raw_content)
        content = clean_article_text(raw_content or raw_description)
        blocks = article_blocks(raw_content or raw_description, content or summary)
        image = entry_image(entry, raw_content or raw_description)
        published = (
            xml_text(entry, "pubDate")
            or xml_text(entry, "{*}published")
            or xml_text(entry, "{*}updated")
        )
        if not title or not link:
            continue
        try:
            timestamp = email.utils.parsedate_to_datetime(published).timestamp()
        except (TypeError, ValueError, OverflowError):
            timestamp = 0
        items.append({"title": title, "url": link, "summary": summary, "content": content, "blocks": blocks, "blocks_version": NEWS_ARTICLE_BLOCK_VERSION, "image": image, "published": published, "timestamp": timestamp, "source": source})
    return items


def clean_article_text(value):
    value = html.unescape(value or "")
    value = re.sub(r"(?is)<(script|style).*?</\1>", "", value)
    value = re.sub(r"(?i)<br\s*/?>", "\n", value)
    value = re.sub(r"(?i)</(p|div|li|h[1-6])\s*>", "\n\n", value)
    value = re.sub(r"<[^>]+>", "", value)
    value = re.sub(r"[ \t]+", " ", value)
    value = re.sub(r"\n[ \t]+", "\n", value)
    return value.strip()


def article_blocks(raw_content, fallback_text):
    """Preserve the feed's text/image order for the native article list."""
    raw_content = html.unescape(raw_content or "")
    blocks = []
    cursor = 0
    image_pattern = re.compile(r"(?is)<img\b[^>]*?(?:src|data-src)=[\"']([^\"']+)[\"'][^>]*>")
    for match in image_pattern.finditer(raw_content):
        text = clean_article_text(raw_content[cursor:match.start()])
        if text:
            blocks.append({"type": "text", "value": text})
        image_url = html.unescape(match.group(1)).strip()
        if image_url.startswith(("http://", "https://")):
            blocks.append({"type": "image", "value": image_url})
        cursor = match.end()
    text = clean_article_text(raw_content[cursor:])
    if text:
        blocks.append({"type": "text", "value": text})
    if not blocks and fallback_text:
        blocks.append({"type": "text", "value": fallback_text})
    return blocks


def fetch_article_blocks(url, fallback_text):
    if not url:
        return []
    try:
        request = urllib.request.Request(url, headers={"User-Agent": "Kodiflix/1.0 FlixRSS reader"})
        with urllib.request.urlopen(request, timeout=NEWS_REQUEST_TIMEOUT_SECONDS) as response:
            page = response.read().decode("utf-8", errors="replace")
    except (OSError, UnicodeError, ValueError):
        return []
    match = re.search(
        r'(?is)<(?:div|article)\b[^>]*class=["\'][^"\']*(?:article__body|entry-content|article-body)[^"\']*["\'][^>]*>(.*?)(?:</div>\s*</article>|</article>)',
        page,
    )
    if not match:
        return []
    return article_blocks(match.group(1), fallback_text)


def entry_image(entry, raw_content):
    for child in list(entry):
        tag = child.tag.rsplit("}", 1)[-1].lower()
        if tag in ("content", "thumbnail", "enclosure"):
            url = child.attrib.get("url") or child.attrib.get("href")
            if url and url.startswith(("http://", "https://")):
                return url
    match = re.search(r"(?is)<img[^>]+src=[\"']([^\"']+)", raw_content or "")
    return html.unescape(match.group(1)).strip() if match else ""


def fetch_news(feed_name=None):
    items = []
    sources = feed_sources()
    if feed_name:
        sources = [source for source in sources if source["name"] == feed_name]
    for source in sources:
        for url in source["urls"]:
            try:
                request = urllib.request.Request(url, headers={"User-Agent": "Kodiflix/1.0 FlixRSS"})
                with urllib.request.urlopen(request, timeout=NEWS_REQUEST_TIMEOUT_SECONDS) as response:
                    items.extend(parse_feed(response.read(), source["name"]))
            except (OSError, ValueError, ElementTree.ParseError):
                continue
    unique = {}
    for item in items:
        unique.setdefault(item["url"], item)
    return sorted(unique.values(), key=lambda item: item.get("timestamp", 0), reverse=True)[:NEWS_MAX_ITEMS]


def add_feed():
    name = xbmcgui.Dialog().input("RSS feed name")
    if not name:
        return
    url = xbmcgui.Dialog().input("RSS feed URL")
    if not url or not url.startswith(("http://", "https://")):
        xbmcgui.Dialog().notification("FlixRSS", "Enter a valid HTTP feed URL", time=2500)
        return
    path = xbmcvfs.translatePath("special://profile/RssFeeds.xml")
    try:
        root = ElementTree.parse(path).getroot()
    except (OSError, ElementTree.ParseError):
        root = ElementTree.Element("rssfeeds")
    feed_set = None
    for candidate in root.findall("./set"):
        if (candidate.attrib.get("id") or candidate.attrib.get("name") or "").strip() == name:
            feed_set = candidate
            break
    if feed_set is None:
        feed_set = ElementTree.SubElement(root, "set", {"id": name})
    if any((feed.text or "").strip() == url for feed in feed_set.findall("feed")):
        xbmcgui.Dialog().notification("FlixRSS", "Feed already exists", time=2500)
        return
    ElementTree.SubElement(feed_set, "feed").text = url
    try:
        xbmcvfs.mkdirs(os.path.dirname(path))
        ElementTree.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)
        try:
            os.remove(news_cache_path())
        except OSError:
            pass
        xbmcgui.Dialog().notification("FlixRSS", "RSS feed added", time=2500)
    except OSError:
        xbmcgui.Dialog().notification("FlixRSS", "Could not save RSS feed", time=2500)


def list_news(handle, feed_name=None):
    if feed_name is None:
        xbmcplugin.setContent(handle, "files")
        xbmcplugin.setPluginCategory(handle, "FlixRSS")
        categories = [("All Feeds", "all")]
        categories.extend((source["name"], source["name"]) for source in feed_sources())
        for label, value in categories:
            item = xbmcgui.ListItem(label=label, offscreen=True)
            item.setInfo("video", {"title": label})
            xbmcplugin.addDirectoryItem(handle, "plugin://script.kodiflix.helper/news/?{}".format(urllib.parse.urlencode({"feed": value})), item, True)
        add_item = xbmcgui.ListItem(label="Add RSS feed", offscreen=True)
        add_item.setInfo("video", {"title": "Add RSS feed"})
        xbmcplugin.addDirectoryItem(handle, "plugin://script.kodiflix.helper/news/add", add_item, False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
        return

    items = read_news_cache()
    if not items or (feed_name != "all" and not any(item.get("source") == feed_name for item in items)):
        items = fetch_news(None if feed_name == "all" else feed_name)
        if items:
            if feed_name == "all":
                write_news_cache(items)
    xbmcplugin.setContent(handle, "videos")
    xbmcplugin.setPluginCategory(handle, "FlixRSS / {}".format("All Feeds" if feed_name == "all" else feed_name))
    if feed_name != "all":
        items = [item for item in items if item.get("source") == feed_name]
    article_cache = read_article_cache()
    for item_data in items:
        item = xbmcgui.ListItem(label=item_data.get("title", ""), offscreen=True)
        item.setInfo("video", {"title": item_data.get("title", ""), "plot": item_data.get("summary", ""), "aired": item_data.get("published", "")})
        item.setProperty("IsPlayable", "false")
        item.setArt({"thumb": item_data.get("image", "")})
        article_cache[article_id(item_data)] = item_data
        query = urllib.parse.urlencode({"id": article_id(item_data)})
        xbmcplugin.addDirectoryItem(handle, "plugin://script.kodiflix.helper/news/article?{}".format(query), item, False)
    write_article_cache(list(article_cache.values()))
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def show_news_article(query):
    values = urllib.parse.parse_qs(query.lstrip("?"))
    key = values.get("id", [""])[0]
    article_cache = read_article_cache()
    article = article_cache.get(key, {})
    title = article.get("title", values.get("title", ["FlixRSS"])[0])
    summary = article.get("summary", values.get("summary", [""])[0])
    content = article.get("content", values.get("content", [""])[0])
    image = article.get("image", values.get("image", [""])[0])
    source = article.get("source", values.get("source", [""])[0])
    url = article.get("url", values.get("url", [""])[0])
    if url and (article.get("blocks_version") != NEWS_ARTICLE_BLOCK_VERSION or len(article.get("blocks", [])) <= 2 or len(content) < 1200):
        page_blocks = fetch_article_blocks(url, summary or content)
        if page_blocks:
            article["blocks"] = page_blocks
            article["content"] = "\n\n".join(block["value"] for block in page_blocks if block.get("type") == "text")
            article["blocks_version"] = NEWS_ARTICLE_BLOCK_VERSION
            article_cache[key] = article
            write_article_cache(list(article_cache.values()))
            content = article["content"]
    elif article.get("blocks_version") != NEWS_ARTICLE_BLOCK_VERSION:
        article["blocks"] = article_blocks(content or summary, summary or content)
        article["blocks_version"] = NEWS_ARTICLE_BLOCK_VERSION
        article_cache[key] = article
        write_article_cache(list(article_cache.values()))
    body = content or summary or "No article content was provided by this feed."
    HOME_WINDOW.setProperty("kodiflix.flixrss.article.title", title)
    HOME_WINDOW.setProperty("kodiflix.flixrss.article.body", body)
    HOME_WINDOW.setProperty("kodiflix.flixrss.article.source", source)
    HOME_WINDOW.setProperty("kodiflix.flixrss.article.url", url)
    HOME_WINDOW.setProperty("kodiflix.flixrss.article.id", values.get("id", [""])[0])
    if image:
        HOME_WINDOW.setProperty("kodiflix.flixrss.article.image", image)
    else:
        HOME_WINDOW.clearProperty("kodiflix.flixrss.article.image")
    xbmc.executebuiltin("ActivateWindow(1113)")


def list_news_article(handle, article_key):
    article = read_article_cache().get(article_key, {})
    xbmcplugin.setContent(handle, "files")
    xbmcplugin.setPluginCategory(handle, article.get("title", "FlixRSS"))
    blocks = article.get("blocks") or [{"type": "text", "value": article.get("content") or article.get("summary", "")}]
    if article.get("image") and not any(block.get("type") == "image" for block in blocks):
        blocks.insert(0, {"type": "image", "value": article.get("image")})
    for block in blocks:
        if block.get("type") == "image":
            item = xbmcgui.ListItem(label="", offscreen=True)
            item.setProperty("flixrss_block_type", "image")
            item.setArt({"thumb": block.get("value", "")})
        else:
            item = xbmcgui.ListItem(label=block.get("value", ""), offscreen=True)
            item.setProperty("flixrss_block_type", "text")
        item.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle, "", item, False)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def jsonrpc(method, params):
    request = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
    return json.loads(xbmc.executeJSONRPC(json.dumps(request))).get("result", {})


def list_songs(handle, lane):
    folder = xbmc.getInfoLabel("Container.FolderPath")
    match = re.search(r"albumid/(\d+)", folder)
    album_id = int(match.group(1)) if match else 0
    if not album_id:
        song_id = int(xbmc.getInfoLabel("ListItem.DBID") or 0)
        if song_id:
            details = jsonrpc("AudioLibrary.GetSongDetails", {"songid": song_id, "properties": ["albumid"]}).get("songdetails", {})
            album_id = int(details.get("albumid", 0) or 0)
    if not album_id:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    songs = jsonrpc("AudioLibrary.GetSongs", {"filter": {"albumid": album_id}, "properties": ["title", "track", "duration", "artist", "album", "albumid", "file", "art"], "limits": {"start": 0, "end": 100000}, "sort": {"method": "track", "order": "ascending"}}).get("songs", [])
    midpoint = len(songs) // 2
    songs = songs[:midpoint] if lane == "left" else songs[midpoint:]
    xbmcplugin.setContent(handle, "songs")
    for song in songs:
        item = xbmcgui.ListItem(label=song.get("title", ""), offscreen=True)
        item.setInfo("music", {"title": song.get("title", ""), "tracknumber": song.get("track", 0), "duration": song.get("duration", 0), "artist": song.get("artist", []), "album": song.get("album", "")})
        item.setArt(song.get("art", {}))
        xbmcplugin.addDirectoryItem(handle, song.get("file", ""), item, False)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)


def clear_blur_cache():
    ensure_cache_directory()
    try:
        for entry in os.scandir(CACHE_DIRECTORY):
            if entry.is_file():
                try:
                    os.remove(entry.path)
                except OSError:
                    continue
    except OSError:
        pass
    clear_properties()
    HOME_WINDOW.setProperty(CACHE_TOKEN_PROPERTY, str(time.time()))
    xbmcgui.Dialog().notification("Kodiflix", "Blur cache cleared", time=2500)


if __name__ == "__main__":
    if len(sys.argv) > 0 and sys.argv[0].startswith("plugin://"):
        handle = int(sys.argv[1])
        query = sys.argv[2] if len(sys.argv) > 2 else ""
        path = sys.argv[0].rstrip("/")
        list_songs(handle, "right" if "lane=right" in query else "left")
    elif len(sys.argv) > 1 and sys.argv[1] == "action=clear_cache":
        clear_blur_cache()
