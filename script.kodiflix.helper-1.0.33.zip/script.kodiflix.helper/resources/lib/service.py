"""Publish adaptive artwork only while a custom view consumes it."""
import time

import xbmc
import xbmcvfs

from artwork_cache import (
    SUPPORTED_SKIN, SOURCE_CONTROL_ID, POSTER_SOURCE_CONTROL_ID,
    OUTPUT_PROPERTY, INFO_OUTPUT_PROPERTY, COLOR_PROPERTY,
    COLOR_NOALPHA_PROPERTY, TEXT_COLOR_PROPERTY, CACHE_TOKEN_PROPERTY,
    DEFAULT_RADIUS, DEFAULT_SATURATION, HOME_WINDOW,
    DEBOUNCE_SECONDS, ACTIVE_POLL_SECONDS, clear_properties,
    prune_cache, setting_number, cache_filename, cached_blur,
    create_blur, image_colors, source_stamp,
)


class KodiflixHelperService(xbmc.Monitor):
	def __init__(self):
		super().__init__()
		self.previous_key = ""
		self.pending_key = ""
		self.pending_since = 0.0
		self.previous_info_mode = False
		self.previous_poster_source = ""
		self.poster_pending_since = 0.0
		self.poster_retry_at = 0.0
		self.poster_succeeded = False
		self.retry_at = 0.0
		self.pruned_at = 0.0

	@staticmethod
	def current_request():
		artist_mode = False
		info_mode = xbmc.getCondVisibility("Window.IsActive(movieinformation)")
		active = info_mode or xbmc.getCondVisibility(
			"[Window.IsActive(videos) + [Control.IsVisible(56) | Control.IsVisible(57)]] | "
			"[Window.IsActive(music) + [Control.IsVisible(55) | Control.IsVisible(56) | Control.IsVisible(60)]]"
		)
		consumed = xbmc.getCondVisibility(
			"!Skin.HasSetting(flix_disable_background_blur) | Skin.HasSetting(flix_adaptive_focus_glow)"
		)
		source_control_id = SOURCE_CONTROL_ID
		source = xbmc.getInfoLabel(
			"Control.GetLabel({})".format(source_control_id)
		)
		playback_mode = xbmc.getCondVisibility(
			"Window.IsVisible(visualisation) | Window.IsActive(musicosd)"
		)
		if playback_mode or not active or not consumed:
			# Playback owns its own output property and reuses this cache/pipeline.
			# Avoid competing writes from the browsing and playback services.
			source = ""
		radius = setting_number("Kodiflix.BlurRadius", DEFAULT_RADIUS, int)
		if playback_mode or xbmc.getCondVisibility("Window.IsActive(music) + Control.IsVisible(60)"):
			# Tracks uses a light full-screen blur rather than the cinematic blur.
			radius = 3
		saturation = setting_number(
			"Kodiflix.BlurSaturation", DEFAULT_SATURATION, float
		)
		cache_token = HOME_WINDOW.getProperty(CACHE_TOKEN_PROPERTY)
		key = (
			"{}|{}|{}|{}|{}|{}|{}".format(source, radius, saturation, artist_mode, info_mode, cache_token, source_stamp(source))
			if source
			else ""
		)
		return source, radius, saturation, artist_mode, info_mode, key

	def generate_and_publish(self, source, radius, saturation, artist_mode, info_mode, request_key):
		try:
			blurred = create_blur(source, radius, saturation)
			if not blurred:
				return False
			self.publish_blur(blurred, artist_mode, info_mode, request_key)
			return True
		except Exception as error:
			xbmc.log(
				"Kodiflix Helper blur failed: {}".format(error), xbmc.LOGERROR
			)
		return False

	def prewarm_poster(self, source, radius, saturation):
		"""Debounce changes and back off failed artwork instead of probing at 10 Hz."""
		if not source or source in ("movie", "tvshow", "episode", "set", "artist", "album", "song"):
			return
		key = cache_filename(source, radius, saturation)
		now = time.monotonic()
		if key != self.previous_poster_source:
			self.previous_poster_source = key
			self.poster_pending_since = now
			self.poster_retry_at = 0.0
			self.poster_succeeded = False
		if self.poster_succeeded or now - self.poster_pending_since < DEBOUNCE_SECONDS or now < self.poster_retry_at:
			return
		try:
			self.poster_succeeded = bool(create_blur(source, radius, saturation))
		except Exception as error:
			xbmc.log("Kodiflix poster prewarm failed: {}".format(error), xbmc.LOGWARNING)
		if not self.poster_succeeded:
			self.poster_retry_at = now + 5

	def publish_blur(self, blurred, artist_mode, info_mode, request_key):
		color, text_color = image_colors(blurred)

		# Selection may have changed while Pillow was processing the image.
		if self.current_request()[5] != request_key:
			return

		HOME_WINDOW.setProperty(
			INFO_OUTPUT_PROPERTY if info_mode else OUTPUT_PROPERTY,
			blurred,
		)
		HOME_WINDOW.setProperty(COLOR_NOALPHA_PROPERTY, color[2:])
		HOME_WINDOW.setProperty(COLOR_PROPERTY, color)
		HOME_WINDOW.setProperty(TEXT_COLOR_PROPERTY, text_color)

	def run(self):
		prune_cache()
		self.pruned_at = time.monotonic()
		while not self.abortRequested():
			if xbmc.getSkinDir() != SUPPORTED_SKIN:
				if self.previous_key:
					clear_properties()
				self.previous_key = ""
				self.pending_key = ""
				self.waitForAbort(5)
				continue

			# Preserve the published blur while a modal context menu owns focus.
			if xbmc.getCondVisibility("Window.IsActive(DialogContextMenu.xml)"):
				self.waitForAbort(ACTIVE_POLL_SECONDS)
				continue

			source, radius, saturation, artist_mode, info_mode, current_key = self.current_request()
			if time.monotonic() - self.pruned_at >= 600 and not self.pending_key:
				prune_cache()
				self.pruned_at = time.monotonic()

			if info_mode != self.previous_info_mode:
				HOME_WINDOW.clearProperty(INFO_OUTPUT_PROPERTY)
				self.previous_info_mode = info_mode

			if current_key != self.previous_key:
				self.previous_key = current_key
				self.pending_key = current_key
				self.pending_since = time.monotonic()
				self.retry_at = 0.0
				if not current_key:
					# Music menu transitions can temporarily hide the source control.
					# Keep the last published blur until valid artwork is available.
					if not xbmc.getCondVisibility(
						"Window.IsActive(music) | Window.IsVisible(visualisation) | Window.IsActive(musicosd)"
					):
						clear_properties()
					self.pending_key = ""
					self.waitForAbort(ACTIVE_POLL_SECONDS)
					continue
				cached_path = cached_blur(cache_filename(source, radius, saturation, artist_mode))
				if cached_path:
					self.pending_key = ""
					self.publish_blur(cached_path, artist_mode, info_mode, current_key)

			if (
				self.pending_key
				and time.monotonic() >= self.retry_at
				and time.monotonic() - self.pending_since >= DEBOUNCE_SECONDS
			):
				request_key = self.pending_key
				self.pending_key = ""
				succeeded = self.generate_and_publish(
					source, radius, saturation, artist_mode, info_mode, request_key
				)
				if not succeeded:
					self.pending_key = request_key
					self.retry_at = time.monotonic() + 5

			if not info_mode and not self.pending_key and xbmc.getCondVisibility(
				"Window.IsActive(videos) + [Control.IsVisible(56) | Control.IsVisible(57)] + !Skin.HasSetting(flix_disable_background_blur)"
			):
				poster_source = xbmc.getInfoLabel("Control.GetLabel({})".format(POSTER_SOURCE_CONTROL_ID))
				self.prewarm_poster(poster_source, radius, saturation)

			self.waitForAbort(ACTIVE_POLL_SECONDS if current_key else 0.75)


if __name__ == "__main__":
	KodiflixHelperService().run()
