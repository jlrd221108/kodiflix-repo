"""Settings integration: RunScript(special://skin/extras/flixium_home_mode.py,toggle).

Selected condition: Skin.HasSetting(Flixium.Home.MQ5).
Optional explicit actions: enable, disable. The controller alone reloads the skin.
"""
import os
import sys

import xbmc
from flixium_reload import request_reload
import xbmcgui
import xbmcvfs


SKIN = os.path.realpath(xbmcvfs.translatePath("special://skin/"))
sys.path.insert(0, os.path.join(SKIN, "resources", "lib"))
from home_mode import HomeModeController, MODE_SETTING, valid_runtime_path


def installed_path(relative):
    if not valid_runtime_path(relative):
        raise ValueError("Invalid installed runtime path")
    path = os.path.realpath(os.path.join(SKIN, *relative.split("/")))
    if os.path.commonpath((SKIN, path)) != SKIN:
        raise ValueError("MQ5 runtime file resolves outside the installed skin")
    return path


def read_text(relative):
    with open(installed_path(relative), encoding="utf-8-sig") as source:
        return source.read()


def main(action="toggle"):
    if action not in ("toggle", "enable", "disable"):
        raise ValueError("Expected toggle, enable, or disable")
    home = xbmcgui.Window(10000)
    controller = HomeModeController(
        get_enabled=lambda: xbmc.getCondVisibility(
            "Skin.HasSetting({})".format(MODE_SETTING)),
        set_enabled=lambda enabled: xbmc.executebuiltin(
            "Skin.{}({})".format("SetBool" if enabled else "Reset", MODE_SETTING),
            True),
        read_text=read_text,
        is_file=lambda relative: os.path.isfile(installed_path(relative)),
        clear_property=home.clearProperty,
        cancel_alarm=lambda name: xbmc.executebuiltin(
            "CancelAlarm({},true)".format(name), True),
        reload_skin=lambda: request_reload(),
        show_dialog=xbmcgui.Dialog().ok,
    )
    if action == "toggle":
        return controller.toggle()
    return controller.set_mode(action == "enable")


if __name__ == "__main__":
    main(sys.argv[1].lower() if len(sys.argv) > 1 else "toggle")
