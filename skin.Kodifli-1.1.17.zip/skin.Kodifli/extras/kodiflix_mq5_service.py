"""Missing MQ5 Home data only; launched by MQ5 Home, never at Kodi startup.

The installed original service.skin.widgets remains the owner of its widgets.
This adapter exits when MQ5 mode is disabled or another skin becomes active.
"""
import json
import os
import sys
import time
import uuid

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.join(xbmcvfs.translatePath("special://skin/"), "resources", "lib"))
from mq5_providers import MQ5Providers

LEASE = "Kodiflix.MQ5.ProviderLease"
MODE = "Skin.HasSetting(Kodiflix.Home.MQ5)"


def active():
    return xbmc.getSkinDir() == "skin.Kodifli" and xbmc.getCondVisibility(MODE)


def rpc(method, params):
    response = json.loads(xbmc.executeJSONRPC(json.dumps(
        {"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))
    if "error" in response:
        raise RuntimeError("{}: {}".format(method, response["error"]))
    return response.get("result", {})


def run():
    if not active():
        return
    home = xbmcgui.Window(10000)
    try:
        previous = json.loads(home.getProperty(LEASE) or "null")
    except ValueError:
        previous = None
    if isinstance(previous, dict) and 0 <= time.monotonic() - previous.get("time", 0) < 3:
        return
    token = uuid.uuid4().hex
    adapter = MQ5Providers(rpc, home.setProperty, home.clearProperty,
                           read_property=home.getProperty)

    class Monitor(xbmc.Monitor):
        def onNotification(self, sender, method, data):
            adapter.notify(method, data)

    monitor = Monitor()
    try:
        adapter.start(active=True)
        while not monitor.abortRequested() and active():
            home.setProperty(LEASE, json.dumps({"token": token, "time": time.monotonic()}))
            adapter.tick()
            if monitor.waitForAbort(.75):
                break
    except Exception as error:
        xbmc.log("Kodiflix MQ5 provider: {}".format(error), xbmc.LOGERROR)
    finally:
        adapter.stop()
        try:
            current = json.loads(home.getProperty(LEASE) or "null")
        except ValueError:
            current = None
        if isinstance(current, dict) and current.get("token") == token:
            home.clearProperty(LEASE)


if __name__ == "__main__":
    run()
