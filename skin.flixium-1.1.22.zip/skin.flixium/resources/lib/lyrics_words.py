"""Render real word timings as a progressive highlight, with bounded frame caches."""
from collections import OrderedDict
import hashlib
import os
import re

import xbmcvfs

from lyrics_glow import text_width


def progress(cue, position):
    if position < cue.start:
        return 0
    if cue.end <= cue.start or position >= cue.end:
        return 1
    # Sixteen progressive steps per word; frames swap without opacity fades.
    return int(16 * (position - cue.start) / (cue.end - cue.start)) / 16


class WordLyrics:
    def __init__(self):
        self.layouts, self.frames = OrderedDict(), OrderedDict()
        self.word_layouts = OrderedDict()
        self.font = None

    def layout(self, text):
        if text in self.layouts:
            self.layouts.move_to_end(text)
            return self.layouts[text]
        from PIL import Image, ImageDraw, ImageFont
        scale = 1
        if self.font is None:
            self.font = ImageFont.truetype(os.path.join(os.path.dirname(__file__), "..", "..", "fonts", "SpotifyMixUI-Bold.ttf"), 36 * scale)
        font = self.font
        mask = Image.new("L", (978 * scale, 180 * scale))
        draw = ImageDraw.Draw(mask)
        ranges = []
        for paragraph in re.finditer(r"[^\n]+", text):
            first, end = paragraph.start(), paragraph.start()
            for token in re.finditer(r"\S+\s*", paragraph.group()):
                last = paragraph.start() + token.end()
                if end > first and text_width(font, text[first:last].rstrip()) > 930 * scale:
                    ranges.append((first, end))
                    first = paragraph.start() + token.start()
                end = last
            if end > first:
                ranges.append((first, end))
        ascent, descent = font.getmetrics()
        line_height = ascent + descent + 4 * scale
        boxes = []
        for first, last in ranges:
            value = text[first:last].rstrip()
            if hasattr(font, "getbbox"):
                box = font.getbbox(value)
            else:
                offset = font.getoffset(value)
                size = font.getsize(value)
                box = (offset[0], offset[1], size[0], size[1])
            boxes.append(box)
        if not boxes:
            raise ValueError("Empty timed lyric")
        top = min(box[1] + i * line_height for i, box in enumerate(boxes))
        bottom = max(box[3] + i * line_height for i, box in enumerate(boxes))
        y = (mask.height - (bottom - top)) / 2 - top
        rows = []
        for i, (first, last) in enumerate(ranges):
            value = text[first:last].rstrip()
            x = (mask.width - text_width(font, value)) / 2
            row_y = y + i * line_height
            draw.text((x, row_y), value, font=font, fill=255)
            rows.append((first, first + len(value), x, row_y + boxes[i][1], row_y + boxes[i][3]))
        result = mask, font, rows
        self.layouts[text] = result
        while len(self.layouts) > 4:
            self.layouts.popitem(last=False)
        return result

    def word_layout(self, text, words):
        """Measure word spans once per line, and blur only occupied pixels.

        A 24px margin retains the existing 8px Gaussian halo. The public frame
        remains 978x180, so Kodi's positioning and lyric-bank slides do not move.
        """
        key = (text, tuple(words))
        if key in self.word_layouts:
            self.word_layouts.move_to_end(key)
            return self.word_layouts[key]
        mask, font, rows = self.layout(text)
        bounds = mask.getbbox() or (0, 0, mask.width, mask.height)
        crop = (max(0, bounds[0] - 24), max(0, bounds[1] - 24),
                min(mask.width, bounds[2] + 24), min(mask.height, bounds[3] + 24))
        spans = []
        for cue in words:
            boxes = []
            for first, last, x, top, bottom in rows:
                begin, end = max(first, cue.first), min(last, cue.last)
                if begin >= end:
                    continue
                left = x + text_width(font, text[first:begin]) - crop[0]
                right = x + text_width(font, text[first:end]) - crop[0]
                boxes.append((left, top - crop[1], right, bottom - crop[1]))
            spans.append(boxes)
        result = mask.crop(crop), spans, crop
        self.word_layouts[key] = result
        while len(self.word_layouts) > 4:
            self.word_layouts.popitem(last=False)
        return result

    def frame_for(self, line, position):
        from PIL import Image, ImageChops, ImageDraw, ImageFilter
        text = line[1].replace("[", "［").replace("]", "］")
        fractions = tuple(progress(cue, position) for cue in line.words)
        key = (text, tuple(line.words), fractions)
        if key in self.frames:
            self.frames.move_to_end(key)
            return self.frames[key]
        directory = xbmcvfs.translatePath("special://temp/flixium-lyrics-words/")
        os.makedirs(directory, exist_ok=True)
        path = os.path.join(directory, hashlib.sha256(("words-3:" + repr(key)).encode("utf-8")).hexdigest() + ".png")
        if not os.path.isfile(path):
            mask, spans, crop = self.word_layout(text, line.words)
            selection = Image.new("L", mask.size)
            draw = ImageDraw.Draw(selection)
            for boxes, fraction in zip(spans, fractions):
                if not fraction:
                    continue
                for left, top, right, bottom in boxes:
                    draw.rectangle((left, top, left + (right - left) * fraction, bottom), fill=255)
            sung = ImageChops.multiply(mask, selection)
            near = sung.filter(ImageFilter.GaussianBlur(3)).point(lambda value: round(value * .44))
            far = sung.filter(ImageFilter.GaussianBlur(8)).point(lambda value: round(value * .32))
            frame = Image.new("RGBA", mask.size, (255, 255, 255, 0))
            frame.putalpha(ImageChops.add(near, far))
            dim = Image.new("RGBA", mask.size, (119, 119, 123, 0))
            dim.putalpha(mask)
            frame = Image.alpha_composite(frame, dim)
            bright = Image.new("RGBA", mask.size, (255, 255, 255, 0))
            bright.putalpha(sung)
            frame = Image.alpha_composite(frame, bright)
            canvas = Image.new("RGBA", (978, 180), (255, 255, 255, 0))
            canvas.paste(frame, crop[:2])
            temporary = path + ".tmp"
            try:
                canvas.save(temporary, "PNG")
                os.replace(temporary, path)
            finally:
                if os.path.exists(temporary):
                    os.remove(temporary)
        self.frames[key] = path
        while len(self.frames) > 96:
            _, expired = self.frames.popitem(last=False)
            try:
                os.remove(expired)
            except OSError:
                pass
        return path
