"""On-demand Flixium palette selection; no service, reload or artwork processing."""
import re
import json
from pathlib import Path
import sys
import xbmc
import xbmcgui

PREFIX = "Flixium.Theme."
PRESETS = (
    ("Default", None, None, None),
    ("Obsidian", "1E1E1E", "E9EEF5", "202124"),
    ("Glacier", "17232E", "4DD9FF", "152735"),
    ("Amethyst", "241D30", "BA95FF", "2A2038"),
    ("Aurora", "162923", "64E6B0", "17312E"),
    ("Crimson Velvet", "2B1B21", "FF637C", "341D2B"),
    ("Champagne Noir", "28221A", "E7C58B", "30271E"),
)
KEYS = ("Window", "Panel", "Card", "Focus", "Highlight", "Dialog", "DialogHeader", "Scheme", "Name")
COLOURS = (
    ("Charcoal", "252525"), ("Graphite", "32363C"), ("Midnight", "17232E"),
    ("Deep plum", "241D30"), ("Deep teal", "17312E"), ("Burgundy", "341D2B"),
    ("Espresso", "30271E"), ("Ice white", "E9EEF5"), ("Electric cyan", "4DD9FF"),
    ("Lavender", "BA95FF"), ("Mint", "64E6B0"), ("Ruby", "FF637C"),
    ("Champagne", "E7C58B"), ("Azure", "72ACFF"), ("Coral", "FF967D"),
)

def presets():
    if xbmc.getCondVisibility("Skin.HasSetting(Flixium.Glass.Enabled) + !Skin.HasSetting(Flixium.Home.MQ5)"):
        rows=json.loads((Path(__file__).with_name("glass-palettes.json")).read_text())
        return tuple((p["name"],p["window"],p["highlight"],p["dialog"]) if i else (p["name"],None,None,None) for i,p in enumerate(rows))
    return PRESETS


def get(key):
    return xbmc.getInfoLabel("Skin.String(" + PREFIX + key + ")")

def set_value(key, value):
    # Values are generated hex colours, fixed preset names or a numeric index.
    if value:
        xbmc.executebuiltin("Skin.SetString({},{})".format(PREFIX + key, value))
    else:
        xbmc.executebuiltin("Skin.Reset({})".format(PREFIX + key))

def rgb(value):
    return tuple(int(value[-6:][i:i+2], 16) for i in (0, 2, 4))

def hex_rgb(values):
    return "FF" + "".join("{:02X}".format(max(0, min(255, round(v)))) for v in values)

def surface(value):
    # Keep chosen hues, but constrain large surfaces for white-text contrast.
    parts = rgb(value)
    scale = min(1, 64 / max(max(parts), 1))
    return hex_rgb([v * scale for v in parts])

def apply_component(component, value):
    if component == "window":
        base = surface(value)
        set_value("Window", base)
        for key, lift in (("Panel", 7), ("Card", 13)):
            set_value(key, hex_rgb([v + lift for v in rgb(base)]))
    elif component == "highlight":
        set_value("Highlight", hex_rgb(rgb(value)))
        set_value("Focus", hex_rgb([v * .25 + 22 for v in rgb(value)]))
    elif component == "dialog":
        base = surface(value)
        set_value("Dialog", base)
        set_value("DialogHeader", hex_rgb([v * .78 for v in rgb(base)]))

def scheme_index():
    try:
        return max(0, min(len(presets())-1, int(get("Scheme") or "0")))
    except ValueError:
        return 0

def apply_preset(index):
    name, window, highlight, dialog = presets()[index]
    for key in KEYS:
        set_value(key, "")
    if index:
        for component, value in (("window", window), ("highlight", highlight), ("dialog", dialog)):
            apply_component(component, value)
        set_value("Scheme", str(index))
        set_value("Name", name)

def refresh(focus, prepare_glass=True):
    # Kodi caches some Skin.String variable conditions and button colours at
    # control creation. One explicit reload applies the whole palette together.
    xbmc.sleep(100)
    if prepare_glass:
        from flixium_glass import prepare
        prepare()
        xbmc.sleep(100)
    xbmc.executebuiltin("ReloadSkin()")
    xbmc.sleep(500)
    xbmc.executebuiltin("SetFocus(9000,1)")
    xbmc.sleep(100)
    xbmc.executebuiltin("SetFocus({})".format(focus))

def main():
    action = sys.argv[1] if len(sys.argv) > 1 else "scheme"
    dialog = xbmcgui.Dialog()
    if action == "scheme":
        labels = []
        for name, window, highlight, popup in presets():
            item = xbmcgui.ListItem(label=name, label2="Window tint / highlight / dialog tint")
            item.setArt({"thumb": "special://skin/extras/themes/{}scheme-{}.png".format("glass-" if presets() != PRESETS else "",len(labels))})
            labels.append(item)
        index = dialog.select("Colour preset", labels, preselect=scheme_index(), useDetails=True)
        if index >= 0:
            apply_preset(index)
            refresh(9050)
    elif action == "reset":
        apply_preset(scheme_index())
        refresh(9054)
    elif action == "round":
        current = 0 if xbmc.getCondVisibility("Skin.HasSetting(Flixium.Unrounded)") else (2 if xbmc.getCondVisibility("Skin.HasSetting(Flixium.ExtraRounded)") else 1)
        index = dialog.select("Corner style", ["Unrounded", "Rounded", "Rounder"], preselect=current)
        if index < 0:
            return
        for key, enabled in (("Flixium.Unrounded", index == 0), ("Flixium.ExtraRounded", index == 2)):
            xbmc.executebuiltin("Skin.{}({})".format("SetBool" if enabled else "Reset", key), True)
        refresh(9055)
    elif action in ("window", "highlight", "dialog"):
        title = {"window": "Window and panel tint", "highlight": "Selection highlight colour", "dialog": "Dialog background tint"}[action]
        labels = []
        for number, (name, colour) in enumerate(COLOURS):
            item = xbmcgui.ListItem(label=name, label2="#" + colour)
            item.setArt({"thumb": "special://skin/extras/themes/colour-{}.png".format(number)})
            labels.append(item)
        labels.append(xbmcgui.ListItem(label="Custom hex colourâ€¦", label2="Enter your own RRGGBB colour"))
        index = dialog.select(title, labels, useDetails=True)
        if index < 0:
            return
        if index == len(COLOURS):
            value = dialog.input("{} â€” RRGGBB".format(title), defaultt=(get(action.title()) or "FF252525")[-6:]).strip().lstrip("#")
            if not value:
                return
            if not re.fullmatch(r"[0-9a-fA-F]{6}", value):
                dialog.ok("Colour", "Enter six hexadecimal characters, for example 4DD9FF.")
                return
        else:
            value = COLOURS[index][1]
        apply_component(action, value.upper())
        set_value("Name", presets()[scheme_index()][0] + " (custom)")
        refresh({"window": 9051, "highlight": 9052, "dialog": 9053}[action])

if __name__ == "__main__":
    main()
