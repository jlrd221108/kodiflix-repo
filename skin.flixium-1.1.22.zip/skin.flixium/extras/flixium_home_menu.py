"""Shared fullscreen main-menu editor; both Home styles consume its preferences."""
import os
import re
import sys
import uuid
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

SKIN = xbmcvfs.translatePath("special://skin/")
sys.path.insert(0, os.path.join(SKIN, "resources", "lib"))
from home_menu import PREFIX, MAX_ITEMS, TARGETS, decode, settings, setting_changes, new_item, changed, normalise
from skin_backup import commands
from mq5_text import sentence_case


def local_label(value):
    return re.sub(r"\$LOCALIZE\[(\d+)\]", lambda m: xbmc.getLocalizedString(int(m[1])), value or "")


def initial_items():
    saved = xbmc.getInfoLabel("Skin.String({}.Config)".format(PREFIX))
    if saved:
        return decode(saved)  # Never replace a malformed saved configuration with defaults.
    tree = ET.parse(os.path.join(SKIN, "xml", "Includes_FlixiumHome.xml"))
    content = tree.find(".//control[@id='9000']/content")
    legacy = content.find("include")
    if legacy is not None:
        tree = ET.parse(os.path.join(SKIN, "xml", "Includes_SharedHomeMenu.xml"))
        content = tree.find("include[@name='FlixiumLegacyMenuItems']")
    rows = []
    for index, item in enumerate(content.findall("item")):
        section = item.findtext("property[@name='id']", "custom")
        actions = [{"command": node.text, "condition": node.get("condition", "")} for node in item.findall("onclick")]
        if not actions:
            continue
        visible = item.findtext("visible", "true")
        rows.append({"uid": "legacy_" + section, "label": local_label(item.findtext("label")),
                     "section": section, "enabled": xbmc.getCondVisibility(visible), "actions": actions})
    if xbmc.getCondVisibility("Skin.HasSetting(Flixium.Home.MQ5)"):
        source = ET.parse(os.path.join(SKIN, "xml", "Includes_MQ5.xml"))
        helper = xbmcaddon.Addon("script.flixium.helper")
        imported = []
        aliases = {"concerts": "musicvideos", "favourites": "favorites", "videos": "video", "programs": "addons"}
        def resolve(value):
            if value.startswith("$INFO[") and value.endswith("]"):
                return xbmc.getInfoLabel(value[6:-1])
            if value.startswith("$VAR[") and value.endswith("]"):
                variable = source.find("variable[@name='" + value[5:-1] + "']")
                if variable is not None:
                    for candidate in variable.findall("value"):
                        if not candidate.get("condition") or xbmc.getCondVisibility(candidate.get("condition")):
                            return resolve(candidate.text or "")
                return ""
            return re.sub(r"\$INFO\[([^\]]+)\]", lambda match: xbmc.getInfoLabel(match[1]), value)
        for index in range(1, MAX_ITEMS + 1):
            def pref(key):
                return xbmc.getInfoLabel("Skin.String(Flixium.MQ5.menu{}.{})".format(index, key))
            master = pref("master")
            if not master:
                continue
            section = aliases.get(master, master)
            default = next((row for row in rows if row["section"] == section), None)
            label = pref("label") or pref("defaultlabel")
            if not label:
                node = source.find("variable[@name='MQ5_value_menu{}.label']/value".format(index))
                match = re.search(r"helper (\d+)\]", node.text or "") if node is not None else None
                label = helper.getLocalizedString(int(match[1])) if match else master
            if not pref("label"):
                label = sentence_case(label)
            action = resolve("$VAR[MQ5_value_menu{}.action]".format(index))
            if not action:
                action = default["actions"][0]["command"] if default else "ActivateWindow(Home)"
            background = pref("bg")
            imported.append({"uid": "mq5_" + str(index), "label": label, "section": section,
                             "enabled": "off" not in pref("visible"), "actions": [{"command": action}],
                             "mq5_slot": index, "mq5_id": resolve("$VAR[MQ5_value_menu{}.id]".format(index)),
                             "mq5_subid": resolve("$VAR[MQ5_value_menu{}.subid]".format(index)), "mq5_path": pref("path"),
                             "background": background if os.path.splitext(background)[1].lower() in (".jpg", ".png", ".jpeg", ".webp") else "",
                             "mq5_backgrounds": background if background and not os.path.splitext(background)[1] else ""})
        if imported:
            return normalise(imported)
    # Keep MQ5's existing per-item widget preferences attached to their section
    # when the shared menu is first edited from Flixium rather than MQ5.
    aliases = {"concerts": "musicvideos", "favourites": "favorites", "videos": "video", "programs": "addons"}
    preferred = {}
    for slot in range(1, MAX_ITEMS + 1):
        master = xbmc.getInfoLabel("Skin.String(Flixium.MQ5.menu{}.master)".format(slot))
        preferred.setdefault(aliases.get(master, master), slot)
    available = set(range(1, MAX_ITEMS + 1))
    for row in rows:
        slot = preferred.get(row["section"])
        if slot in available:
            row["mq5_slot"] = slot
            available.remove(slot)
    for row in rows:
        if "mq5_slot" not in row:
            row["mq5_slot"] = min(available)
            available.remove(row["mq5_slot"])
    return normalise(rows)


class HomeMenuEditor(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.rows = initial_items()
        self.index = 0
        self.applied = False
        self._published = None
        self.mq5 = xbmc.getCondVisibility("Skin.HasSetting(Flixium.Home.MQ5)")

    def onInit(self):
        self.setProperty("mq5", "true" if self.mq5 else "false")
        self.render()
        self.setProperty("ready", "true")
        self.setFocusId(100 if self.visible_indices else 101)

    def render(self):
        listing = self.getControl(100)
        listing.reset()
        self.visible_indices = [index for index, row in enumerate(self.rows)
                                if self.mq5 or row["section"] != "settings"]
        for index in self.visible_indices:
            row = self.rows[index]
            item = xbmcgui.ListItem(row["label"])
            listing.addItem(item)
        self.index = min(self.index, len(self.rows) - 1)
        if self.visible_indices:
            if self.index not in self.visible_indices:
                self.index = self.visible_indices[0]
            listing.selectItem(self.visible_indices.index(self.index))
        self.details()

    def details(self):
        self.setProperty("hasitem", "true" if self.visible_indices else "false")
        if not self.visible_indices:
            self.setProperty("item", "Add a menu item")
            self.setProperty("canadd", "true" if len(self.rows) < MAX_ITEMS else "false")
            return
        position = max(0, min(self.getControl(100).getSelectedPosition(), len(self.visible_indices) - 1))
        self.index = self.visible_indices[position]
        row = self.rows[self.index]
        self.setProperty("locked", "true" if row["section"] == "settings" else "false")
        self.setProperty("item", row["label"])
        self.setProperty("action", row["actions"][0]["command"])
        self.setProperty("actionlabel", next((target[1] for target in TARGETS if target[2] == row["actions"][0]["command"]), "Custom action"))
        self.setProperty("enabled", "true" if row["enabled"] else "false")
        self.setProperty("background", os.path.basename(row["background"].replace("\\", "/")) or "Default")
        self.setProperty("backgrounds", os.path.basename(row["mq5_backgrounds"].replace("\\", "/").rstrip("/")) or "Not set")
        self.setProperty("canadd", "true" if len(self.rows) < MAX_ITEMS else "false")

    def commit(self, rows):
        rows = normalise(rows)
        if rows == self.rows:
            return
        published = settings(rows)
        if self._published is None:
            # Read each setting using its actual type. Do this once per editor
            # session, also handling the first migration and cleared slots.
            self._published = [dict(row, value=(
                xbmc.getCondVisibility("Skin.HasSetting({})".format(row["id"]))
                if row["type"] == "bool" else xbmc.getInfoLabel("Skin.String({})".format(row["id"]))))
                for row in published]
        for command in commands(setting_changes(self._published, published)):
            xbmc.executebuiltin(command, True)
        self._published = published
        same_order = [row["uid"] for row in rows] == [row["uid"] for row in self.rows]
        if not self.mq5:
            same_order = same_order and [row["uid"] for row in rows if row["section"] != "settings"] == [row["uid"] for row in self.rows if row["section"] != "settings"]
        previous = self.rows
        self.rows = rows
        self.applied = True
        if same_order:
            listing = self.getControl(100)
            for index, row in enumerate(rows):
                if row["label"] != previous[index]["label"]:
                    if index in self.visible_indices:
                        listing.getListItem(self.visible_indices.index(index)).setLabel(row["label"])
            self.details()
        else:
            self.render()

    def onFocus(self, control_id):
        self.details()

    def onAction(self, action):
        if action.getId() in (9, 10, 92):
            self.close()
        elif self.getFocusId() == 100:
            self.details()

    def onClick(self, control_id):
        if control_id != 101 and not self.visible_indices:
            return
        if control_id == 100:
            self.details()
            self.setFocusId(201)
            return
        row = self.rows[self.index]
        if row["section"] == "settings" and control_id in (202, 203, 206):
            return
        dialog = xbmcgui.Dialog()
        try:
            if control_id == 101:
                name = dialog.input("New menu item name")
                if name.strip():
                    item = new_item("custom_" + uuid.uuid4().hex, name)
                    item["mq5_slot"] = next(slot for slot in range(1, MAX_ITEMS + 1) if slot not in {r["mq5_slot"] for r in self.rows})
                    self.commit(self.rows + [item])
                    self.index = len(self.rows) - 1
                    self.render()
                    self.setFocusId(100)
            elif control_id == 201:
                name = dialog.input("Menu item name", defaultt=row["label"])
                if name.strip():
                    self.commit(changed(self.rows, self.index, label=name))
            elif control_id == 202:
                # Settings is a mandatory MQ5 entry, not a target that can
                # accidentally turn another item into a second locked entry.
                targets = [target for target in TARGETS if target[0] != "settings"]
                choice = dialog.select("Click action", [target[1] for target in targets] + ["Favourite", "Custom Kodi action"])
                if 0 <= choice < len(targets):
                    target = targets[choice]
                    self.commit(changed(self.rows, self.index, section=target[0], actions=[{"command": target[2]}], mq5_id="", mq5_subid="", mq5_path=""))
                elif choice == len(targets):
                    import json
                    response = json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1,
                        "method": "Favourites.GetFavourites", "params": {"properties": ["window", "windowparameter", "path"]}})))
                    favourites = response.get("result", {}).get("favourites", [])
                    selected = dialog.select("Favourite", [item["title"] for item in favourites])
                    if 0 <= selected < len(favourites):
                        item = favourites[selected]
                        def quoted(value):
                            return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"') + '"'
                        action = ("ActivateWindow({},{},return)".format(item["window"], quoted(item.get("windowparameter", "")))
                                  if item.get("type") == "window" else "PlayMedia({})".format(quoted(item.get("path", ""))))
                        self.commit(changed(self.rows, self.index, actions=[{"command": action}]))
                elif choice == len(targets) + 1:
                    action = dialog.input("Kodi click action", defaultt=row["actions"][0]["command"])
                    if action.strip():
                        self.commit(changed(self.rows, self.index, actions=[{"command": action.strip()}]))
            elif control_id == 203:
                self.commit(changed(self.rows, self.index, enabled=not row["enabled"]))
            elif control_id in (204, 205):
                position = self.visible_indices.index(self.index) + (-1 if control_id == 204 else 1)
                if 0 <= position < len(self.visible_indices):
                    target = self.visible_indices[position]
                    rows = list(self.rows)
                    rows[target], rows[self.index] = rows[self.index], rows[target]
                    self.index = target
                    self.commit(rows)
            elif control_id == 206:
                if dialog.yesno("Remove menu item", "Remove '{}'?".format(row["label"])):
                    self.commit(self.rows[:self.index] + self.rows[self.index + 1:])
                    self.setFocusId(100)
            elif control_id == 207:
                path = dialog.browseSingle(2, "Menu item background", "files", ".jpg|.jpeg|.png|.webp", False, False, row["background"])
                if path:
                    self.commit(changed(self.rows, self.index, background=path, mq5_backgrounds=""))
            elif control_id == 208 and self.mq5:
                path = dialog.browseSingle(0, "Multiple backdrops folder", "files", defaultt=row["mq5_backgrounds"])
                if path:
                    self.commit(changed(self.rows, self.index, mq5_backgrounds=path))
            elif control_id == 209:
                self.commit(changed(self.rows, self.index, background="", mq5_backgrounds=""))
        except (ValueError, TypeError) as error:
            dialog.ok("Main menu customisation", str(error))


def activate(uid):
    rows = decode(xbmc.getInfoLabel("Skin.String({}.Config)".format(PREFIX)))
    row = next((row for row in rows if row["uid"] == uid and row["enabled"]), None)
    if row:
        for action in row["actions"]:
            if not action["condition"] or xbmc.getCondVisibility(action["condition"]):
                xbmc.executebuiltin(action["command"])
                break


def finish_edit(applied, mq5):
    if not applied:
        return
    # Editing the shared menu must never select a different Home renderer.
    if xbmc.getCondVisibility("Skin.HasSetting(Flixium.Home.MQ5)") != mq5:
        xbmc.executebuiltin("Skin.SetBool(Flixium.Home.MQ5)" if mq5 else "Skin.Reset(Flixium.Home.MQ5)", True)
    xbmc.executebuiltin("ReloadSkin()", True)
    xbmc.sleep(500)
    if xbmc.getCondVisibility("Window.IsActive(skinsettings)"):
        # Return to the editor button, rather than the adjacent Home-mode switch.
        xbmc.executebuiltin("SetFocus(9000,1)", True)
        xbmc.executebuiltin("SetFocus(9042)", True)


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "activate":
        activate(sys.argv[2])
    else:
        editor = HomeMenuEditor("script-FlixiumHomeMenu.xml", SKIN, "Default", "1080i")
        editor.doModal()
        applied, mq5 = editor.applied, editor.mq5
        del editor
        finish_edit(applied, mq5)
