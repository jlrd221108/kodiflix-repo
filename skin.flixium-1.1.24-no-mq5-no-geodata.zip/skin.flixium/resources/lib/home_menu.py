"""One portable main-menu configuration for both Home renderers. No Kodi imports."""
from copy import deepcopy
import json
import re
from urllib.parse import quote, unquote
PREFIX = 'Flixium.HomeMenu'
MAX_ITEMS = 20
TARGETS = (('movies', 'Movies', 'ActivateWindow(Videos,videodb://movies/titles/,return)', '5000'), ('tvshows', 'TV shows', 'ActivateWindow(Videos,videodb://tvshows/titles/,return)', '6000'), ('music', 'Music', 'ActivateWindow(Music,root,return)', '7000'), ('musicvideos', 'Music videos', 'ActivateWindow(Videos,musicvideos,return)', '16000'), ('livetv', 'Live TV', 'ActivateWindow(TVChannels)', '12000'), ('radio', 'Radio', 'ActivateWindow(RadioChannels)', '13000'), ('addons', 'Add-ons', 'ActivateWindow(1100)', '8000'), ('pictures', 'Pictures', 'ActivateWindow(Pictures)', '4000'), ('video', 'Videos', 'ActivateWindow(Videos,root,return)', '11000'), ('games', 'Games', 'ActivateWindow(Games)', '17000'), ('favorites', 'Favourites', 'ActivateWindow(favouritesbrowser)', '14000'), ('weather', 'Weather', 'ActivateWindow(Weather)', '15000'), ('settings', 'Settings', 'ActivateWindow(Settings)', '0'))
TARGET_MAP = {row[0]: row for row in TARGETS}

def valid_action(value):
    return isinstance(value, str) and 0 < len(value) <= 2048 and (not any((char in value for char in '\x00\r\n'))) and (re.match('^[A-Za-z][A-Za-z0-9_.]*(?:\\(|$)', value) is not None)

def normalise(rows):
    if not isinstance(rows, list) or not 1 <= len(rows) <= MAX_ITEMS:
        raise ValueError('The Home menu needs between 1 and 20 items')
    result, seen = ([], set())
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError('Invalid menu item')
        uid, label = (row.get('uid'), row.get('label'))
        if not isinstance(uid, str) or not re.fullmatch('[A-Za-z0-9_-]{1,64}', uid) or uid in seen:
            raise ValueError('Invalid or duplicate menu item identity')
        if not isinstance(label, str) or not label.strip() or len(label) > 160 or ('\x00' in label):
            raise ValueError('A menu item needs a name of at most 160 characters')
        seen.add(uid)
        actions = row.get('actions', [])
        if not isinstance(actions, list) or not 1 <= len(actions) <= 12:
            raise ValueError('A menu item needs a click action')
        clean_actions = []
        for action in actions:
            if not isinstance(action, dict) or not valid_action(action.get('command')):
                raise ValueError('Invalid click action')
            condition = action.get('condition', '')
            if not isinstance(condition, str) or len(condition) > 2048 or '\x00' in condition:
                raise ValueError('Invalid action condition')
            clean_actions.append({'command': action['command'], 'condition': condition})
        section = row.get('section', 'custom')
        if not isinstance(section, str) or not re.fullmatch('[a-z0-9_]{1,64}', section):
            raise ValueError('Invalid menu section')
        item = {'uid': uid, 'label': label.strip(), 'section': section, 'enabled': row.get('enabled', True) is True, 'actions': clean_actions}
        for key in ('background',):
            value = row.get(key, '')
            if not isinstance(value, str) or len(value) > 4096 or '\x00' in value:
                raise ValueError('Invalid background path')
            item[key] = value
        item['menu_id'] = '21000' if section == 'disc' else TARGET_MAP.get(section, (None, None, None, '0'))[3]
        if section == 'settings':
            item.update(enabled=True, actions=[{'command': 'ActivateWindow(Settings)', 'condition': ''}])
        result.append(item)
    if not any((row['enabled'] for row in result)):
        raise ValueError('Keep at least one menu item enabled')
    return result

def encode(rows):
    return quote(json.dumps(normalise(rows), ensure_ascii=False, separators=(',', ':')), safe='')

def decode(value):
    if not isinstance(value, str) or len(value) > 512000:
        raise ValueError('Invalid Home menu configuration')
    return normalise(json.loads(unquote(value)))

def new_item(uid, label, target='movies'):
    section, _, action, menu_id = TARGET_MAP[target]
    return {'uid': uid, 'label': label, 'section': section, 'menu_id': menu_id, 'enabled': True, 'actions': [{'command': action, 'condition': ''}], 'background': ''}

def settings(rows):
    rows = normalise(rows)
    output = [{'id': PREFIX + '.Config', 'type': 'string', 'value': encode(rows)}]
    for index in range(MAX_ITEMS):
        row = rows[index] if index < len(rows) else None
        base = '{}.Item{}.'.format(PREFIX, index + 1)
        values = {'Label': row['label'] if row else '', 'Id': row['section'] if row else '', 'Uid': row['uid'] if row else '', 'MenuId': row['menu_id'] if row else '0', 'Background': row['background'] if row else ''}
        if row:
            values['Action'] = row['actions'][0]['command'] if len(row['actions']) == 1 and (not row['actions'][0]['condition']) else 'RunScript(special://skin/extras/flixium_home_menu.py,activate,{})'.format(row['uid'])
        else:
            values['Action'] = ''
        output.extend(({'id': base + key, 'type': 'string', 'value': value} for key, value in values.items()))
        output.append({'id': base + 'Enabled', 'type': 'bool', 'value': bool(row and row['enabled'])})
    output.append({'id': PREFIX + '.Configured', 'type': 'bool', 'value': True})
    return output

def changed(rows, index, **values):
    result = deepcopy(rows)
    result[index].update(values)
    return normalise(result)

def setting_changes(previous, current):
    """Keep publication order, without retriggering Kodi for unchanged values."""
    before = {row['id']: (row['type'], row['value']) for row in previous}
    return [row for row in current if before.get(row['id']) != (row['type'], row['value'])]
