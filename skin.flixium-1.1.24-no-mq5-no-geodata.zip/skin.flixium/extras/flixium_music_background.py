"""Choose cached cover-background motion without changing the lyric effects."""
import xbmc
import xbmcgui


def main():
    value = xbmc.getInfoLabel("Skin.String(Flixium.MusicBackgroundMotion)")
    choices = ("Preset", "Static", "Gentle", "Full")
    selected = xbmcgui.Dialog().select("Dynamic (Kawarp) motion", [
        "Use lyric quality preset", "Static - frozen Kawarp background",
        "Gentle - smooth motion, lower memory", "Full - smoother motion, higher memory"],
        preselect=choices.index(value) if value in choices else 0)
    if selected >= 0:
        xbmc.executebuiltin("Skin.SetString(Flixium.MusicBackgroundMotion,{})".format(choices[selected]))


if __name__ == "__main__":
    main()
