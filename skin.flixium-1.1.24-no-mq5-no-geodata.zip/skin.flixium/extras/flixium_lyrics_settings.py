"""Edit lyric effects as individual checkboxes, without animation presets."""
import os
import sys

import xbmc
import xbmcgui

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "resources", "lib"))
from lyrics_options import read_options


EFFECTS = (("Simple", "Simple lyrics", "simple"),
           ("WordHighlight", "Word highlighting", "words"),
           ("Glow", "Lyric glow", "glow"),
           ("WordMotion", "Whole-word movement", "motion"),
           ("SmoothScroll", "Smooth line transitions", "smooth"),
           ("LetterEmphasis", "Held-word letter emphasis", "letters"),
           ("InterludeDots", "Interlude dots", "interludes"),
           ("LineRipple", "Line ripple", "ripple"),
           ("SmoothFrames", "60 fps animation", "fps"))


def main(toggle=None):
    options = read_options(xbmc.getInfoLabel)
    keys = {key for key, _, _ in EFFECTS}
    if toggle is not None:
        if toggle not in keys:
            return
        current = xbmc.getInfoLabel("Skin.String(Flixium.Lyrics{})".format(toggle))
        xbmc.executebuiltin("Skin.SetString(Flixium.Lyrics{},{})".format(toggle, "Off" if current == "On" else "On"))
        return
    for key, _, field in EFFECTS:
        if xbmc.getInfoLabel("Skin.String(Flixium.Lyrics{})".format(key)) not in ("On", "Off"):
            enabled = options.fps == 60 if field == "fps" else getattr(options, field)
            xbmc.executebuiltin("Skin.SetString(Flixium.Lyrics{},{})".format(key, "On" if enabled else "Off"))
    xbmc.executebuiltin("ActivateWindow(1106)")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else None)
