"""Tidy Kodi's generated Interface/Skin controls while this window is open."""
import xbmc
import xbmcgui

def main():
    monitor = xbmc.Monitor()
    window = xbmcgui.Window(10032)
    while xbmc.getCondVisibility("Window.IsActive(interfacesettings)") and not monitor.abortRequested():
        if xbmc.getCondVisibility("Container(3).Position(0)"):
            try:
                configure = window.getControl(-178)
                label = configure.getLabel()
                if label.startswith("- "):
                    configure.setLabel(label[2:])
                    for control_id in (-177, -176, -175):
                        window.getControl(control_id).setVisibleCondition("false")
            except RuntimeError:
                pass
        if monitor.waitForAbort(0.3):
            break

if __name__ == "__main__":
    main()
