"""Publish local/embedded lyrics and timed context for the music playback screen."""
import bisect
from collections import OrderedDict
import os

import xbmc
import xbmcgui
import xbmcvfs

from lyrics_local import decode_text, embedded_lyrics, parse_lyrics
from playback_blur import PlaybackBlur

PREFIX = "kodiflix.lyrics."
PROPERTIES = ("mode", "text", "before2", "before1", "current", "after1", "after2", "source")
MAX_TEXT = 256 * 1024


def load_lyrics(path):
    # Internet streams should not be reopened just to probe their metadata.
    if path.lower().startswith(("http://", "https://", "plugin://")):
        lines, plain = parse_lyrics(xbmc.getInfoLabel("MusicPlayer.Lyrics"))
        return lines, plain, "Embedded lyrics" if lines or plain else ""
    stem = os.path.splitext(path)[0]
    for candidate in (stem + ".lrc", path + ".lrc", stem + ".txt"):
        if not xbmcvfs.exists(candidate):
            continue
        handle = xbmcvfs.File(candidate)
        try:
            text = decode_text(bytes(handle.readBytes(MAX_TEXT)))
        finally:
            handle.close()
        lines, plain = parse_lyrics(text)
        if lines or plain:
            return lines, plain, "Local lyrics"
    if path and xbmcvfs.exists(path):
        handle = xbmcvfs.File(path)
        try:
            lines, plain = embedded_lyrics(handle)
        finally:
            handle.close()
        if lines or plain:
            return lines, plain, "Embedded lyrics"
    lines, plain = parse_lyrics(xbmc.getInfoLabel("MusicPlayer.Lyrics"))
    return lines, plain, "Embedded lyrics" if lines or plain else ""


def run():
    monitor, player, window = xbmc.Monitor(), xbmc.Player(), xbmcgui.Window(10000)
    if window.getProperty(PREFIX + "running"):
        return
    window.setProperty(PREFIX + "running", "true")
    xbmc.log("Kodiflix music playback service started", xbmc.LOGINFO)
    blur = PlaybackBlur(window)
    cache, published = OrderedDict(), {}
    current_path, lines, times, plain, source = "", [], [], "", ""

    def publish(values):
        for key in PROPERTIES:
            value = values.get(key, "")
            if published.get(key) != value:
                # Lyrics are data, not Kodi label markup.
                window.setProperty(PREFIX + key, value.replace("[", "［").replace("]", "］"))
                published[key] = value

    try:
        while not monitor.abortRequested():
            if xbmc.getSkinDir() != "skin.Kodifli" or not player.isPlayingAudio():
                publish({})
                blur.clear()
                current_path = ""
                monitor.waitForAbort(0.5)
                continue
            try:
                visible = xbmc.getCondVisibility("Window.IsVisible(visualisation) | Window.IsVisible(musicosd)")
                if not visible:
                    monitor.waitForAbort(0.5)
                    continue
                blur.update()
                if not xbmc.getCondVisibility("!Skin.HasSetting(KodiflixMusicLyricsDisabled)"):
                    publish({"mode": "missing"})
                    current_path = ""
                    monitor.waitForAbort(0.5)
                    continue
                path = player.getPlayingFile()
                if path != current_path:
                    publish({"mode": "loading"})
                    current_path = path
                    lines, times, plain, source = [], [], "", ""
                    if path in cache:
                        lines, plain, source = cache.pop(path)
                    else:
                        lines, plain, source = load_lyrics(path)
                    cache[path] = (lines, plain, source)
                    while len(cache) > 8:
                        cache.popitem(last=False)
                    times = [entry[0] for entry in lines]
                if lines:
                    index = bisect.bisect_right(times, player.getTime()) - 1
                    values = {"mode": "synced", "source": source}
                    for key, offset in (("before2", -2), ("before1", -1), ("current", 0), ("after1", 1), ("after2", 2)):
                        target = index + offset
                        values[key] = lines[target][1] if 0 <= target < len(lines) else ""
                    publish(values)
                elif plain:
                    publish({"mode": "plain", "text": plain, "source": source})
                else:
                    publish({"mode": "missing"})
            except Exception as error:
                xbmc.log("Kodiflix local lyrics: {}".format(error), xbmc.LOGWARNING)
                publish({"mode": "missing"})
            # Native Player.Progress owns seeking; Python only synchronises lyrics.
            delay = 0.5 if not lines or xbmc.getCondVisibility("Player.Paused") else 0.1
            monitor.waitForAbort(delay)
    finally:
        blur.clear()
        window.clearProperty(PREFIX + "running")
        window.clearProperty("kodiflix.playback.progress")  # Remove a legacy unused value.
        for key in PROPERTIES:
            window.clearProperty(PREFIX + key)


if __name__ == "__main__":
    run()
