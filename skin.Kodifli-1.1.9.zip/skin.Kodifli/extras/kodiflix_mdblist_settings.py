#!/usr/bin/python
# coding: utf-8

"""Configure the MDBList API key from Kodiflix's own settings panel."""

import re

import xbmc
import xbmcaddon
import xbmcgui


SETTING_ID = "Kodiflix.MDBListApiKey"
API_KEY_RE = re.compile(r"^[A-Za-z0-9]+$")


def get_api_key():
	addon = xbmcaddon.Addon("skin.Kodifli")
	if addon.getSettingBool("mdblist_key_migrated"):
		return addon.getSettingString("mdblist_api_key")
	return addon.getSettingString("mdblist_api_key") or xbmc.getInfoLabel("Skin.String({})".format(SETTING_ID))


def set_api_key(value):
	addon = xbmcaddon.Addon("skin.Kodifli")
	addon.setSettingString("mdblist_api_key", value)
	addon.setSettingBool("mdblist_key_migrated", True)
	xbmcgui.Window(10000).setProperty("kodiflix.mdblist.key_configured", "true" if value else "")
	if value:
		xbmc.executebuiltin("Skin.SetString({},{})".format(SETTING_ID, value))
	else:
		xbmc.executebuiltin("Skin.Reset({})".format(SETTING_ID))


def configure_api_key():
	keyboard = xbmc.Keyboard(
		get_api_key(),
		"Enter MDBList API key",
		True,
	)
	keyboard.doModal()
	if not keyboard.isConfirmed():
		return

	api_key = keyboard.getText().strip()
	if api_key and not API_KEY_RE.match(api_key):
		xbmcgui.Dialog().notification(
			"Kodiflix",
			"The MDBList API key contains invalid characters",
			xbmcgui.NOTIFICATION_ERROR,
			3000,
		)
		return

	set_api_key(api_key)
	message = "MDBList API key saved" if api_key else "MDBList API key removed"
	xbmcgui.Dialog().notification(
		"Kodiflix",
		message,
		xbmcgui.NOTIFICATION_INFO,
		2500,
	)


if __name__ == "__main__":
	configure_api_key()
