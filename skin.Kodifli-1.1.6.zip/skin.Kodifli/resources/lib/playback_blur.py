"""Reuse the Tracks blur pipeline/cache without depending on browser controls."""
import os
import runpy
import time

import xbmc
import xbmcaddon
import xbmcvfs

PROPERTY = "kodiflix.playback.blurred"


class PlaybackBlur:
    def __init__(self, window):
        self.window = window
        self.helper = None
        self.key = None
        self.retry_at = 0

    def update(self):
        if not xbmc.getCondVisibility("System.AddonIsEnabled(script.kodiflix.helper) + !Skin.HasSetting(flix_disable_background_blur)"):
            self.clear()
            return
        source = xbmc.getInfoLabel("Player.Art(album.thumb)") or xbmc.getInfoLabel("MusicPlayer.Cover")
        saturation = xbmc.getInfoLabel("Skin.String(Kodiflix.BlurSaturation)")
        token = self.window.getProperty("kodiflix.helper.cache_token")
        key = (source, saturation, token)
        if not source or key == self.key or time.monotonic() < self.retry_at:
            return
        try:
            if self.helper is None:
                addon = xbmcaddon.Addon("script.kodiflix.helper")
                script = os.path.join(addon.getAddonInfo("path"), "resources", "lib", "service.py")
                self.helper = runpy.run_path(xbmcvfs.translatePath(script), run_name="kodiflix_playback_blur")
            amount = self.helper["setting_number"]("Kodiflix.BlurSaturation", self.helper["DEFAULT_SATURATION"], float)
            path = self.helper["create_blur"](source, 3, amount)
            if not path:
                raise ValueError("Album artwork could not be opened")
            # Never substitute sharp artwork while a new derivative is being made.
            self.window.setProperty(PROPERTY, path)
            self.key = key
            self.retry_at = 0
        except Exception as error:
            xbmc.log("Kodiflix playback blur: {}".format(error), xbmc.LOGWARNING)
            self.retry_at = time.monotonic() + 5

    def clear(self):
        self.window.clearProperty(PROPERTY)
        self.key = None

