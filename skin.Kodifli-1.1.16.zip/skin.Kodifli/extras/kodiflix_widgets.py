"""Remote-friendly widget editor and the Next episode library source."""
import json
import os
import sys
import xml.etree.ElementTree as ET
from urllib.parse import unquote

import xbmc
import xbmcgui
import xbmcvfs

SKIN = xbmcvfs.translatePath("special://skin/")
sys.path.insert(0, os.path.join(SKIN, "resources", "lib"))
from home_widgets import (CATALOGUE, ITEM_COUNTS, MAX_WIDGETS, PLAYLIST_TYPES, PREFIX,
                          SECTIONS, SECTION_LABELS, decode, defaults, encode,
                          next_episodes, normalise, option, widget_settings)


def widget_select(heading, items, warning="", **kwargs):
    """Scope the themed native popup to widget configuration menus."""
    home = xbmcgui.Window(10000)
    home.setProperty("kodiflix.widget_select", "true")
    home.setProperty("kodiflix.widget_select_warning", warning)
    try:
        return xbmcgui.Dialog().select(heading, items, **kwargs)
    finally:
        home.clearProperty("kodiflix.widget_select")
        home.clearProperty("kodiflix.widget_select_warning")


class WidgetEditor(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.section = "movies"
        self.draft = {section: decode(section, xbmc.getInfoLabel("Skin.String({}.{}.Config)".format(PREFIX, section))) for section in SECTIONS}
        self.applied = False
        self.move_original = None
        self.move_index = 0
        self.selected = 0
        try:
            saved = json.loads(unquote(xbmc.getInfoLabel(
                "Skin.String({}.GlobalAppearance)".format(PREFIX))))
        except (ValueError, TypeError):
            saved = {}
        if not isinstance(saved, dict):
            saved = {}
        self.has_global_appearance = bool(saved)
        self.global_settings = widget_settings("movies", dict(saved, id="continue"))

    def onInit(self):
        self.render()
        self.setFocusId(100)
        self.setProperty("ready", "true")

    def render(self, selected=0):
        rows = self.draft[self.section]
        self.setProperty("section", SECTION_LABELS[SECTIONS.index(self.section)])
        self.setProperty("count", "{} of {} widgets".format(len(rows), MAX_WIDGETS))
        self.setProperty("canadd", "true" if len(rows) < MAX_WIDGETS else "false")
        self.setProperty("category", self.section)
        self.setProperty("hasrows", "true" if rows else "false")
        self.selected = max(0, min(selected, len(rows) - 1))
        for index in range(MAX_WIDGETS):
            self.setProperty("row{}.label".format(index),
                             "{}. {}".format(index + 1, rows[index]["title"]) if index < len(rows) else "")
        self.setProperty("description", rows[self.selected]["description"] if rows else "")

    def focus_widget(self):
        self.setFocusId(210 + self.selected if self.draft[self.section] else 201)

    def onFocus(self, control_id):
        if 210 <= control_id < 210 + len(self.draft[self.section]):
            self.selected = control_id - 210
            self.setProperty("description", self.draft[self.section][self.selected]["description"])

    def choose(self, replacing=None):
        rows = self.draft[self.section]
        used = {entry["id"] for index, entry in enumerate(rows) if index != replacing}
        choices = [entry for entry in CATALOGUE[self.section] if entry["id"] not in used]
        choices.append(option("custom", "Custom smart playlist…", "", "Choose an existing smart playlist for this section."))
        items = []
        for entry in choices:
            item = xbmcgui.ListItem(entry["title"], entry["description"])
            items.append(item)
        selected = widget_select("{} — choose widget".format(SECTION_LABELS[SECTIONS.index(self.section)]), items, useDetails=True)
        if selected < 0:
            return None
        entry = dict(choices[selected])
        if entry["id"] == "custom":
            folder = "special://profile/playlists/" + ("music/" if self.section == "music" else "video/")
            path = xbmcgui.Dialog().browse(1, "Choose smart playlist", "files", ".xsp", False, False, folder)
            if not path:
                return None
            try:
                file = xbmcvfs.File(path)
                try:
                    root = ET.fromstring(file.read())
                finally:
                    file.close()
                if root.tag != "smartplaylist" or root.get("type") not in PLAYLIST_TYPES[self.section]:
                    raise ValueError("Choose a playlist for this section's media type.")
                entry = option("custom", root.findtext("name") or os.path.splitext(os.path.basename(path))[0], path, "Your custom smart playlist.")
                if not normalise(self.section, [entry]):
                    raise ValueError("This playlist's name or path contains unsupported characters.")
                if any(index != replacing and row["path"] == path for index, row in enumerate(rows)):
                    raise ValueError("This playlist is already selected.")
            except (ET.ParseError, ValueError, OSError, RuntimeError) as error:
                xbmcgui.Dialog().ok("Widget configuration", str(error))
                return None
        if self.has_global_appearance:
            self.apply_global_entry(self.section, entry)
        return entry

    def apply_global_entry(self, section, entry):
        if entry["id"] == "fullscreen":
            return
        entry["artwork"] = "covers" if section == "music" else self.global_settings["artwork"]
        entry["limit"] = self.global_settings["limit"]
        entry.pop("progress", None)
        if entry["id"] == "continue":
            entry["progress"] = self.global_settings["progress"]

    def global_appearance(self):
        while True:
            settings = self.global_settings
            labels = [
                "Movie / TV artwork: " + ("Posters" if settings["artwork"] == "posters" else "Landscape thumbs"),
                "Item count: {}".format(settings["limit"]),
                "Continue watching progress: " + ("On" if settings["progress"] else "Off"),
            ]
            action = widget_select("Global customisation — all sections", labels,
                                   warning="Changing a global option replaces all individual appearance settings in every section. Set individual exceptions afterwards.")
            if action < 0:
                return
            if action == 0:
                choice = widget_select("Artwork", ["Landscape thumbs", "Posters"],
                                       preselect=1 if settings["artwork"] == "posters" else 0)
                if choice < 0:
                    continue
                settings["artwork"] = ("thumbs", "posters")[choice]
            elif action == 1:
                choice = widget_select("Item count", [str(value) for value in ITEM_COUNTS],
                                       preselect=ITEM_COUNTS.index(settings["limit"]))
                if choice < 0:
                    continue
                settings["limit"] = ITEM_COUNTS[choice]
            else:
                settings["progress"] = not settings["progress"]
            # Reapply the complete global appearance, clearing individual overrides.
            for section in SECTIONS:
                for entry in self.draft[section]:
                    self.apply_global_entry(section, entry)
            self.has_global_appearance = True
            xbmc.executebuiltin('Skin.SetString({}.GlobalAppearance,"{}")'.format(
                PREFIX, encode(settings)))
            self.save()

    def appearance(self, entry):
        while True:
            settings = widget_settings(self.section, entry)
            actions = []
            if self.section != "music":
                actions.append(("Artwork: " + ("Posters" if settings["artwork"] == "posters" else "Landscape thumbs"), "artwork"))
            actions.append(("Item count: {}".format(settings["limit"]), "limit"))
            if entry["id"] == "continue":
                actions.append(("Playback progress: " + ("On" if settings["progress"] else "Off"), "progress"))
            selected = widget_select(entry["title"] + " — appearance", [label for label, _ in actions])
            if selected < 0:
                return
            before = dict(entry)
            action = actions[selected][1]
            if action == "artwork":
                selected = widget_select("Artwork", ["Landscape thumbs", "Posters"], preselect=1 if settings["artwork"] == "posters" else 0)
                if selected >= 0:
                    entry["artwork"] = ("thumbs", "posters")[selected]
            elif action == "limit":
                selected = widget_select("Item count", [str(value) for value in ITEM_COUNTS], preselect=ITEM_COUNTS.index(settings["limit"]))
                if selected >= 0:
                    entry["limit"] = ITEM_COUNTS[selected]
            else:
                entry["progress"] = not settings["progress"]
            if entry != before:
                self.save()

    def onClick(self, control_id):
        if 210 <= control_id < 210 + len(self.draft[self.section]):
            self.selected = control_id - 210
            control_id = 200
        if self.move_original is not None:
            if control_id == 200:
                self.finish_move()
            return
        if control_id == 103:
            self.global_appearance()
            self.render()
            self.setFocusId(103)
        elif control_id in (100, 101, 102):
            self.section = SECTIONS[control_id - 100]
            self.render()
            self.focus_widget()
        elif control_id == 200 and self.draft[self.section]:
            rows = self.draft[self.section]
            index = self.selected
            actions = [("Change widget", "change")]
            if len(rows) > 1:
                actions.append(("Move widget", "move"))
            if rows[index]["id"] != "fullscreen":
                actions.append(("Appearance…", "appearance"))
            actions.append(("Remove", "remove"))
            selected = widget_select(rows[index]["title"], [label for label, _ in actions])
            if selected < 0:
                return
            action = actions[selected][1]
            if action == "change":
                entry = self.choose(index)
                if entry:
                    rows[index] = entry
                    self.save()
            elif action == "appearance":
                self.appearance(rows[index])
            elif action == "move":
                self.move_original = list(rows)
                self.move_index = index
                self.setProperty("moving", "true")
                self.focus_widget()
                return
            else:
                rows.pop(index)
                self.save()
            self.render(index)
            self.focus_widget()
        elif control_id == 201 and len(self.draft[self.section]) < MAX_WIDGETS:
            entry = self.choose()
            if entry:
                self.draft[self.section].append(entry)
                self.save()
                self.render(len(self.draft[self.section]) - 1)
                self.focus_widget()
        elif control_id == 202:
            self.draft[self.section] = defaults(self.section)
            if self.has_global_appearance:
                for entry in self.draft[self.section]:
                    self.apply_global_entry(self.section, entry)
            self.save()
            self.render()

    def onAction(self, action):
        if self.move_original is not None:
            action_id = action.getId()
            if action_id in (9, 10, 92):
                self.finish_move(cancel=True)
            elif action_id in (3, 4):
                rows = self.draft[self.section]
                target = max(0, min(len(rows) - 1, self.move_index + (-1 if action_id == 3 else 1)))
                if target != self.move_index:
                    rows.insert(target, rows.pop(self.move_index))
                    self.move_index = target
                    self.render(target)
                self.focus_widget()
            return
        if action.getId() in (9, 10, 92):
            self.close()

    def finish_move(self, cancel=False):
        if cancel:
            entry = self.draft[self.section][self.move_index]
            self.draft[self.section] = self.move_original
            self.move_index = self.move_original.index(entry)
        elif self.draft[self.section] != self.move_original:
            self.save()
        self.move_original = None
        self.clearProperty("moving")
        self.render(self.move_index)
        self.focus_widget()

    def save(self):
        for section in SECTIONS:
            rows = normalise(section, self.draft[section])
            values = {"Config": encode(rows), "Count": str(len(rows))}
            for slot in range(1, MAX_WIDGETS + 1):
                entry = rows[slot - 1] if slot <= len(rows) else {"id": "", "path": "", "title": ""}
                values["{}.Id".format(slot)] = entry["id"]
                values["{}.Path".format(slot)] = entry["path"]
                values["{}.Title".format(slot)] = entry["title"]
                settings = widget_settings(section, entry)
                values["{}.Artwork".format(slot)] = settings["artwork"] if entry["id"] != "fullscreen" else ""
                values["{}.Limit".format(slot)] = str(settings["limit"]) if settings["limit"] else ""
                values["{}.Progress".format(slot)] = ("on" if settings["progress"] else "off") if entry["id"] == "continue" else ""
            for key, value in values.items():
                name = "{}.{}.{}".format(PREFIX, section, key)
                if value:
                    xbmc.executebuiltin('Skin.SetString({},"{}")'.format(name, value))
                else:
                    xbmc.executebuiltin("Skin.Reset({})".format(name))
        xbmc.executebuiltin("Skin.SetBool({}.Configured)".format(PREFIX))
        self.applied = True


def list_next(handle):
    import xbmcplugin
    request = {"jsonrpc": "2.0", "id": 1, "method": "VideoLibrary.GetEpisodes", "params": {
        "properties": ["tvshowid", "season", "episode", "playcount", "lastplayed", "resume"]}}
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        if "error" in response:
            raise RuntimeError(str(response["error"]))
        xbmcplugin.setContent(handle, "episodes")
        for episode in next_episodes(response.get("result", {}).get("episodes", []), limit=30):
            # Fetch artwork and long plots only for the episodes actually displayed.
            details_request = {"jsonrpc": "2.0", "id": 1, "method": "VideoLibrary.GetEpisodeDetails", "params": {
                "episodeid": episode["episodeid"], "properties": ["title", "showtitle", "art", "file", "plot", "runtime", "firstaired", "rating", "uniqueid"]}}
            details = json.loads(xbmc.executeJSONRPC(json.dumps(details_request)))
            if "error" in details:
                continue  # A concurrent library clean can remove an episode.
            episode.update(details.get("result", {}).get("episodedetails", {}))
            item = xbmcgui.ListItem(episode["title"], path=episode["file"], offscreen=True)
            tag = item.getVideoInfoTag()
            tag.setDbId(episode["episodeid"])
            tag.setMediaType("episode")
            tag.setTitle(episode["title"])
            tag.setTvShowTitle(episode.get("showtitle", ""))
            tag.setSeason(episode["season"])
            tag.setEpisode(episode["episode"])
            tag.setPlot(episode.get("plot", ""))
            tag.setDuration(episode.get("runtime", 0))
            tag.setFirstAired(episode.get("firstaired", ""))
            tag.setPlaycount(episode.get("playcount", 0))
            tag.setRating(episode.get("rating", 0))
            tag.setUniqueIDs(episode.get("uniqueid", {}))
            tag.setResumePoint(episode.get("resume", {}).get("position", 0), episode.get("resume", {}).get("total", 0))
            art = dict(episode.get("art", {}))
            for kind in ("fanart", "clearlogo", "poster"):
                if not art.get(kind) and art.get("tvshow." + kind):
                    art[kind] = art["tvshow." + kind]
            item.setArt(art)
            item.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle, episode["file"], item, False)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
    except (ValueError, KeyError, RuntimeError) as error:
        xbmc.log("Kodiflix next episode: {}".format(error), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(handle, succeeded=False)


if __name__ == "__main__":
    if sys.argv[0].startswith("plugin://"):
        list_next(int(sys.argv[1]))
    else:
        editor = WidgetEditor("script-KodiflixWidgets.xml", SKIN, "Default", "1080i")
        editor.doModal()
        applied = editor.applied
        del editor
        if applied:
            xbmc.executebuiltin("ReloadSkin()")
