"""Apply the Netflix preset directly to Kodi's native subtitle settings."""
import os
import sys

import xbmc
import xbmcgui
import xbmcvfs

sys.path.insert(0, os.path.join(xbmcvfs.translatePath("special://skin/"), "resources", "lib"))
from subtitle_appearance import NativeSettings


def main():
    try:
        target = "special://home/media/Fonts/NetflixSans-Regular.otf"
        if not xbmcvfs.exists(target):
            xbmcvfs.mkdirs("special://home/media/Fonts/")
            if not xbmcvfs.copy("special://skin/fonts/NetflixSans-Regular.otf", target):
                raise ValueError("Could not install Netflix Sans in Kodi's subtitle font folder")
        settings = NativeSettings(xbmc.executeJSONRPC)
        settings.refresh()
        settings.apply_preset()
        xbmcgui.Dialog().notification("Subtitles", "Netflix default applied", time=2500)
    except (ValueError, KeyError, TypeError) as error:
        xbmcgui.Dialog().ok("Netflix default", str(error))


if __name__ == "__main__":
    main()
