"""Populate settings labels from the existing, already loaded MQ5 translations."""
import json
import os
import re
import sys
import xbmcaddon
import xbmcgui
import xbmcvfs

root = xbmcvfs.translatePath("special://skin/")
sys.path.insert(0, os.path.join(root, "resources", "lib"))
from mq5_text import sentence_case


def main():
    helper = xbmcaddon.Addon("script.flixium.helper")
    home = xbmcgui.Window(10000)
    with open(os.path.join(root, "resources", "mq5", "settings-labels.json"), encoding="utf-8") as source:
        identifiers = json.load(source)
    for identifier in identifiers:
        value = helper.getLocalizedString(identifier)
        key = "Flixium.MQ5.SettingsLabel.{}".format(identifier)
        if value:
            # State is shown by the native switch, not source-skin (*) markers.
            value = re.sub(r"\s*\((?:\*| )?\)", "", value)
            home.setProperty(key, sentence_case(value))
        else:
            home.clearProperty(key)


if __name__ == "__main__":
    main()
