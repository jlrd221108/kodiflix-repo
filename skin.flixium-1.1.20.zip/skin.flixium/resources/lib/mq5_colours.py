"""Original MQ5 colour keys with readable labels shared by UI and selector."""
COLOURS = (
    ("nocolor", "Default"), ("lightblue", "Light blue"), ("aqua", "Aqua"),
    ("ocean", "Ocean"), ("sky", "Sky"), ("deepblue", "Deep blue"),
    ("royal", "Royal blue"), ("turquoise", "Turquoise"), ("digital", "Digital"),
    ("olive", "Olive"), ("red", "Red"), ("blood", "Blood red"),
    ("brown", "Brown"), ("chocolate", "Chocolate"), ("lightyellow", "Light yellow"),
    ("goldyellow", "Golden yellow"), ("orange", "Orange"), ("spring", "Spring green"),
    ("forest", "Forest green"), ("violet", "Violet"), ("purple", "Purple"),
    ("silver", "Silver"), ("grey", "Grey"), ("graphite", "Graphite"),
)
TITLES = {"colortexture": "Menu bar colour", "colorheader": "Header colour"}


def select_colour(key, current, *, select, set_string):
    title = TITLES[key]  # Reject unrelated settings before opening or writing.
    values, labels = zip(*COLOURS)
    selected = select(title, list(labels), preselect=values.index(current) if current in values else -1)
    if type(selected) is int and 0 <= selected < len(values) and values[selected] != current:
        set_string("Flixium.MQ5." + key, values[selected])
        return True
    return False
