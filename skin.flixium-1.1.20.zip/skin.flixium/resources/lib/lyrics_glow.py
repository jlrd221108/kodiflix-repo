"""Render only a soft alpha halo; Kodi draws the sharp lyric text above it."""
from collections import OrderedDict
import hashlib
import os

import xbmcvfs


def text_width(font, text):
    """Kodi may bundle Pillow older than getlength/textbbox/Resampling."""
    if hasattr(font, "getlength"):
        return font.getlength(text)
    return font.getsize(text)[0]


def text_bounds(draw, text, font, spacing):
    if hasattr(draw, "multiline_textbbox"):
        return draw.multiline_textbbox((0, 0), text, font=font, spacing=spacing, align="center")
    width, height = draw.multiline_textsize(text, font=font, spacing=spacing)
    # Legacy textsize includes the font's space above the visible glyphs.
    top = font.getoffset(text.split("\n")[0])[1]
    return 0, top, width, height


class LyricGlow:
    def __init__(self):
        self.cache = OrderedDict()

    def image_for(self, text):
        if not text.strip():
            return ""
        if text in self.cache:
            self.cache.move_to_end(text)
            return self.cache[text]
        from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

        directory = xbmcvfs.translatePath("special://temp/flixium-lyrics-glow/")
        os.makedirs(directory, exist_ok=True)
        path = os.path.join(directory, hashlib.sha256(("soft-2:" + text).encode("utf-8")).hexdigest() + ".png")
        if not os.path.isfile(path):
            scale = 2
            font_path = os.path.join(os.path.dirname(__file__), "..", "..", "fonts", "SpotifyMixUI-Bold.ttf")
            font = ImageFont.truetype(font_path, 36 * scale)
            lines = []
            for paragraph in text.split("\n"):
                line = ""
                for word in paragraph.split():
                    candidate = (line + " " + word).strip()
                    if line and text_width(font, candidate) > 930 * scale:
                        lines.append(line)
                        line = word
                    else:
                        line = candidate
                lines.append(line)
            # Match the centred, 132px lyric textbox, with room for the blur.
            mask = Image.new("L", (978 * scale, 180 * scale))
            draw = ImageDraw.Draw(mask)
            content = "\n".join(lines)
            bounds = text_bounds(draw, content, font, 8 * scale)
            x = (mask.width - (bounds[2] - bounds[0])) / 2 - bounds[0]
            y = (mask.height - (bounds[3] - bounds[1])) / 2 - bounds[1]
            draw.multiline_text((x, y), content, font=font, fill=255, spacing=8 * scale, align="center")
            near = mask.filter(ImageFilter.GaussianBlur(3 * scale)).point(lambda value: round(value * 0.44))
            far = mask.filter(ImageFilter.GaussianBlur(8 * scale)).point(lambda value: round(value * 0.32))
            halo = Image.new("RGBA", mask.size, (255, 255, 255, 0))
            halo.putalpha(ImageChops.add(near, far))
            halo = halo.resize((978, 180), getattr(Image, "Resampling", Image).LANCZOS)
            halo.save(path)
        self.cache[text] = path
        while len(self.cache) > 64:
            _, expired = self.cache.popitem(last=False)
            try:
                os.remove(expired)
            except OSError:
                pass
        return path
