"""Pure, event-driven bridge for the original MQ5 Home property names.

Runtime integration (owned by the caller)::

    adapter = MQ5Providers(rpc, home.setProperty, home.clearProperty,
                           read_property=home.getProperty)
    adapter.start(active=is_mq5_mode)
    adapter.notify(method, data)  # forward Kodi library notifications
    adapter.tick()              # cheap when clean; no periodic library refresh
    adapter.set_active(is_mq5_mode)
    adapter.stop()              # call BEFORE destroying the Home publisher

``rpc(method, params)`` returns a decoded JSON-RPC result or response envelope.
The caller wraps executeJSONRPC, selects Window(10000), and drives tick from its
existing lifetime loop. No Kodi imports, threads, timers, or external services
are started here. All public lifecycle calls are serialized. Deactivation clears
only properties successfully published by this instance, before becoming idle.

Default external-provider mode owns only missing library statistics and LatestSong.
It neither queries nor writes the video/album/widget families of service.skin.widgets.
That global service has its own lifetime: this adapter does not start, stop, or gate
it. Recommendations are external-only; there is no local approximation fallback.

``owned_families`` restricts ownership to exact family names in SUPPORTED_FAMILIES.
``external_provider=False`` permits the optional recent/random local widgets;
these are not exact replacements for service.skin.widgets settings/formatting.
With ``read_property``, any populated contract property from another writer reserves the
whole family for that activation. Missing fields in an external family are not
filled using a potentially different item selection. Without a reader, the caller
must ensure exclusive ownership of its configured families. All callbacks run on
the caller's thread; the runtime must serialize mode changes through set_active.
"""

import copy
import threading
import time


MAX_ITEMS = 12
CORE_FAMILIES = (
    "Movies", "TVShows", "Episodes", "MusicVideos", "Music",
    "LatestSong",
)
LOCAL_WIDGET_FAMILIES = (
    "RecentMovie", "RandomMovie", "RecentEpisode", "RandomEpisode",
    "RecentMusicVideo", "RandomMusicVideo", "RecentAlbum", "RandomAlbum",
    "RandomSong", "RandomArtist",
)
RECOMMENDATION_FAMILIES = (
    "RecommendedMovie", "RecommendedEpisode", "RecommendedMusicVideo", "RecommendedAlbum",
)
EXTERNAL_WIDGET_FAMILIES = LOCAL_WIDGET_FAMILIES + RECOMMENDATION_FAMILIES
SUPPORTED_FAMILIES = CORE_FAMILIES + LOCAL_WIDGET_FAMILIES
UNSUPPORTED_CONTRACTS = {
    "RecommendedMovie.*, RecommendedEpisode.*, RecommendedMusicVideo.*, RecommendedAlbum.*":
        "External-only: use the installed original service; no local recommendation fallback.",
    "Playlist*": "PlaylistLast/RandomMovievpl{1..20}, Episodevpl{1..20}, "
        "MusicVideovpl{1..20}, Musicapl{1..20}: requires original user playlist bindings.",
    "NextAired.*": "Requires an external airing schedule service.",
    "MostPlayedROM.*": "Requires the external ROM collection provider.",
    "RandomAddon.*": "External addon eligibility and launch semantics are unknown.",
    "Favourite.*": "External favourite command serialization is not implemented.",
    "WeatherOverride/current_wxicon_path": "Owned by the weather provider.",
    "SkinInfo.*": "Non-Home selected-item metadata is outside this adapter.",
}
PARITY_NOTES = (
    "External-provider mode leaves all service.skin.widgets widget families untouched.",
    "This adapter's inactive state does not stop the original global service.",
    "LatestSong.Description uses the song comment; no external biography enrichment.",
    "Artwork is limited to artwork returned by Kodi; missing values are empty.",
    "Optional local widgets do not mirror external unplayed-only, plot-hiding, or season-folder settings.",
    "Optional local widgets use PlayMedia rather than the external RunScript playback dispatcher.",
    "Optional local episodes use s02e03 formatting rather than the external service's decimal formatting.",
    "A property reader can detect changed values, not another writer publishing an identical value.",
)

_VIDEO = {
    "Movie": ("Movies", "movies", ["title", "year", "genre", "rating", "plot",
        "tagline", "mpaa", "runtime", "file", "art", "streamdetails", "trailer", "resume"]),
    "Episode": ("Episodes", "episodes", ["title", "showtitle", "season", "episode",
        "rating", "plot", "runtime", "file", "art", "streamdetails", "firstaired", "resume", "tvshowid"]),
    "MusicVideo": ("MusicVideos", "musicvideos", ["title", "year", "artist", "genre",
        "plot", "runtime", "file", "art", "thumbnail", "streamdetails", "resume"]),
}
_AUDIO = {
    "Album": ("Albums", "albums", ["title", "artist", "genre", "year", "rating",
        "description", "thumbnail", "fanart", "art"]),
    "Song": ("Songs", "songs", ["title", "artist", "year", "comment", "file",
        "thumbnail", "art"]),
    "Artist": ("Artists", "artists", ["genre", "description", "thumbnail", "fanart"]),
}


def _text(value):
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        return " / ".join(_text(part) for part in value)
    return str(value)


def _play(path):
    # Escape builtin argument syntax; never splice a raw filename into a command.
    return 'PlayMedia("{}")'.format(_text(path).replace("\\", "\\\\").replace('"', '\\"')) if path else ""


def item_properties(kind, row):
    """Translate Kodi metadata to MQ5 suffixes, preserving Art(...) spelling."""
    art = row.get("art") or {}
    runtime = row.get("runtime") or 0
    resume = row.get("resume") or {}
    total = resume.get("total") or runtime
    percent = min(100, max(0, 100 * (resume.get("position") or 0) / total)) if total else 0
    video = (row.get("streamdetails") or {}).get("video") or []
    result = {
        "Title": row.get("title") or row.get("label") or row.get("artist", ""),
        "Year": row.get("year") or "", "Genre": row.get("genre", ""),
        "Artist": row.get("artist", ""), "Plot": row.get("plot", ""),
        "Rating": row.get("rating", ""), "MPAA": row.get("mpaa", ""),
        "Tagline": row.get("tagline", ""), "Trailer": row.get("trailer", ""),
        "File": row.get("file", ""), "Path": row.get("file", ""),
        "Play": _play(row.get("file")), "Runtime": int(runtime) // 60,
        "Runtimesecs": runtime, "PercentPlayed": "{:.2f}".format(percent),
        "PercentPlayedAsInt": int(percent), "VideoCodec": video[0].get("codec", "") if video else "",
        "Thumb": row.get("thumbnail") or art.get("thumb") or art.get("poster", ""),
        "Fanart": row.get("fanart") or art.get("fanart", ""),
        "Art(poster)": art.get("poster", ""), "Art(fanart)": art.get("fanart") or row.get("fanart", ""),
        "Art(thumb)": art.get("thumb", ""),
        "Art(Thumb)": art.get("thumb") or row.get("thumbnail", ""),
        "Art(tvshow.poster)": art.get("tvshow.poster", ""),
        "Art(tvshow.fanart)": art.get("tvshow.fanart", ""),
        "DBID": row.get("movieid", ""), "TVShowTitle": row.get("showtitle", ""),
        "Premiered": row.get("firstaired", ""),
        "EpisodeNo": "s{:02d}e{:02d}".format(row.get("season") or 0, row.get("episode") or 0),
        "Description": row.get("comment", "") if kind == "Song" else row.get("description", ""),
    }
    if kind == "Album":
        result["Play"] = _play("musicdb://albums/{}/".format(row["albumid"])) if "albumid" in row else ""
    if kind == "Artist":
        result["LibraryPath"] = "musicdb://artists/{}/".format(row["artistid"]) if "artistid" in row else ""
    return {key: _text(value) for key, value in result.items()}


# Only emit fields actually consumed by the original Home widgets. In particular,
# LatestSong.Path is used inside PlayMedia(), whereas RandomSong.Play is a builtin.
_FIELDS = {
    "Movie": "Title Year Genre Rating Plot Tagline MPAA Runtime File Trailer VideoCodec DBID Art(poster) Art(fanart) Play PercentPlayed PercentPlayedAsInt",
    "Episode": "Title TVShowTitle EpisodeNo Premiered Genre MPAA Plot Rating Runtime File VideoCodec Play PercentPlayedAsInt Art(thumb) Art(tvshow.poster) Art(tvshow.fanart)",
    "MusicVideo": "Title Year Artist Genre Plot Runtime Runtimesecs File Play Thumb VideoCodec Art(Thumb) Art(fanart) PercentPlayedAsInt",
    "Album": "Title Artist Genre Description Year Rating Thumb Play Art(fanart)",
    "Song": "Title Artist Description Year Thumb Fanart Play",
    "Artist": "Title Genre Description Thumb Fanart LibraryPath",
}


class MQ5Providers:
    """Lifecycle API for a caller-owned runtime; inactive construction does no work.

    Events coalesce for ``debounce`` seconds, capped by ``max_debounce`` so a
    stream of updates cannot starve refresh. Errors retain the last good domain
    snapshot and retry no faster than ``retry_interval``. Clean ticks never query.
    ``last_errors`` and ``unsupported_contracts`` are caller-visible diagnostics.
    """

    def __init__(self, rpc, publish, clear, clock=time.monotonic, item_limit=12,
                 debounce=1.0, max_debounce=5.0, retry_interval=30.0,
                 external_provider=True, owned_families=None, read_property=None):
        self.rpc, self.publish, self.clear, self.clock = rpc, publish, clear, clock
        self.external_provider = bool(external_provider)
        allowed = CORE_FAMILIES if self.external_provider else SUPPORTED_FAMILIES
        if isinstance(owned_families, str):
            raise ValueError("owned_families must be a collection of exact family names")
        self.owned_families = frozenset(allowed if owned_families is None else owned_families)
        invalid = self.owned_families - set(allowed)
        if invalid:
            raise ValueError("Unavailable or external-only property families: " + ", ".join(sorted(invalid)))
        self.external_families = frozenset(EXTERNAL_WIDGET_FAMILIES) - self.owned_families
        self.read_property = read_property
        self.blocked_families = set()
        self.item_limit = max(1, min(MAX_ITEMS, int(item_limit)))
        self.debounce = max(0.0, float(debounce))
        self.max_debounce = max(self.debounce, float(max_debounce))
        self.retry_interval = max(1.0, float(retry_interval))
        self.active = False
        self.closed = False
        self.last_errors = {}
        self._family_error_domains = {}
        self.unsupported_contracts = dict(UNSUPPORTED_CONTRACTS)
        self._owned = {}
        self._property_domains = {}
        self._snapshots = {}
        self._retry_after = {}
        self._dirty = {}
        self._scanning = set()
        self._show_cache = {}
        self._lock = threading.RLock()

    def start(self, active=True):
        self.set_active(active)
        return self

    def set_active(self, active):
        with self._lock:
            if self.closed or self.active == bool(active):
                return
            if active:
                self.active = True
                self.blocked_families.clear()
                self._retry_after.clear()
                now = self.clock()
                self._dirty = {domain: (now, now) for domain in ("video", "music")}
            else:
                self.clear_owned()
                self.active = False
                self._snapshots.clear()

    def clear_owned(self):
        """Clear this instance's writes only; inactive calls are silent."""
        with self._lock:
            if not self.active:
                return
            self._release_collisions()
            for name in list(self._owned):
                self.clear(name)
                del self._owned[name]
                self._property_domains.pop(name, None)

    @staticmethod
    def _domain(family):
        return "music" if family in ("Music", "LatestSong", "RandomSong", "RandomArtist",
                                      "RecentAlbum", "RandomAlbum") else "video"

    def _owns(self, family):
        return family in self.owned_families and family not in self.blocked_families

    def _property_names(self, family):
        if family == "Music":
            return ["Music." + plural + "Count" for plural in ("Artists", "Albums", "Songs")]
        if family in ("Movies", "TVShows", "Episodes", "MusicVideos"):
            fields = ("Count",) if family == "TVShows" else ("Count", "UnWatched", "Watched")
            return [family + "." + field for field in fields]
        fields = "Title Artist Thumb Fanart Year Description Path".split() if family == "LatestSong" else next(
            _FIELDS[kind].split() for kind in _FIELDS if family.endswith(kind))
        # Reserve the original full 12-slot namespace even with a smaller limit.
        return ["{}.{}.{}".format(family, index, field)
                for index in range(1, MAX_ITEMS + 1) for field in fields]

    def _release_collisions(self, domain=None):
        if self.read_property is None:
            return
        for family in sorted(self.owned_families - self.blocked_families):
            if domain is not None and self._domain(family) != domain:
                continue
            for name in self._property_names(family):
                value = self.read_property(name)
                if value not in (None, "") and (name not in self._owned or value != self._owned[name]):
                    self.blocked_families.add(family)
                    # A takeover transfers the whole family without clearing any
                    # of its properties, including values we previously wrote.
                    for owned in list(self._owned):
                        if owned.startswith(family + "."):
                            self._owned.pop(owned)
                            self._property_domains.pop(owned, None)
                    self.last_errors.pop(family, None)
                    self._family_error_domains.pop(family, None)
                    break

    def stop(self):
        with self._lock:
            self.set_active(False)
            self.closed = True

    def mark_dirty(self, domain):
        with self._lock:
            if self.closed or domain not in ("video", "music"):
                return
            now = self.clock()
            first = self._dirty.get(domain, (now, now))[0]
            self._dirty[domain] = (first, min(now + self.debounce, first + self.max_debounce))

    def notify(self, method, data=None):
        """Forward Kodi Monitor.onNotification method names; payload is optional.

        Scan/clean events suppress intermediate reads. Playback library changes
        arrive through OnUpdate; player ticks do not trigger library queries.
        """
        with self._lock:
            if self.closed:
                return
            for prefix, domain in (("VideoLibrary.", "video"), ("AudioLibrary.", "music")):
                if not method.startswith(prefix):
                    continue
                event = method[len(prefix):]
                if event in ("OnScanStarted", "OnCleanStarted"):
                    self._scanning.add(domain)
                if event in ("OnScanFinished", "OnCleanFinished"):
                    self._scanning.discard(domain)
                if event in ("OnUpdate", "OnRemove", "OnScanStarted", "OnCleanStarted",
                             "OnScanFinished", "OnCleanFinished"):
                    self.mark_dirty(domain)

    def _call(self, method, params):
        response = self.rpc(method, copy.deepcopy(params))
        if not isinstance(response, dict) or "error" in response:
            raise ValueError("{} failed: {}".format(method, response))
        result = response.get("result", response)
        if not isinstance(result, dict):
            raise ValueError("{} returned a non-object result".format(method))
        return result

    def _count(self, method, filter_=None):
        params = {"limits": {"start": 0, "end": 1}}
        if filter_:
            params["filter"] = filter_
        result = self._call(method, params)
        # Never infer a whole-library count from a truncated item list.
        total = result.get("limits", {}).get("total")
        if not isinstance(total, int) or isinstance(total, bool) or total < 0:
            raise ValueError("{} missing limits.total".format(method))
        return total

    def _items(self, domain, kind, mode):
        plural, key, properties = (_VIDEO if domain == "video" else _AUDIO)[kind]
        method = ("VideoLibrary." if domain == "video" else "AudioLibrary.") + "Get" + plural
        params = {"properties": properties, "limits": {"start": 0, "end": self.item_limit},
                  "sort": {"method": "random" if mode == "Random" else "dateadded", "order": "descending"}}
        response = self._call(method, params)
        rows = response.get(key)
        if not isinstance(rows, list) or any(not isinstance(row, dict) for row in rows):
            raise ValueError("{} missing or invalid {}".format(method, key))
        if kind == "Episode":
            rows = [self._enrich_episode(row) for row in rows[:self.item_limit]]
        prefix = mode + kind
        if kind == "Song" and mode == "Recent":
            prefix = "LatestSong"
        fields = _FIELDS[kind].split()
        if prefix == "LatestSong":
            fields = "Title Artist Thumb Fanart Year Description Path".split()
        return self._flatten(prefix, kind, rows, fields)

    def _flatten(self, prefix, kind, rows, fields=None):
        fields = fields or _FIELDS[kind].split()
        return {"{}.{}.{}".format(prefix, index, field): values[field]
                for index, row in enumerate(rows[:self.item_limit], 1)
                for values in (item_properties(kind, row),) for field in fields}

    def _enrich_episode(self, row):
        row = dict(row)
        show_id = row.get("tvshowid")
        if show_id is None:
            return row
        if show_id not in self._show_cache:
            result = self._call("VideoLibrary.GetTVShowDetails", {
                "tvshowid": show_id, "properties": ["genre", "mpaa", "art"]})
            details = result.get("tvshowdetails")
            if not isinstance(details, dict):
                raise ValueError("VideoLibrary.GetTVShowDetails missing tvshowdetails")
            self._show_cache[show_id] = details
        details = self._show_cache[show_id]
        row.update({field: details.get(field, "") for field in ("genre", "mpaa")})
        art = dict(row.get("art") or {})
        for field in ("poster", "fanart"):
            if not art.get("tvshow." + field):
                art["tvshow." + field] = (details.get("art") or {}).get(field, "")
        row["art"] = art
        return row

    def _refresh(self, domain):
        values = {}
        if domain == "video":
            # Per-refresh cache bounds show enrichment to the bounded widget rows.
            self._show_cache.clear()
            for plural in ("Movies", "TVShows", "Episodes", "MusicVideos"):
                if not self._owns(plural):
                    continue
                method = "VideoLibrary.Get" + plural
                total = self._count(method)
                values[plural + ".Count"] = str(total)
                if plural != "TVShows":
                    unwatched = self._count(method, {"field": "playcount", "operator": "is", "value": "0"})
                    values[plural + ".UnWatched"] = str(unwatched)
                    values[plural + ".Watched"] = str(max(0, total - unwatched))
            kinds = _VIDEO
        else:
            if self._owns("Music"):
                for plural in ("Artists", "Albums", "Songs"):
                    values["Music." + plural + "Count"] = str(self._count("AudioLibrary.Get" + plural))
            kinds = _AUDIO
        for kind in kinds:
            modes = ("Random",) if kind == "Artist" else ("Recent", "Random")
            for mode in modes:
                prefix = "LatestSong" if (kind, mode) == ("Song", "Recent") else mode + kind
                if self._owns(prefix):
                    values.update(self._family(domain, prefix,
                        lambda kind=kind, mode=mode: self._items(domain, kind, mode)))
        return values

    def _family(self, domain, prefix, fetch):
        # An optional widget failure must not withhold library totals or LatestSong.
        # Keep this family's last good values, publish the other families, and retry
        # after the same backoff used for domain failures.
        try:
            values = fetch()
        except Exception as error:
            self.last_errors[prefix] = str(error)
            self._family_error_domains[prefix] = domain
            return {name: value for name, value in self._snapshots.get(domain, {}).items()
                    if name.startswith(prefix + ".")}
        self.last_errors.pop(prefix, None)
        self._family_error_domains.pop(prefix, None)
        return values

    def _commit(self, domain, values):
        self._release_collisions(domain)
        values = {name: value for name, value in values.items() if self._owns(name.split(".", 1)[0])}
        old = {name for name, owner in self._property_domains.items() if owner == domain}
        for name in old - values.keys():
            if name in self._owned:
                self.clear(name)
                del self._owned[name]
                self._property_domains.pop(name, None)
        for name, value in values.items():
            if name not in self._owned or self._owned[name] != value:
                self.publish(name, value)
                self._owned[name] = value
                self._property_domains[name] = domain
        self._snapshots[domain] = values

    def tick(self):
        """Refresh due dirty domains once; return the successfully refreshed names."""
        with self._lock:
            if not self.active or self.closed:
                return ()
            refreshed = []
            for domain, (_, due) in list(self._dirty.items()):
                if self.clock() < max(due, self._retry_after.get(domain, 0)) or domain in self._scanning:
                    continue
                try:
                    self._release_collisions(domain)
                    values = self._refresh(domain)
                    self._commit(domain, values)
                except Exception as error:
                    self.last_errors[domain] = str(error)
                    now = self.clock()
                    self._retry_after[domain] = now + self.retry_interval
                    self._dirty[domain] = (now, now + self.retry_interval)
                else:
                    self._dirty.pop(domain, None)
                    self.last_errors.pop(domain, None)
                    self._retry_after.pop(domain, None)
                    if domain in self._family_error_domains.values():
                        now = self.clock()
                        self._retry_after[domain] = now + self.retry_interval
                        self._dirty[domain] = (now, now + self.retry_interval)
                    refreshed.append(domain)
            return tuple(refreshed)
