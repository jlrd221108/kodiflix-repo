"""Publish local/embedded lyrics and timed context for the music playback screen."""
import bisect
from collections import OrderedDict
import os

import xbmc
import xbmcgui
import xbmcvfs

from lyrics_local import embedded_lyrics, parse_lyrics
from playback_blur import PlaybackBlur
from lyrics_glow import LyricGlow
from lyrics_timed import parse_sidecar
from lyrics_words import WordLyrics

PREFIX = "flixium.lyrics."
CONTEXT = (("before2", -2), ("before1", -1), ("current", 0), ("after1", 1), ("after2", 2))
LINE_KEYS = tuple(key for key, _ in CONTEXT)
SNAPSHOTS = tuple(bank + "." + key for bank in ("a", "b") for key in LINE_KEYS + ("glow", "frame", "wordtimed"))
PROPERTIES = ("mode", "text", "before2", "before1", "current", "after1", "after2", "source") + SNAPSHOTS + ("bank",)
MAX_TEXT = 2 * 1024 * 1024


def load_lyrics(path, source="auto"):
    # Internet streams should not be reopened just to probe their metadata.
    if path.lower().startswith(("http://", "https://", "plugin://")):
        if source == "local":
            return [], "", ""
        lines, plain = parse_lyrics(xbmc.getInfoLabel("MusicPlayer.Lyrics"))
        return lines, plain, "Embedded lyrics" if lines or plain else ""
    stem = os.path.splitext(path)[0]
    candidates = [base + ext for ext in (".ttml", ".krc", ".lrc", ".txt") for base in (stem, path)]
    for candidate in candidates if source != "embedded" else ():
        if not xbmcvfs.exists(candidate):
            continue
        handle = xbmcvfs.File(candidate)
        try:
            data = bytes(handle.readBytes(MAX_TEXT + 1))
        finally:
            handle.close()
        try:
            if len(data) > MAX_TEXT:
                raise ValueError("Lyric sidecar exceeds size limit")
            lines, plain = parse_sidecar(data, os.path.splitext(candidate)[1])
        except (ValueError, SyntaxError) as error:
            xbmc.log("Flixium lyric sidecar {}: {}".format(candidate, error), xbmc.LOGWARNING)
            continue
        if lines or plain:
            return lines, plain, "Local lyrics ({})".format(os.path.splitext(candidate)[1][1:].upper())
    if source == "local":
        return [], "", ""
    if path and xbmcvfs.exists(path):
        handle = xbmcvfs.File(path)
        try:
            lines, plain = embedded_lyrics(handle)
        finally:
            handle.close()
        if lines or plain:
            return lines, plain, "Embedded lyrics"
    lines, plain = parse_lyrics(xbmc.getInfoLabel("MusicPlayer.Lyrics"))
    return lines, plain, "Embedded lyrics" if lines or plain else ""


def run():
    monitor, player, window = xbmc.Monitor(), xbmc.Player(), xbmcgui.Window(10000)
    if window.getProperty(PREFIX + "running"):
        return
    window.setProperty(PREFIX + "running", "true")
    xbmc.log("Flixium music playback service started", xbmc.LOGINFO)
    blur = PlaybackBlur(window)
    glow = LyricGlow()
    words = WordLyrics()
    cache, published = OrderedDict(), {}
    current_path, lines, times, plain, source = "", [], [], "", ""
    last_lyric_id = None
    current_source = ""
    index = -1

    def publish(values, lyric_id=None, word_line=None, position=0):
        nonlocal last_lyric_id
        values = dict(values)
        if values.get("mode") == "synced":
            # Fill the hidden bank, including its halo, before switching the
            # visible snapshot so the scrolling text and glow arrive together.
            values.update((key, published.get(key, "")) for key in SNAPSHOTS)
            bank = published.get("bank", "")
            if lyric_id != last_lyric_id:
                bank = "b" if bank == "a" else "a"
                values.update((bank + "." + key, values[key]) for key, _ in CONTEXT)
                values[bank + ".glow"] = ""
                try:
                    if not getattr(word_line, "words", ()):
                        text = values["current"].replace("[", "［").replace("]", "］")
                        values[bank + ".glow"] = glow.image_for(text)
                except Exception as error:
                    # An optional visual effect must never interrupt lyric sync.
                    values[bank + ".glow"] = ""
                    xbmc.log("Flixium lyric glow: {}".format(error), xbmc.LOGWARNING)
            values[bank + ".frame"], values[bank + ".wordtimed"] = "", ""
            if getattr(word_line, "words", ()):
                try:
                    values[bank + ".frame"] = words.frame_for(word_line, position)
                    values[bank + ".wordtimed"] = "true"
                except Exception as error:
                    xbmc.log("Flixium word lyrics: {}".format(error), xbmc.LOGWARNING)
            values["bank"] = bank
        last_lyric_id = lyric_id
        for key in PROPERTIES:
            value = values.get(key, "")
            if published.get(key) != value:
                # Lyrics are data, not Kodi label markup.
                window.setProperty(PREFIX + key, value.replace("[", "［").replace("]", "］"))
                published[key] = value

    try:
        while not monitor.abortRequested():
            if xbmc.getSkinDir() != "skin.flixium" or not player.isPlayingAudio():
                publish({})
                blur.clear()
                current_path = ""
                monitor.waitForAbort(0.5)
                continue
            try:
                visible = xbmc.getCondVisibility("Window.IsVisible(visualisation) | Window.IsVisible(musicosd)")
                if not visible:
                    monitor.waitForAbort(0.5)
                    continue
                blur.update()
                if not xbmc.getCondVisibility("!Skin.HasSetting(FlixiumMusicLyricsDisabled)"):
                    publish({"mode": "missing"})
                    current_path = ""
                    monitor.waitForAbort(0.5)
                    continue
                path = player.getPlayingFile()
                source_mode = "embedded" if xbmc.getCondVisibility("Skin.HasSetting(FlixiumMusicEmbeddedLyrics)") else "local"
                cache_key = (path, source_mode)
                if path != current_path or source_mode != current_source:
                    publish({"mode": "loading"})
                    current_path = path
                    current_source = source_mode
                    lines, times, plain, source = [], [], "", ""
                    index = -1
                    if cache_key in cache:
                        lines, plain, source = cache.pop(cache_key)
                    else:
                        lines, plain, source = load_lyrics(path, source_mode)
                    cache[cache_key] = (lines, plain, source)
                    while len(cache) > 8:
                        cache.popitem(last=False)
                    times = [entry[0] for entry in lines]
                if lines:
                    position = player.getTime()
                    index = bisect.bisect_right(times, position) - 1
                    values = {"mode": "synced", "source": source}
                    for key, offset in CONTEXT:
                        target = index + offset
                        values[key] = lines[target][1] if 0 <= target < len(lines) else ""
                    word_line = lines[index] if index >= 0 else None
                    publish(values, (path, source_mode, index), word_line, position)
                elif plain:
                    publish({"mode": "plain", "text": plain, "source": source})
                else:
                    publish({"mode": "missing"})
            except Exception as error:
                xbmc.log("Flixium local lyrics: {}".format(error), xbmc.LOGWARNING)
                publish({"mode": "missing"})
            # Native Player.Progress owns seeking; Python only synchronises lyrics.
            word_timed = lines and index >= 0 and getattr(lines[index], "words", ())
            delay = 0.5 if not lines or xbmc.getCondVisibility("Player.Paused") else (0.05 if word_timed else 0.1)
            monitor.waitForAbort(delay)
    finally:
        blur.clear()
        window.clearProperty(PREFIX + "running")
        window.clearProperty("flixium.playback.progress")  # Remove a legacy unused value.
        for key in PROPERTIES:
            window.clearProperty(PREFIX + key)


if __name__ == "__main__":
    run()
