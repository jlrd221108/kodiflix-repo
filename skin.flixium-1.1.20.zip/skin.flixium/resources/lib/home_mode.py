"""Callback-driven home mode lifecycle; no Kodi imports or implicit file access.

The build owns resources/mq5/runtime-manifest.json. Its contract is
{"ready": true, "requiredfiles": ["xml/installed-runtime.xml", ...]}.
Paths are relative to the installed skin, never the source MQ5 addon or staging
tree. Readiness certifies the original MQ5 runtime assembled by the build;
this controller does not recreate, install, or initialise MQ5 configuration.
"""
import json


MODE_SETTING = "Flixium.Home.MQ5"
MANIFEST_PATH = "resources/mq5/runtime-manifest.json"

# Only transient, namespaced equivalents of MQ5 home state belong here.
# Never enumerate a prefix or clear Skin.String/HasSetting preferences.
TEMP_PROPERTIES = (
    "Flixium.MQ5.current_wxicon_path",
    "Flixium.MQ5.current_wxicon_multi",
    "Flixium.MQ5.skin.aeonmq5.omegamod.status",
)
TEMP_ALARMS = ("Flixium.MQ5.artistslideshow",)
# The user's shutdowntimer (including a namespaced one) is not home state.


def valid_runtime_path(path):
    """Accept canonical skin-relative files, excluding build/source locations."""
    if not isinstance(path, str) or not path or path != path.strip():
        return False
    if any(char in path for char in ("\\", ":", "\x00")):
        return False
    parts = path.split("/")
    return (all(part not in ("", ".", "..") for part in parts)
            and parts[0].lower() not in ("ports", "tools", ".git"))


def runtime_problem(read_text, is_file):
    """Return a useful readiness failure, or None; callbacks use skin paths."""
    try:
        manifest = json.loads(read_text(MANIFEST_PATH))
        if not isinstance(manifest, dict) or manifest.get("ready") is not True:
            return "The installed original MQ5 home runtime is not marked ready."
        files = manifest.get("requiredfiles")
        if not isinstance(files, list) or not files:
            return "The MQ5 runtime manifest needs a nonempty requiredfiles list."
        for path in files:
            if not valid_runtime_path(path):
                return "The MQ5 runtime manifest contains an invalid installed file path."
            if not is_file(path):
                return "A required MQ5 runtime file is missing: {}".format(path)
    except (OSError, ValueError, TypeError, RuntimeError) as error:
        return "Cannot validate the installed MQ5 runtime manifest: {}".format(error)
    return None


class HomeModeController:
    """Callbacks are synchronous. set_mode/toggle return True only on change.

    get_enabled() -> bool; set_enabled(bool); read_text(skin_relative_path);
    is_file(skin_relative_path) -> bool; clear_property(name); cancel_alarm(name);
    reload_skin(); show_dialog(heading, message).
    The filesystem adapter must reject paths resolving outside the active skin.
    """

    def __init__(self, *, get_enabled, set_enabled, read_text, is_file,
                 clear_property, cancel_alarm, reload_skin, show_dialog):
        self.get_enabled = get_enabled
        self.set_enabled = set_enabled
        self.read_text = read_text
        self.is_file = is_file
        self.clear_property = clear_property
        self.cancel_alarm = cancel_alarm
        self.reload_skin = reload_skin
        self.show_dialog = show_dialog

    def toggle(self):
        return self.set_mode(not self.get_enabled())

    def set_mode(self, enabled):
        if not isinstance(enabled, bool):
            raise TypeError("enabled must be a bool")
        if enabled == self.get_enabled():
            return False
        if enabled:
            problem = runtime_problem(self.read_text, self.is_file)
            if problem:
                self.show_dialog(
                    "Original MQ5 home unavailable",
                    problem + "\nInstall or rebuild the complete self-contained MQ5 "
                    "home runtime in this skin, then try again. "
                    "Your home mode and saved configurations have not changed.")
                return False
        for name in TEMP_ALARMS:
            self.cancel_alarm(name)
        for name in TEMP_PROPERTIES:
            self.clear_property(name)
        self.set_enabled(enabled)
        self.reload_skin()
        return True
